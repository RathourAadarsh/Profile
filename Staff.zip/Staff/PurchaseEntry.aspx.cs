﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Staff_PurchaseEntry : System.Web.UI.Page
{
    public static TimeZoneInfo timeZoneInfo = TimeZoneInfo.FindSystemTimeZoneById("India Standard Time");
    public static DateTime dateTime;
    Class1 cl3 = new Class1();
    HttpCookie lgdcookie;

    protected void Page_Load(object sender, EventArgs e)
    {
        lgdcookie = Request.Cookies["userauth"];
        if (lgdcookie != null && !string.IsNullOrEmpty(lgdcookie["UserName"]) && (lgdcookie["type"].ToString()) == "Staff")
        {
            if (!IsPostBack)
            {
                dateTime = TimeZoneInfo.ConvertTime(DateTime.Now, timeZoneInfo);
            }
        }
        else
        {
            Response.Redirect("../Login.aspx");
        }
    }

    protected void btnSave_Click(object sender, EventArgs e)
    {

    }
}