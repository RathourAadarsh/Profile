﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class Login : System.Web.UI.Page
{
    public static TimeZoneInfo timeZoneInfo = TimeZoneInfo.FindSystemTimeZoneById("India Standard Time");
    public static DateTime dateTime;
    Class1 cl = new Class1();

    protected void Page_Load(object sender, EventArgs e)
    {
        dateTime = TimeZoneInfo.ConvertTime(DateTime.Now, timeZoneInfo);
        Response.Cache.SetCacheability(HttpCacheability.NoCache);
        Response.Cache.SetNoStore();
        Response.Cache.SetExpires(DateTime.UtcNow.AddMinutes(-1));
        if (!IsPostBack)
        {
            HttpCookie logincookie = Request.Cookies["userauth"];
            if (Request.Cookies["userauth"] != null)
            {
                HttpCookie userAuthCookie = new HttpCookie("userauth");
                userAuthCookie.Expires = DateTime.Now.AddDays(-1);
                Response.Cookies.Add(userAuthCookie);
            }
            bindyear();
        }
    }
    public void bindyear()
    {
        try
        {
            string str = "SELECT FY FROM (SELECT CASE WHEN MONTH(GETUTCDATE()) >= 4 THEN CAST(YEAR(GETUTCDATE())-2 AS VARCHAR(4)) + '-' + RIGHT(CAST(YEAR(GETUTCDATE())-1 AS VARCHAR(4)),2) ELSE CAST(YEAR(GETUTCDATE())-3 AS VARCHAR(4)) + '-' + RIGHT(CAST(YEAR(GETUTCDATE())-2 AS VARCHAR(4)),2) END AS FY UNION ALL SELECT CASE WHEN MONTH(GETUTCDATE()) >= 4 THEN CAST(YEAR(GETUTCDATE())-1 AS VARCHAR(4)) + '-' + RIGHT(CAST(YEAR(GETUTCDATE()) AS VARCHAR(4)),2) ELSE CAST(YEAR(GETUTCDATE())-2 AS VARCHAR(4)) + '-' + RIGHT(CAST(YEAR(GETUTCDATE())-1 AS VARCHAR(4)),2) END UNION ALL SELECT CASE WHEN MONTH(GETUTCDATE()) >= 4 THEN CAST(YEAR(GETUTCDATE()) AS VARCHAR(4)) + '-' + RIGHT(CAST(YEAR(GETUTCDATE())+1 AS VARCHAR(4)),2) ELSE CAST(YEAR(GETUTCDATE())-1 AS VARCHAR(4)) + '-' + RIGHT(CAST(YEAR(GETUTCDATE()) AS VARCHAR(4)),2) END ) AS FYList order by FY desc";
            SqlCommand cmd = new SqlCommand(str, cl.con);
            SqlDataAdapter adp = new SqlDataAdapter(cmd);
            DataTable dt1 = new DataTable();
            adp.Fill(dt1);
            if (dt1.Rows.Count > 0)
            {
                ddlyear.DataSource = dt1;
                ddlyear.DataTextField = "FY";
                ddlyear.DataValueField = "FY";
                ddlyear.DataBind();
            }
        }
        catch (Exception)
        {

        }
    }
    protected void btnlogin_Click(object sender, EventArgs e)
    {
        try
        {
            if (txtuserid.Text == "")
            {
                string message = "Please Enter Username !!";
                string type = "warning";
                ScriptManager.RegisterStartupScript(this, this.GetType(), "Script", "savealert('" + message + "','" + type + "')", true);
                return;
            }
            else if (txtpassword.Text == "")
            {
                string message = "Please Enter Password !!";
                string type = "warning";
                ScriptManager.RegisterStartupScript(this, this.GetType(), "Script", "savealert('" + message + "','" + type + "')", true);
                return;
            }
            else
            {
                string query = "select username,password,type from Login where username='" + txtuserid.Text + "' and password='" + txtpassword.Text + "'";
                SqlDataAdapter sda = new SqlDataAdapter(query, cl.con);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                if (dt.Rows.Count > 0)
                {
                    string usertype = dt.Rows[0]["type"].ToString();
                    HttpCookie logincookie = new HttpCookie("userauth");
                    logincookie["username"] = txtuserid.Text;
                    logincookie["finyear"] = dateTime.ToString("yyyy");
                    logincookie["type"] = usertype;
                    logincookie.Expires = DateTime.Now.AddYears(1);
                    if (usertype == "Admin")
                    {
                        Response.Cookies.Add(logincookie);
                        string redirectUrl = "Admin/Dashboard.aspx";
                        string message = "";
                        string type = "success";
                        string script = "savealert('" + message + "', '" + type + "'); setTimeout(function() {{ window.location.href = '" + redirectUrl + "'; }},  0.1000);"; ScriptManager.RegisterStartupScript(this, this.GetType(), "Script", script, true);
                        return;
                    }
                    else if (usertype == "OPD")
                    {
                        Response.Cookies.Add(logincookie);
                        string redirectUrl = "OPD/Home.aspx";
                        string message = "";
                        string type = "success";
                        string script = "savealert('" + message + "', '" + type + "'); setTimeout(function() {{ window.location.href = '" + redirectUrl + "'; }}, 0.1000);"; ScriptManager.RegisterStartupScript(this, this.GetType(), "Script", script, true);
                        return;
                    }
                    else if (usertype == "IPD")
                    {
                        Response.Cookies.Add(logincookie);
                        string redirectUrl = "IPD/Home.aspx";
                        string message = "";
                        string type = "success";
                        string script = "savealert('" + message + "', '" + type + "'); setTimeout(function() {{ window.location.href = '" + redirectUrl + "'; }}, 0.1000);"; ScriptManager.RegisterStartupScript(this, this.GetType(), "Script", script, true);
                        return;
                    }
                    else if (usertype == "Reception")
                    {
                        Response.Cookies.Add(logincookie);
                        string redirectUrl = "Reception/Default.aspx";
                        string message = "";
                        string type = "success";
                        string script = "savealert('" + message + "', '" + type + "'); setTimeout(function() {{ window.location.href = '" + redirectUrl + "'; }}, 0.1000);"; ScriptManager.RegisterStartupScript(this, this.GetType(), "Script", script, true);
                        return;
                    }
                    else if (usertype == "Pathology")
                    {
                        Response.Cookies.Add(logincookie);
                        string redirectUrl = "Pathology/Home.aspx";
                        string message = "";
                        string type = "success";
                        string script = "savealert('" + message + "', '" + type + "'); setTimeout(function() {{ window.location.href = '" + redirectUrl + "'; }}, 0.1000);"; ScriptManager.RegisterStartupScript(this, this.GetType(), "Script", script, true);
                        return;
                    }
                    else if (usertype == "Doctor")
                    {
                        Response.Cookies.Add(logincookie);
                        string redirectUrl = "Doctor/Home.aspx";
                        string message = "Login Successfully !!";
                        string type = "success";
                        string script = "savealert('" + message + "', '" + type + "'); setTimeout(function() {{ window.location.href = '" + redirectUrl + "'; }}, 0.1000);"; ScriptManager.RegisterStartupScript(this, this.GetType(), "Script", script, true);
                        return;
                    }
                    else if (usertype == "Staff/Nurse")
                    {
                        Response.Cookies.Add(logincookie);
                        string redirectUrl = "Staff/Home.aspx";
                        string message = "";
                        string type = "success";
                        string script = "savealert('" + message + "', '" + type + "'); setTimeout(function() {{ window.location.href = '" + redirectUrl + "'; }}, 0.1000);"; ScriptManager.RegisterStartupScript(this, this.GetType(), "Script", script, true);
                        return;
                    }
                    else if (usertype == "Medical")
                    {
                        Response.Cookies.Add(logincookie);
                        string redirectUrl = "Panel/Home.aspx";
                        string message = "";
                        string type = "success";
                        string script = "savealert('" + message + "', '" + type + "'); setTimeout(function() {{ window.location.href = '" + redirectUrl + "'; }}, 0.1000);"; ScriptManager.RegisterStartupScript(this, this.GetType(), "Script", script, true);
                        return;
                    }
                    //else if (usertype == "Delivery")
                    //{
                    //    Response.Cookies.Add(logincookie);
                    //    string redirectUrl = "Delivery/Home.aspx";
                    //    string message = "Login Successfully !!";
                    //    string type = "success";
                    //    string script = "savealert('" + message + "', '" + type + "'); setTimeout(function() {{ window.location.href = '" + redirectUrl + "'; }}, 1000);"; ScriptManager.RegisterStartupScript(this, this.GetType(), "Script", script, true);
                    //    return;
                    //}
                    else
                    {
                        string message = "Access Denied !!";
                        string type = "error";
                        ScriptManager.RegisterStartupScript(this, this.GetType(), "Script", "savealert('" + message + "','" + type + "')", true);
                        return;
                    }
                }
                else
                {
                    txtpassword.Text = "";
                    string message = "Invalid Login Credentials !!";
                    string type = "error";
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "Script", "savealert('" + message + "','" + type + "')", true);
                    return;
                }
            }
        }
        catch (Exception ex)
        {

        }
    }
}