﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Billing : System.Web.UI.Page
{
    Class1 cl = new Class1();
    public static TimeZoneInfo timeZoneInfo = TimeZoneInfo.FindSystemTimeZoneById("India Standard Time");
    public static DateTime dateTime;
    public static string sku = "";
    public static string kotbill = "";
    public static string item_bill = "";
    public static string kno = "";
    public static string prefix;
    protected string TableNo = "";
    protected void Page_Load(object sender, EventArgs e)
    {
        dateTime = TimeZoneInfo.ConvertTime(DateTime.Now, timeZoneInfo);
        if (!IsPostBack)
        {
            hfTableNo.Value = Request.QueryString["table_no"];
            lblTableNo.Text = hfTableNo.Value;
            itemgroup();
            CalculateBill();
            DataTable dt = new DataTable();
            dt.Columns.Add("ItemName");
            dt.Columns.Add("Rate", typeof(decimal));
            dt.Columns.Add("Qty", typeof(int));
            dt.Columns.Add("Amount", typeof(decimal));
            Session["BillTable"] = dt;
        }
    }
    public void itemgroup()
    {
        string query = "select item_g_id, item_g_name from Item_group_master";
        SqlDataAdapter sda = new SqlDataAdapter(query, cl.con);
        DataTable dt = new DataTable();
        sda.Fill(dt);
        if (dt.Rows.Count > 0)
        {
            lst.DataSource = dt;
            lst.DataBind();
        }
    }

    protected void lnlroom_Click(object sender, EventArgs e)
    {
        LinkButton cb = (LinkButton)sender;
        ListViewItem item = (ListViewItem)cb.NamingContainer;
        ListViewDataItem dataItem = (ListViewDataItem)item;
        string groupname = lst.DataKeys[dataItem.DisplayIndex].Values[0].ToString();
        string query2 = "select item_name from item_detail where item_group_name='" + groupname + "'";
        //lblgroupitem.Text = groupname;
        SqlDataAdapter sda = new SqlDataAdapter(query2, cl.con);
        DataTable dt = new DataTable();
        sda.Fill(dt);
        if (dt.Rows.Count > 0)
        {
            ListView1.DataSource = dt;
            ListView1.DataBind();
            Panel1.Visible = true;
            lblmessage.Visible = false;
        }
        else
        {
            lblmessage.Text = "Item Not Found!!";
            lblmessage.Visible = true;
            Panel1.Visible = false;
        }
    }

    protected void itemname_Click(object sender, EventArgs e)
    {
        LinkButton btn = (LinkButton)sender;
        string itemName = btn.Text;
        string query = "SELECT item_sale_rate FROM item_detail WHERE item_name=@name";
        SqlCommand cmd = new SqlCommand(query, cl.con);
        cmd.Parameters.AddWithValue("@name", itemName);

        cl.con.Open();
        decimal rate = Convert.ToDecimal(cmd.ExecuteScalar());
        cl.con.Close();

        DataTable dt = (DataTable)Session["BillTable"];

        DataRow row = dt.AsEnumerable()
            .FirstOrDefault(r => r.Field<string>("ItemName") == itemName);

        if (row != null)
        {
            row["Qty"] = Convert.ToInt32(row["Qty"]) + 1;
            row["Amount"] = Convert.ToDecimal(row["Qty"]) * rate;
        }
        else
        {
            DataRow dr = dt.NewRow();
            dr["ItemName"] = itemName;
            dr["Rate"] = rate;
            dr["Qty"] = 1;
            dr["Amount"] = rate;
            dt.Rows.Add(dr);
        }

        gvBill.DataSource = dt;
        gvBill.DataBind();
    }
    protected void gvBill_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        DataTable dt = (DataTable)ViewState["BillTable"];
        int index = Convert.ToInt32(e.CommandArgument);

        if (e.CommandName == "Plus")
            dt.Rows[index]["Qty"] = Convert.ToInt32(dt.Rows[index]["Qty"]) + 1;

        if (e.CommandName == "Minus")
        {
            int q = Convert.ToInt32(dt.Rows[index]["Qty"]);
            if (q > 1) dt.Rows[index]["Qty"] = q - 1;
        }

        if (e.CommandName == "Remove")
            dt.Rows.RemoveAt(index);

        foreach (DataRow r in dt.Rows)
            r["Amount"] = Convert.ToDecimal(r["Rate"]) * Convert.ToInt32(r["Qty"]);

        ViewState["BillTable"] = dt;
        gvBill.DataSource = dt;
        gvBill.DataBind();

        CalculateBill();
    }

    protected void txtnumber_TextChanged(object sender, EventArgs e)
    {
        string search = txtnumber.Text.Trim();

        if (string.IsNullOrEmpty(search))
        {
            ListView1.DataSource = null;
            ListView1.DataBind();
            return;
        }

        string query = "SELECT item_name FROM item_detail WHERE item_name LIKE @search";

        SqlDataAdapter sda = new SqlDataAdapter(query, cl.con);
        sda.SelectCommand.Parameters.AddWithValue("@search", "%" + search + "%");

        DataTable dt = new DataTable();
        sda.Fill(dt);

        if (dt.Rows.Count > 0)
        {
            ListView1.DataSource = dt;
            ListView1.DataBind();
            Panel1.Visible = true;
            lblmessage.Visible = false;
        }
        else
        {
            lblmessage.Text = "Item Not Found!";
            lblmessage.Visible = true;
            Panel1.Visible = false;
        }
    }
    private void CalculateBill()
    {
        if (ViewState["BillTable"] == null) return;

        DataTable dt = (DataTable)ViewState["BillTable"];

        decimal subTotal = 0;

        foreach (DataRow row in dt.Rows)
        {
            subTotal += Convert.ToDecimal(row["Amount"]);
        }

        decimal tax = Math.Round(subTotal * 0.05M, 2);   
        decimal grandTotal = subTotal + tax;
        decimal roundOff = Math.Round(grandTotal) - grandTotal;
        grandTotal = Math.Round(grandTotal);

        lblSubTotal.Text = subTotal.ToString("0.00");
        lblTax.Text = tax.ToString("0.00");
        lblRoundOff.Text = roundOff.ToString("0.00");

        lblGrandTotal.Text = grandTotal.ToString("0.00");

        CalculateReturn(grandTotal);
    }
    protected void txtCustomerPaid_TextChanged(object sender, EventArgs e)
    {
        decimal grandTotal = Convert.ToDecimal(lblGrandTotal.Text);
        CalculateReturn(grandTotal);
    }

    private void CalculateReturn(decimal grandTotal)
    {
        decimal paid = 0;
        decimal.TryParse(txtCustomerPaid.Text, out paid);

        decimal ret = paid - grandTotal;
        if (ret < 0) ret = 0;

        lblReturn.Text = ret.ToString("0.00");
    }
    protected void chkPaid_CheckedChanged(object sender, EventArgs e)
    {
        if (chkPaid.Checked)
        {
            txtCustomerPaid.Text = lblGrandTotal.Text;
            CalculateReturn(Convert.ToDecimal(lblGrandTotal.Text));
        }
    }

}