﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;


public partial class Issuetokitchen : System.Web.UI.Page
{
    public static TimeZoneInfo timeZoneInfo = TimeZoneInfo.FindSystemTimeZoneById("India Standard Time");
    public static DateTime dateTime;
    Class1 cl3 = new Class1();
    HttpCookie lgdcookie;

    protected void Page_Load(object sender, EventArgs e)
    {
        lgdcookie = Request.Cookies["loggeduser"];
        dateTime = TimeZoneInfo.ConvertTime(DateTime.Now, timeZoneInfo);
        if (!IsPostBack)
        {
            generateino();
            //itemcategory();
            binddetail();
            bindpno();
            txtpdate.Text = dateTime.ToString("yyyy-MM-dd");
            txtindate.Text = dateTime.ToString("yyyy-MM-dd");
        }
    }
    public void itemcategory(string pnono)
    {
        try
        {
            string str = "select distinct item_g_id,item_g_name from StoreItem_group_Master c inner join PurchaseEntry p on c.Item_G_Id=p.itemcate where pno='"+pnono+"' and c.deactive='0' order by item_g_name";
            SqlCommand cmd = new SqlCommand(str, cl3.con);
            SqlDataAdapter adp = new SqlDataAdapter(cmd);
            DataTable dt1 = new DataTable();
            adp.Fill(dt1);
            if (dt1.Rows.Count > 0)
            {
                ddlitemcate.DataSource = dt1;
                ddlitemcate.DataTextField = "item_g_name";
                ddlitemcate.DataValueField = "item_g_id";
                ddlitemcate.DataBind();
                ddlitemcate.Items.Insert(0, new ListItem("--Select--", "0"));
            }
        }
        catch (Exception)
        {

        }
    }
    public void item(string igrouname)
    {
        try
        {
            string str = "select distinct sku,item_name from StoreItem_detail s inner join PurchaseEntry p on s.sku=p.itemname where pno='" + txtpno.SelectedItem.Text + "' and s.Deactive='0'";
            SqlCommand cmd = new SqlCommand(str, cl3.con);
            SqlDataAdapter adp = new SqlDataAdapter(cmd);
            DataTable dt1 = new DataTable();
            adp.Fill(dt1);
            if (dt1.Rows.Count > 0)
            {
                ddlitename.DataSource = dt1;
                ddlitename.DataTextField = "item_name";
                ddlitename.DataValueField = "sku";
                ddlitename.DataBind();
                ddlitename.Items.Insert(0, new ListItem("--Select--", "0"));
            }
        }
        catch (Exception ex)
        {

        }
    }
    public void generateino()
    {
        int len = 0;
        string id = null;
        string st = null;
        int count = 0;
        int i = 0;
        string vou = null;
        string prefix = cl3.Scalar("select Inofix from PrefixPurchase");
        vou = "Select ISNULL(max(convert(int,isid)),0) as isid  from IssuetoKitchen where finyear='" + lgdcookie["finyear"] + "'";
        count = Convert.ToInt32(cl3.Scalar(vou));
        if (count > 0)
        {
            st = cl3.Scalar("Select ISNULL(max(convert(int,isid)),0) as isid  from IssuetoKitchen where finyear='" + lgdcookie["finyear"] + "'");
            i = Convert.ToInt32(st);
            id = (i + 1).ToString();
            len = id.Length;
            switch (len)
            {
                case 1:
                    id = "000" + id;
                    break;
                case 2:
                    id = "00" + id;
                    break;
                case 3:
                    id = "0" + id;
                    break;
            }
        }
        else
        {
            id = "0001";
        }
        lblisid.Text = id;
        lblissno.Text = prefix + "/" + id;
    }
    public void binddetail()
    {
        string query = "select ptype,p.isid,p.ino,convert(nvarchar,p.idate,103)pdate,p.inv,convert(nvarchar,p.invdt,103)pinvdt,p.itemcate,p.itemname,p.qty,p.rate,p.amount,sip.Item_G_Name,sd.Item_name from Issuetokitchen p inner join StoreItem_group_Master sip on p.itemcate=sip.item_g_id inner join storeitem_detail sd on p.itemname=sd.sku where pno='" + txtpno.Text + "'";
        SqlDataAdapter sda = new SqlDataAdapter(query, cl3.con);
        DataTable dt = new DataTable();
        sda.Fill(dt);
        if (dt.Rows.Count > 0)
        {
            listview2.DataSource = dt;
            listview2.DataBind();
        }
    }

    protected void ddlitemcate_SelectedIndexChanged(object sender, EventArgs e)
    {
        item(ddlitemcate.SelectedValue);
    }

    protected void ddlitename_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            txtrate.Text = cl3.Scalar("select rate from purchaseentry where sku = '" + ddlitename.SelectedValue + "' and pno='"+txtpno.SelectedItem.Text+"'");

        }
        catch (Exception ex)
        {

        }
    }

    protected void btnSave_Click(object sender, EventArgs e)
    {
        try
        {
            if (txtindate.Text == "" || txtpno.Text == "" || txtpdate.Text == "" || ddlitename.SelectedValue == "0" || txtqty.Text == "" || txtrate.Text == "" || txtamt.Text == "" || ddlitemcate.SelectedValue == "0")
            {

                string message = "Please Fill All Fields !!";
                string type = "warning";
                ScriptManager.RegisterStartupScript(this, this.GetType(), "Script", "savealert('" + message + "','" + type + "')", true);
                return;
            }
            else
            {
                Store clsave = new Store();
                if (rbtnpurchase.SelectedValue == "Kitchen")
                {
                    
                    int purchaseQty = Convert.ToInt32(cl3.Scalar("select isnull(sum(cast(qty as int)),0) from  PurchaseEntry where pid='" + txtpno.Text + "' and itemname='"+ ddlitename.SelectedValue+ "'"));
                    string issueqty = txtqty.Text.Trim();
                    int sum=Convert.ToInt32(cl3.Scalar("select Isnull(sum(Cast(qty as int)),0) from IssuetoKitchen where pno='"+ txtpno.Text + "' and itemname='"+ddlitename.SelectedValue+"'"));
                    if(sum>0)
                    {
                        int remaingqty = purchaseQty - sum;
                        if(remaingqty==0)
                        {
                            string message = "You have alerady issued All Quantity !!";
                            string type = "warning";
                            ScriptManager.RegisterStartupScript(this, this.GetType(), "Script", "savealert('" + message + "','" + type + "')", true);
                            return;
                        }
                        if(Convert.ToInt32(issueqty)>remaingqty)
                        {
                            string message = "You Can Issule only ("+remaingqty+") Quantity !!";
                            string type = "warning";
                            ScriptManager.RegisterStartupScript(this, this.GetType(), "Script", "savealert('" + message + "','" + type + "')", true);
                            return;
                        }

                    }
                    else
                    {
                        if(Convert.ToInt32(issueqty) > purchaseQty)
                        {
                            string message = "You Can Issule Valid Quantity !!";
                            string type = "warning";
                            ScriptManager.RegisterStartupScript(this, this.GetType(), "Script", "savealert('" + message + "','" + type + "')", true);
                            return;
                        }
                    }
                  
                   string txtinvno = "";
                    bool issue = clsave.Issuetokitchen(lblisid.Text, lblissno.Text, txtpdate.Text, txtinvno, txtindate.Text, ddlitename.SelectedValue, txtqty.Text, txtrate.Text, txtamt.Text, lgdcookie["username"].ToString(), lgdcookie["finyear"].ToString(), ddlitemcate.SelectedValue, rbtnpurchase.SelectedValue, txtpno.Text);
                }
                else
                {
                    string message = "Something Went Wrong !!";
                    string type = "error";
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "Script", "savealert('" + message + "','" + type + "')", true);
                    return;
                }
                binddetail();
                txtamt.Text = "";
                txtqty.Text = "";
                txtrate.Text = "";
                btnfinal.Visible = true;
            }
        }
        catch (Exception ex)
        {

        }
    }

    protected void btnClear_Click(object sender, EventArgs e)
    {
        Response.Redirect("StoreDashboard.aspx");
    }

    protected void btnfinal_Click(object sender, EventArgs e)
    {
        Response.Redirect("Issuetokitchen.aspx");
    }
    public void bindpno()
    {
        try
        {
            string str = "select distinct pid,pno from PurchaseEntry order by pid";
            SqlCommand cmd = new SqlCommand(str, cl3.con);
            SqlDataAdapter adp = new SqlDataAdapter(cmd);
            DataTable dt1 = new DataTable();
            adp.Fill(dt1);
            if (dt1.Rows.Count > 0)
            {
                txtpno.DataSource = dt1;
                txtpno.DataTextField = "pno";
                txtpno.DataValueField = "pid";
                txtpno.DataBind();
                txtpno.Items.Insert(0, new ListItem("--Select--", "0"));
            }
        }
        catch (Exception)
        {

        }
    }

    protected void txtpno_SelectedIndexChanged(object sender, EventArgs e)
    {
        itemcategory(txtpno.SelectedItem.Text);
        string dtt = cl3.Scalar("select convert(nvarchar,pdate,103)da from PurchaseEntry where pno='"+txtpno.SelectedItem.Text+"'");
        DateTime dttt=DateTime.ParseExact(dtt,"dd/MM/yyyy",null);
        txtpdate.Text = dttt.ToString("yyyy-MM-dd");

    }
}