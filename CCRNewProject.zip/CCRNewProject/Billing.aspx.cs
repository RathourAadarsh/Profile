﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Billing : System.Web.UI.Page
{
    public static TimeZoneInfo timeZoneInfo = TimeZoneInfo.FindSystemTimeZoneById("India Standard Time");
    public static DateTime dateTime;
    HttpCookie lgdcookie;

    Class1 cl = new Class1();
    public static string sku = "";
    public static string kotbill = "";
    protected string TableNo = "";
    protected void Page_Load(object sender, EventArgs e)
    {
        lgdcookie = Request.Cookies["loggeduser"];
        if (lgdcookie != null && !string.IsNullOrEmpty(lgdcookie["UserName"]))
        {
            dateTime = TimeZoneInfo.ConvertTime(DateTime.Now, timeZoneInfo);
            if (!IsPostBack)
            {
                if (string.IsNullOrWhiteSpace(Request.QueryString["table_no"]))
                {
                    Response.Redirect("Dashboard.aspx");
                    return;
                }
                hfTableNo.Value = Request.QueryString["table_no"];
                string view = Request.QueryString["view"];
                lblTableNo.Text = hfTableNo.Value;
                LoadKotNumbers(hfTableNo.Value);
                bindbill(hfTableNo.Value);
                if (view == "1")
                {
                    LoadOpenKOT(hfTableNo.Value);
                }
                else
                {
                    Session["BillTable"] = null;
                    BindGrid(0);
                    lblSubTotal.Text = "0.00";
                    lblTax.Text = "0.00";
                    lblGrandTotal.Text = "0.00";
                    lblRoundOff.Text = "0.00";
                    lblReturn.Text = "0.00";
                    txtdiscount.Text = "0";
                    txtdilivery.Text = "0";
                    txtCustomerPaid.Text = "";
                }
                itemgroup();
                CalculateBill();
            }
        }
        else
        {
            Response.Redirect("Login.aspx");
        }
    }
    public void bindbill(String table)
    {
        try
        {
            string query = "SELECT bd.itemname, sum(bd.qty) as qty FROM KOT_Master bm LEFT JOIN KOT_Detail bd ON bm.KOT_ID = bd.KOT_ID LEFT JOIN item_detail id ON bd.itemname = id.item_name WHERE bm.IsClosed = 0 and bm.table_no= '" + table + "' AND bm.isrunning = 1 group by bd.ItemName ORDER BY bd.itemname ";

            SqlDataAdapter sda = new SqlDataAdapter(query, cl.con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                gvPopupItems.DataSource = dt;
                gvPopupItems.DataBind();
            }
        }
        catch (Exception ex)
        {

        }
    }

    protected void gvBill_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            string view = Request.QueryString["view"];

            if (view == "1")
            {
                LinkButton btnMinus = (LinkButton)e.Row.FindControl("Minus");
                LinkButton btnPlus = (LinkButton)e.Row.FindControl("Plus");
                LinkButton btnRemove = (LinkButton)e.Row.FindControl("Remove");

                if (btnMinus != null)
                {
                    btnMinus.Enabled = false;
                    btnMinus.CssClass += " disabled-btn";
                }

                if (btnPlus != null)
                {
                    btnPlus.Enabled = false;
                    btnPlus.CssClass += " disabled-btn";
                }

                if (btnRemove != null)
                {
                    btnRemove.Enabled = false;
                    btnRemove.CssClass += " disabled-btn";
                }
            }
        }
    }

    private void BindGrid(int isSaved)
    {
        if (Session["BillTable"] == null) return;

        DataView dv = new DataView((DataTable)Session["BillTable"]);
        dv.RowFilter = "IsSaved = " + isSaved;

        gvBill.DataSource = dv;
        gvBill.DataBind();
    }

    private void LoadOpenKOT(string tableNo)
    {
        DataTable dt = new DataTable();
        dt.Columns.Add("ItemName");
        dt.Columns.Add("Rate", typeof(decimal));
        dt.Columns.Add("Qty", typeof(int));
        dt.Columns.Add("Amount", typeof(decimal));
        dt.Columns.Add("Flag", typeof(int));
        dt.Columns.Add("SKU", typeof(string));
        dt.Columns.Add("GST", typeof(decimal));
        dt.Columns.Add("GroupName", typeof(string));
        dt.Columns.Add("IsSaved", typeof(int));
        SqlCommand cmd = new SqlCommand("SELECT d.ItemName, d.Rate, d.Qty, d.Amount, ISNULL(i.flag,1) Flag,d.sku,d.gst_per,   igm.pgroupname FROM KOT_Master m INNER JOIN KOT_Detail d ON m.KOT_ID = d.KOT_ID LEFT JOIN item_detail i ON d.ItemName = i.item_name LEFT JOIN Item_group_Master igm ON i.Item_group_name = igm.Item_G_Id WHERE m.Table_No = @TableNo AND m.IsClosed = 0 ", cl.con);
        cmd.Parameters.AddWithValue("@TableNo", tableNo);

        cl.con.Open();
        SqlDataReader dr = cmd.ExecuteReader();
        while (dr.Read())
        {
            DataRow r = dt.NewRow();
            r["ItemName"] = dr["ItemName"];
            r["Rate"] = dr["Rate"];
            r["Qty"] = dr["Qty"];
            r["Amount"] = dr["Amount"];
            r["Flag"] = dr["Flag"];
            r["SKU"] = dr["sku"];
            r["GST"] = dr["gst_per"];
            r["GroupName"] = dr["pgroupname"] == DBNull.Value ? "" : dr["pgroupname"].ToString();
            r["IsSaved"] = 1;
            dt.Rows.Add(r);
        }
        cl.con.Close();

        Session["BillTable"] = dt;
        BindGrid(1);


    }
    private void LoadKotNumbers(string tableNo)
    {
        DataTable dt = new DataTable();
        dt.Columns.Add("KOT_No");

        SqlCommand cmd = new SqlCommand(
            "SELECT KOT_No FROM KOT_Master WHERE Table_No=@t AND IsClosed=0 ORDER BY KOT_No", cl.con);
        cmd.Parameters.AddWithValue("@t", tableNo);

        cl.con.Open();
        SqlDataReader dr = cmd.ExecuteReader();
        while (dr.Read())
        {
            DataRow r = dt.NewRow();
            r["KOT_No"] = dr["KOT_No"].ToString();
            dt.Rows.Add(r);
        }
        cl.con.Close();

        rptKOT.DataSource = dt;
        rptKOT.DataBind();

        lblNextKOT.Text = GenerateKOTNo();
    }

    public void itemgroup()
    {
        string query = "select item_g_id, item_g_name from Item_group_master where deactive = 0 order by item_g_name ";
        SqlDataAdapter sda = new SqlDataAdapter(query, cl.con);
        DataTable dt = new DataTable();
        sda.Fill(dt);
        if (dt.Rows.Count > 0)
        {
            lst.DataSource = dt;
            lst.DataBind();
        }
    }
    protected void lnlroom_Click(object sender, EventArgs e)
    {
        LinkButton btn = (LinkButton)sender;
        ListViewDataItem dataItem = (ListViewDataItem)btn.NamingContainer;

        int groupId = Convert.ToInt32(lst.DataKeys[dataItem.DataItemIndex].Value);

        string query2 = "select item_name from item_detail where item_group_name = @gid";

        SqlDataAdapter sda = new SqlDataAdapter(query2, cl.con);
        sda.SelectCommand.Parameters.AddWithValue("@gid", groupId);

        DataTable dt = new DataTable();
        sda.Fill(dt);

        if (dt.Rows.Count > 0)
        {
            ListView1.DataSource = dt;
            ListView1.DataBind();
            Panel1.Visible = true;
            lblmessage.Visible = false;
        }
        else
        {
            lblmessage.Text = "Item Not Found!!";
            lblmessage.Visible = true;
            Panel1.Visible = false;
        }
    }

    protected void itemname_Click(object sender, EventArgs e)
    {

        LinkButton btn = (LinkButton)sender;
        string itemName = btn.Text;

        string query = "SELECT item_sale_rate, flag,sku, gst_per,igm.pgroupname FROM item_detail id left join Item_group_Master igm on id.Item_group_name = igm.Item_G_Id WHERE item_name=@name";
        SqlCommand cmd = new SqlCommand(query, cl.con);
        cmd.Parameters.AddWithValue("@name", itemName);

        decimal rate = 0;
        int flag = 1;
        string sku = "";
        decimal gst = 0;
        string groupName = "";

        cl.con.Open();
        SqlDataReader dr = cmd.ExecuteReader();
        if (dr.Read())
        {
            rate = dr["item_sale_rate"] == DBNull.Value ? 0 : Convert.ToDecimal(dr["item_sale_rate"]);
            flag = dr["flag"] == DBNull.Value ? 0 : Convert.ToInt32(dr["flag"]);
            sku = dr["sku"] == DBNull.Value ? "" : dr["sku"].ToString();
            gst = dr["gst_per"] == DBNull.Value ? 0 : Convert.ToDecimal(dr["gst_per"]);
            groupName = dr["pgroupname"].ToString();

        }
        cl.con.Close();
        DataTable dt;
        if (Session["BillTable"] == null)
        {
            dt = new DataTable();
            dt.Columns.Add("ItemName", typeof(string));
            dt.Columns.Add("Rate", typeof(decimal));
            dt.Columns.Add("Qty", typeof(int));
            dt.Columns.Add("Amount", typeof(decimal));
            dt.Columns.Add("Flag", typeof(int));
            dt.Columns.Add("SKU", typeof(string));
            dt.Columns.Add("GST", typeof(decimal));
            dt.Columns.Add("GroupName", typeof(string));
            dt.Columns.Add("IsSaved", typeof(int));
            Session["BillTable"] = dt;
        }
        else
        {
            dt = (DataTable)Session["BillTable"];
        }

        DataRow row = dt.AsEnumerable()
          .FirstOrDefault(r => r.Field<string>("ItemName") == itemName && Convert.ToInt32(r["IsSaved"]) == 0);

        if (row != null)
        {
            row["Qty"] = Convert.ToInt32(row["Qty"]) + 1;
            row["Amount"] = Convert.ToInt32(row["Qty"]) * rate;
        }
        else
        {
            DataRow drNew = dt.NewRow();
            drNew["ItemName"] = itemName;
            drNew["Rate"] = rate;
            drNew["Qty"] = 1;
            drNew["Amount"] = rate;
            drNew["Flag"] = flag;
            drNew["SKU"] = sku;
            drNew["GST"] = gst;
            drNew["GroupName"] = groupName;
            drNew["IsSaved"] = 0;
            dt.Rows.Add(drNew);
        }
        Session["BillTable"] = dt;
        BindGrid(0);
        CalculateBill();
    }
    protected void gvBill_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (Session["BillTable"] == null) return;
        if (Request.QueryString["view"] == "1") return;
        DataTable dt = (DataTable)Session["BillTable"];

        int index;
        if (!int.TryParse(e.CommandArgument.ToString(), out index))
            return;

        if (index < 0 || index >= dt.Rows.Count)
            return;

        if (e.CommandName == "Plus")
        {
            dt.Rows[index]["Qty"] =
                Convert.ToInt32(dt.Rows[index]["Qty"]) + 1;
        }
        else if (e.CommandName == "Minus")
        {
            int q = Convert.ToInt32(dt.Rows[index]["Qty"]);

            if (q > 1)
                dt.Rows[index]["Qty"] = q - 1;
            else
                dt.Rows.RemoveAt(index);
        }
        else if (e.CommandName == "Remove")
        {
            dt.Rows.RemoveAt(index);
        }
        foreach (DataRow r in dt.Rows)
        {
            r["Amount"] =
                Convert.ToDecimal(r["Rate"]) * Convert.ToInt32(r["Qty"]);
        }
        Session["BillTable"] = dt;
        BindGrid(0);
        CalculateBill();
    }

    private void CalculateBill()
    {
        if (Session["BillTable"] == null) return;

        DataTable dt = (DataTable)Session["BillTable"];
        string view = Request.QueryString["view"];

        decimal subTotal = 0;
        decimal foodSubTotal = 0;
        decimal tax = 0;

        foreach (DataRow row in dt.Rows)
        {
            int isSaved = Convert.ToInt32(row["IsSaved"]);

            if (view == "1")
            {
                if (isSaved != 1) continue;
            }
            else
            {
                if (isSaved != 0) continue;
            }

            decimal amt = Convert.ToDecimal(row["Amount"]);
            decimal gstPer = row["GST"] == DBNull.Value ? 0 : Convert.ToDecimal(row["GST"]);
            string groupName = row["GroupName"] == DBNull.Value ? "" : row["GroupName"].ToString().ToUpper();

            subTotal += amt;
            if (groupName == "FOODING")
            {
                foodSubTotal += amt;
            }

            tax += Math.Round((amt * gstPer) / 100, 2);
        }
        decimal discountPer = 0;
        decimal.TryParse(txtdiscount.Text, out discountPer);

        if (discountPer > 40)
        {
            discountPer = 40;
            txtdiscount.Text = "40";
        }

        decimal discountAmount = 0;
        if (discountPer > 0 && foodSubTotal > 0)
        {
            discountAmount = Math.Round((foodSubTotal * discountPer) / 100, 2);
        }
        decimal netAmount = subTotal - discountAmount;
        decimal deliveryCharge = 0;
        decimal.TryParse(txtdilivery.Text, out deliveryCharge);

        decimal exactTotal = netAmount + tax + deliveryCharge;
        decimal grandTotal = Math.Round(exactTotal);
        decimal roundOff = grandTotal - exactTotal;

        lblSubTotal.Text = subTotal.ToString("0.00");
        lblTax.Text = tax.ToString("0.00");
        lblRoundOff.Text = roundOff.ToString("0.00");
        lblGrandTotal.Text = grandTotal.ToString("0.00");

        CalculateReturn(grandTotal);
    }

    private void CalculateReturn(decimal grandTotal)
    {
        decimal paid = 0;
        decimal.TryParse(txtCustomerPaid.Text, out paid);

        decimal ret = paid - grandTotal;
        if (ret < 0) ret = 0;

        lblReturn.Text = ret.ToString("0.00");
    }
    protected void txtdilivery_TextChanged(object sender, EventArgs e)
    {
        CalculateBill();
    }
    protected void txtdiscount_TextChanged(object sender, EventArgs e)
    {
        CalculateBill();
    }
    protected void txtCustomerPaid_TextChanged(object sender, EventArgs e)
    {
        decimal grandTotal = Convert.ToDecimal(lblGrandTotal.Text);
        CalculateReturn(grandTotal);
    }
    protected void txtnumber_TextChanged(object sender, EventArgs e)
    {
        string search = txtnumber.Text.Trim();

        if (string.IsNullOrEmpty(search))
        {
            ListView1.DataSource = null;
            ListView1.DataBind();
            return;
        }

        string query = "SELECT item_name FROM item_detail WHERE item_name LIKE @search";

        SqlDataAdapter sda = new SqlDataAdapter(query, cl.con);
        sda.SelectCommand.Parameters.AddWithValue("@search", "%" + search + "%");

        DataTable dt = new DataTable();
        sda.Fill(dt);

        if (dt.Rows.Count > 0)
        {
            ListView1.DataSource = dt;
            ListView1.DataBind();
            Panel1.Visible = true;
            lblmessage.Visible = false;
        }
        else
        {
            lblmessage.Text = "Item Not Found!";
            lblmessage.Visible = true;
            Panel1.Visible = false;
        }
    }
    protected void chkPaid_CheckedChanged(object sender, EventArgs e)
    {
        if (chkPaid.Checked)
        {
            txtCustomerPaid.Text = lblGrandTotal.Text;
            CalculateReturn(Convert.ToDecimal(lblGrandTotal.Text));
        }
    }
    protected void btnKot_Click(object sender, EventArgs e)
    {
        SaveKOTSplit(false);
    }
    protected void btnKotPrint_Click(object sender, EventArgs e)
    {
        SaveKOTSplit(true);
    }
    private int GetCurrentBillNo(int tableNo)
    {
        SqlCommand cmd = new SqlCommand("SELECT ISNULL(MAX(Bill_No),0) + 1 FROM KOT_Master WHERE Table_No=@t AND IsClosed=1", cl.con);

        cmd.Parameters.AddWithValue("@t", tableNo);

        cl.con.Open();
        int billNo = Convert.ToInt32(cmd.ExecuteScalar());
        cl.con.Close();

        return billNo == 0 ? 1 : billNo;
    }
    private void ClearGridAfterKOT()
    {
        DataTable dt = (DataTable)Session["BillTable"];
        dt.Clear();
        Session["BillTable"] = dt;
        BindGrid(0);
        CalculateBill();


    }
    private void SaveKOTSplit(bool isPrint)
    {
        if (Session["BillTable"] == null) return;

        DataTable dt = (DataTable)Session["BillTable"];
        if (dt.Rows.Count == 0) return;

        string tableNo = hfTableNo.Value;
        string kotNo = GenerateKOTNo();

        DataRow[] foodRows =
            dt.Select("GroupName IN ('FOODING','BEVERAGE','COMPL') AND IsSaved = 0");

        DataRow[] barRows =
            dt.Select("GroupName = 'BAR' AND IsSaved = 0");

        if (foodRows.Length > 0)
            SaveKOTByGroup(foodRows, tableNo, kotNo, "FOOD", isPrint);

        if (barRows.Length > 0)
            SaveKOTByGroup(barRows, tableNo, kotNo, "BAR", isPrint);

        BindGrid(0);
        CalculateBill();

        if (isPrint)
        {
            Response.Redirect(
                "Print_KOT.aspx?table_no=" + tableNo + "&kotno=" + kotNo,
                false
            );
            Context.ApplicationInstance.CompleteRequest();
        }
        else
        {
            Response.Redirect("Dashboard.aspx");
        }
    }
    private void SaveKOTByGroup(DataRow[] rows, string tableNo, string kotNo, string orderType, bool isPrint)
    {
        DataTable kotDT = rows.CopyToDataTable();

        decimal total = 0;
        decimal gst = 0;

        foreach (DataRow r in kotDT.Rows)
        {
            decimal amt = Convert.ToDecimal(r["Amount"]);
            decimal gstPer = r["GST"] == DBNull.Value ? 0 : Convert.ToDecimal(r["GST"]);

            total += amt;
            gst += Math.Round((amt * gstPer) / 100, 2);
        }

        decimal grandTotal = total + gst;

        cl.con.Open();
        SqlTransaction tran = cl.con.BeginTransaction();

        try
        {
            SqlCommand cmdKot = new SqlCommand(@"
            INSERT INTO KOT_Master
            (Table_No,KOT_No,KOT_Date,IsPrinted,IsClosed,
             IsRunning,KOTTime,total,Gstper,Grandtotal,order_type)
            OUTPUT INSERTED.KOT_ID
            VALUES
            (@Table,@KOT,GETUTCDATE(),@Print,0,1,
             @Time,@Total,@GST,@Grand,@Type)",
                cl.con, tran);

            cmdKot.Parameters.AddWithValue("@Table", tableNo);
            cmdKot.Parameters.AddWithValue("@KOT", kotNo);
            cmdKot.Parameters.AddWithValue("@Print", isPrint);
            cmdKot.Parameters.AddWithValue("@Time", dateTime.ToString("hh:mm tt"));
            cmdKot.Parameters.AddWithValue("@Total", total);
            cmdKot.Parameters.AddWithValue("@GST", gst);
            cmdKot.Parameters.AddWithValue("@Grand", grandTotal);
            cmdKot.Parameters.AddWithValue("@Type", orderType);

            int kotId = Convert.ToInt32(cmdKot.ExecuteScalar());

            foreach (DataRow r in kotDT.Rows)
            {
                SqlCommand cmdItem = new SqlCommand(@"
                INSERT INTO KOT_Detail
                (KOT_ID,ItemName,Rate,Qty,Amount,sku,gst_per)
                VALUES
                (@ID,@Item,@Rate,@Qty,@Amt,@SKU,@GST)",
                    cl.con, tran);

                cmdItem.Parameters.AddWithValue("@ID", kotId);
                cmdItem.Parameters.AddWithValue("@Item", r["ItemName"]);
                cmdItem.Parameters.AddWithValue("@Rate", r["Rate"]);
                cmdItem.Parameters.AddWithValue("@Qty", r["Qty"]);
                cmdItem.Parameters.AddWithValue("@Amt", r["Amount"]);
                cmdItem.Parameters.AddWithValue("@SKU", r["SKU"]);
                cmdItem.Parameters.AddWithValue("@GST", r["GST"]);

                cmdItem.ExecuteNonQuery();

                r["IsSaved"] = 1;
            }

            tran.Commit();               
        }
        catch
        {
            tran.Rollback();
            throw;
        }
        finally
        {
            cl.con.Close();
        }
    }

    private void SaveKOT(bool isPrint)
    {
        if (Session["BillTable"] == null) return;
        DataTable dt = (DataTable)Session["BillTable"];
        if (dt.Rows.Count == 0) return;

        string tableNo = hfTableNo.Value;
        string kotNo = GenerateKOTNo();
        decimal kotTotal = 0;
        decimal kotGST = 0;
        foreach (DataRow r in dt.Rows)
        {
            if (Convert.ToInt32(r["IsSaved"]) == 1)
                continue;

            decimal amt = Convert.ToDecimal(r["Amount"]);
            decimal gstPer = r["GST"] == DBNull.Value ? 0 : Convert.ToDecimal(r["GST"]);

            kotTotal += amt;
            kotGST += Math.Round((amt * gstPer) / 100, 2);
        }
        if (kotTotal == 0) return;

        decimal kotGrandTotal = kotTotal + kotGST;

        cl.con.Open();
        using (SqlTransaction tran = cl.con.BeginTransaction())
        {
            try
            {
                SqlCommand cmdKot = new SqlCommand("INSERT INTO KOT_Master(Table_No, KOT_No, KOT_Date, IsPrinted, IsClosed, IsRunning, KOTTime, total, Gstper, Grandtotal) OUTPUT INSERTED.KOT_ID VALUES(@TableNo, @KOTNo, GETUTCDATE(), @Printed, 0, 1, @KOTTime, @total, @Gstper, @Grandtotal)",
                    cl.con, tran);

                cmdKot.Parameters.AddWithValue("@TableNo", tableNo);
                cmdKot.Parameters.AddWithValue("@KOTNo", kotNo);
                cmdKot.Parameters.AddWithValue("@Printed", isPrint);
                cmdKot.Parameters.AddWithValue("@KOTTime", dateTime.ToString("hh:mm tt"));
                cmdKot.Parameters.AddWithValue("@total", kotTotal);
                cmdKot.Parameters.AddWithValue("@Gstper", kotGST);
                cmdKot.Parameters.AddWithValue("@Grandtotal", kotGrandTotal);

                int kotId = Convert.ToInt32(cmdKot.ExecuteScalar());

                foreach (DataRow r in dt.Rows)
                {
                    if (Convert.ToInt32(r["IsSaved"]) == 1) continue;

                    SqlCommand cmdItem = new SqlCommand("INSERT INTO KOT_Detail(KOT_ID, ItemName, Rate, Qty, Amount, sku, gst_per) VALUES (@KOT_ID, @Item, @Rate, @Qty, @Amount, @SKU, @gst)",
                        cl.con, tran);

                    cmdItem.Parameters.AddWithValue("@KOT_ID", kotId);
                    cmdItem.Parameters.AddWithValue("@Item", r["ItemName"]);
                    cmdItem.Parameters.AddWithValue("@Rate", r["Rate"]);
                    cmdItem.Parameters.AddWithValue("@Qty", r["Qty"]);
                    cmdItem.Parameters.AddWithValue("@Amount", r["Amount"]);
                    cmdItem.Parameters.AddWithValue("@SKU", r["SKU"]);
                    cmdItem.Parameters.AddWithValue("@gst", r["GST"]);

                    cmdItem.ExecuteNonQuery();

                    r["IsSaved"] = 1;
                }

                tran.Commit();
            }
            catch
            {
                try { tran.Rollback(); } catch { }
                throw;
            }
        }
        BindGrid(0);
        CalculateBill();
        if (isPrint)
        {
            Response.Redirect("Print_KOT.aspx?table_no=" + tableNo + "&kotno=" + kotNo);
            return;
        }                       
        Response.Redirect("Dashboard.aspx");
    }

    private string GenerateKOTNo()
    {
        SqlCommand cmd = new SqlCommand("SELECT ISNULL(MAX(CAST(KOT_No AS INT)), 0) + 1 FROM KOT_Master", cl.con);

        cl.con.Open();
        int nextNo = Convert.ToInt32(cmd.ExecuteScalar());
        cl.con.Close();

        return nextNo.ToString("000");
    }
    protected void btnSave_Click(object sender, EventArgs e)
    {
        SaveFinalBill(false);
    }

    protected void btnSavePrint_Click(object sender, EventArgs e)
    {
        SaveFinalBill(true);
    }
    private string GenerateBillNo(string prefix)
    {
        int nextNo;
        using (SqlCommand cmd = new SqlCommand("SELECT ISNULL(MAX(CAST(RIGHT(Bill_No,5) AS INT)),0) FROM Bill_Master WHERE Bill_No LIKE @p + '%'", cl.con))
        {
            cmd.Parameters.AddWithValue("@p", prefix);
            cl.con.Open();
            nextNo = (int)cmd.ExecuteScalar() + 1;
            cl.con.Close();
        }
        return prefix + nextNo.ToString().PadLeft(5, '0');
    }

    private void SaveFinalBill(bool isPrint)
    {
        if (Session["BillTable"] == null) return;

        DataTable dt = (DataTable)Session["BillTable"];
        if (dt.Rows.Count == 0) return;

        DataRow[] foodRows = dt.Select(
            "GroupName IN ('FOODING','BEVERAGE','COMPL')");

        DataRow[] barRows = dt.Select(
            "GroupName = 'BAR'");

        string foodBillNo = SaveBillByGroup(foodRows, "FOOD");
        string barBillNo = SaveBillByGroup(barRows, "BAR");

        if (!string.IsNullOrEmpty(foodBillNo))
        {
            using (SqlCommand cmd = new SqlCommand("UPDATE KOT_Master SET IsClosed = 1, billno = @billno WHERE Table_No = @t        AND IsClosed = 0 AND order_type = 'FOOD'", cl.con))
            {
                cmd.Parameters.AddWithValue("@billno", foodBillNo);
                cmd.Parameters.AddWithValue("@t", hfTableNo.Value);

                cl.con.Open();
                cmd.ExecuteNonQuery();
                cl.con.Close();
            }
        }
        if (!string.IsNullOrEmpty(barBillNo))
        {
            using (SqlCommand cmd = new SqlCommand("UPDATE KOT_Master SET IsClosed = 1, billno = @billno WHERE Table_No = @t        AND IsClosed = 0 AND order_type = 'BAR'", cl.con))
            {
                cmd.Parameters.AddWithValue("@billno", barBillNo);
                cmd.Parameters.AddWithValue("@t", hfTableNo.Value);

                cl.con.Open();
                cmd.ExecuteNonQuery();
                cl.con.Close();
            }
        }
        dt.Clear();
        Session["BillTable"] = dt;
        gvBill.DataSource = dt;
        gvBill.DataBind();
        if (isPrint)
        {
            string url = "Restaurant_Billing.aspx?"
             + "food=" + Server.UrlEncode(foodBillNo)
             + "&bar=" + Server.UrlEncode(barBillNo)
             + "&tableno=" + Server.UrlEncode(hfTableNo.Value);

            string script = "window.location.href = '" + url + @"';"; ClientScript.RegisterStartupScript(this.GetType(), "print",
                script, true );

        }
        else
        {
            Response.Redirect("Dashboard.aspx");
        }

    }

    private string SaveBillByGroup(DataRow[] rows, string billType)
    {
        if (rows == null || rows.Length == 0)
            return string.Empty;

        DataTable billDT = rows.CopyToDataTable();

        decimal subTotal = 0;
        decimal tax = 0;

        foreach (DataRow r in billDT.Rows)
        {
            decimal amt = Convert.ToDecimal(r["Amount"]);
            decimal gst = r["GST"] == DBNull.Value ? 0 : Convert.ToDecimal(r["GST"]);

            subTotal += amt;
            tax += Math.Round((amt * gst) / 100, 2);
        }
        decimal discountAmount = 0;
        decimal discountPer = 0;

        if (billType == "FOOD")
        {
            decimal.TryParse(txtdiscount.Text, out discountPer);
            if (discountPer > 40) discountPer = 40;

            discountAmount = Math.Round((subTotal * discountPer) / 100, 2);
        }
        decimal exactTotal = subTotal - discountAmount + tax;
        decimal grandTotal = Math.Round(exactTotal);
        decimal roundOff = grandTotal - exactTotal;

        string billNo = billType == "FOOD" ? GenerateBillNo("FR") : GenerateBillNo("BR");

        string tableNo = hfTableNo.Value;

        cl.con.Open();
        SqlTransaction tran = cl.con.BeginTransaction();

        try
        {
            SqlCommand cmdBill = new SqlCommand("INSERT INTO Bill_Master (Bill_No,Table_No,SubTotal,Tax,GrandTotal,PaidAmount,       ReturnAmount,PaymentMode,IsPaid,IsRunning,billTime, Discount,DeliveryCharge,Bill_date,RoundOff,Status,         order_type,insuser,insdate,instime,insyear) OUTPUT INSERTED.Bill_ID VALUES  (@BillNo,@TableNo,@SubTotal,@Tax,@GrandTotal,@Paid, @Return,@PayMode,@IsPaid,1,@billTime, @Discount,@DeliveryCharge,GETUTCDATE(),@RoundOff,@Status, @order_type,@insuser,@insdate,@instime,@insyear)", cl.con, tran);

            cmdBill.Parameters.AddWithValue("@BillNo", billNo);
            cmdBill.Parameters.AddWithValue("@TableNo", tableNo);
            cmdBill.Parameters.AddWithValue("@SubTotal", subTotal);
            cmdBill.Parameters.AddWithValue("@Tax", tax);
            cmdBill.Parameters.AddWithValue("@GrandTotal", grandTotal);
            cmdBill.Parameters.AddWithValue("@Paid",
                string.IsNullOrEmpty(txtCustomerPaid.Text) ? 0 : Convert.ToDecimal(txtCustomerPaid.Text));
            cmdBill.Parameters.AddWithValue("@Return", lblReturn.Text);
            cmdBill.Parameters.AddWithValue("@PayMode",
                rbCash.Checked ? "CASH" :
                rbCard.Checked ? "CREDIT" :
                rbUPI.Checked ? "UPI" : "OTHER");
            cmdBill.Parameters.AddWithValue("@IsPaid", chkPaid.Checked);
            cmdBill.Parameters.AddWithValue("@billTime", DateTime.Now.ToString("hh:mm tt"));
            cmdBill.Parameters.AddWithValue("@Discount", discountAmount);
            cmdBill.Parameters.AddWithValue("@DeliveryCharge", txtdilivery.Text);
            cmdBill.Parameters.AddWithValue("@RoundOff", roundOff);
            cmdBill.Parameters.AddWithValue("@Status", chkPaid.Checked ? "SUCCESS" : "PENDING");
            cmdBill.Parameters.AddWithValue("@order_type", billType);
            cmdBill.Parameters.AddWithValue("@insuser", lgdcookie["UserName"]);
            cmdBill.Parameters.AddWithValue("@insdate", DateTime.Now.ToString("yyyy-MM-dd"));
            cmdBill.Parameters.AddWithValue("@instime", DateTime.Now.ToString("hh:mm:ss tt"));
            cmdBill.Parameters.AddWithValue("@insyear", DateTime.Now.ToString("yyyy"));

            int billId = Convert.ToInt32(cmdBill.ExecuteScalar());

            foreach (DataRow r in billDT.Rows)
            {
                SqlCommand cmdItem = new SqlCommand("INSERT INTO Bill_Detail (Bill_ID,ItemName,Rate,Qty,Amount,sku,gst_per) VALUES  (@BillID,@Item,@Rate,@Qty,@Amount,@sku,@gst)", cl.con, tran);

                cmdItem.Parameters.AddWithValue("@BillID", billId);
                cmdItem.Parameters.AddWithValue("@Item", r["ItemName"]);
                cmdItem.Parameters.AddWithValue("@Rate", r["Rate"]);
                cmdItem.Parameters.AddWithValue("@Qty", r["Qty"]);
                cmdItem.Parameters.AddWithValue("@Amount", r["Amount"]);
                cmdItem.Parameters.AddWithValue("@sku", r["SKU"]);
                cmdItem.Parameters.AddWithValue("@gst", r["GST"]);
                cmdItem.ExecuteNonQuery();
            }
            tran.Commit();
            return billNo;
        }
        catch
        {
            tran.Rollback();
            throw;
        }
        finally
        {
            cl.con.Close();
        }
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        Response.Redirect("Dashboard.aspx");
    }
}