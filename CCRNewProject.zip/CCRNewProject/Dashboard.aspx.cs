﻿using System;
using System.Activities.Expressions;
using System.Activities.Statements;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Dashboard : System.Web.UI.Page
{
    Class1 cl = new Class1();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            BindTables();
        }
    }
    void BindTables()
    {
        DataTable dt = new DataTable();
        cl.con.Open();
        string query = @"SELECT t.Table_no,
    DATEDIFF(
        MINUTE,
        CAST(CAST(DATEADD(MINUTE, 330, GETUTCDATE()) AS DATE) AS DATETIME)
        + CAST(k.KOTTime AS DATETIME),
        DATEADD(MINUTE, 330, GETUTCDATE())
    ) AS RunningMinutes,

    CASE 
        WHEN b.Bill_ID IS NOT NULL THEN b.GrandTotal
        WHEN k.KOT_ID IS NOT NULL THEN k.total
        ELSE 0
    END AS TotalAmount,

    b.bill_no,
    k.KOT_no,
    b.Bill_ID,

    CASE 
        WHEN b.Bill_ID IS NOT NULL THEN 2      
        WHEN k.KOT_ID IS NOT NULL THEN 1       
        ELSE 0                                 
    END AS TableStatus

FROM Table_Master t
LEFT JOIN
(
    SELECT 
        Table_No,
        MIN(KOTTime) AS KOTTime,
        SUM(grandtotal) AS total,
        MAX(KOT_ID) AS KOT_ID,
        MAX(KOT_No) AS KOT_no
    FROM KOT_Master
    WHERE IsClosed = 0
    GROUP BY Table_No
) k ON t.Table_no = k.Table_No
LEFT JOIN Bill_Master b 
    ON t.Table_no = b.Table_No
    AND b.IsRunning = 1
    AND ISNULL(b.IsPaid,0) = 0   
WHERE t.Useflag = 1
ORDER BY t.Table_no;
";
        SqlDataAdapter da = new SqlDataAdapter(query, cl.con);
        da.Fill(dt);
        cl.con.Close();
        rptBoxes.DataSource = dt;
        rptBoxes.DataBind();
    }
    protected void rptBoxes_ItemCommand(object source, RepeaterCommandEventArgs e)
    {
        if (e.CommandName == "SelectTable")
        {
            Response.Redirect("Billing.aspx?table_no=" + e.CommandArgument);
        }

        else if (e.CommandName == "PrintBill")
        {
            string[] args = e.CommandArgument.ToString().Split('|');

            if (args.Length < 3) return;  

            string tableNo = args[0];
            string no = args[1];          
            int tableStatus = Convert.ToInt32(args[2]);

            if (tableStatus == 1)
            {
                Response.Redirect("Print_KOT.aspx?table_no=" + tableNo + "&kotno=" + no);
            }
            else if (tableStatus == 2)
            {
                Response.Redirect("Restaurant_Billing.aspx?billno=" + no + "&tableno=" + tableNo);
            }
        }

        else if (e.CommandName == "ViewBill")
        {
            Response.Redirect("Billing.aspx?table_no=" + e.CommandArgument + "&view=1");
        }

    }



}