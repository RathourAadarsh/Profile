﻿using System;
using System.Activities.Expressions;
using System.Activities.Statements;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.UI;

using System.Web.UI.WebControls;

public partial class Dashboard : System.Web.UI.Page
{
    Class1 cl = new Class1();
    public static TimeZoneInfo timeZoneInfo = TimeZoneInfo.FindSystemTimeZoneById("India Standard Time");
    public static DateTime dateTime;
    HttpCookie lgdcookie;
    protected void Page_Load(object sender, EventArgs e)
    {
        lgdcookie = Request.Cookies["loggeduser"];
        dateTime = TimeZoneInfo.ConvertTime(DateTime.Now, timeZoneInfo);
        if (!IsPostBack)
        {
            BindTables();
            LoadHoldTables();
            BindClearHoldTables();
        }
    }
    void BindTables()
    {
        DataTable dt = new DataTable();
        cl.con.Open();
        string query = @"SELECT t.Table_no, DATEDIFF(MINUTE,CAST(CAST(DATEADD(MINUTE, 330, GETUTCDATE()) AS DATE) AS DATETIME)
        + CAST(k.KOTTime AS DATETIME),
        DATEADD(MINUTE, 330, GETUTCDATE())
    ) AS RunningMinutes,
    CASE 
        WHEN b.TotalBill IS NOT NULL THEN b.TotalBill
        WHEN k.KOT_ID IS NOT NULL THEN k.total
        ELSE 0 
    END AS TotalAmount,
    b.BillNos,
    k.KOT_no,
    b.MaxBillID,
    CASE 
        WHEN b.MaxBillID IS NOT NULL THEN 2
        WHEN k.KOT_ID IS NOT NULL THEN 1
        ELSE 0 
    END AS TableStatus
FROM Table_Master t
LEFT JOIN (
    SELECT 
        km.Table_No,
        MIN(km.KOTTime) AS KOTTime,
        SUM(km.grandtotal) AS total,
        MAX(km.KOT_ID) AS KOT_ID,
        STUFF((
            SELECT ', ' + km2.KOT_No
            FROM KOT_Master km2
            WHERE km2.Table_No = km.Table_No
              AND km2.IsClosed = 0
            FOR XML PATH(''), TYPE
        ).value('.', 'NVARCHAR(MAX)'), 1, 2, '') AS KOT_no
    FROM KOT_Master km
    WHERE km.IsClosed = 0
    GROUP BY km.Table_No
) k ON t.Table_no = k.Table_No
LEFT JOIN (
    SELECT 
        bm.Table_No,
        SUM(bm.GrandTotal) AS TotalBill,
        MAX(bm.Bill_ID) AS MaxBillID,
        STUFF((
            SELECT ', ' + bm2.bill_no
            FROM Bill_Master bm2
            WHERE bm2.Table_No = bm.Table_No
              AND bm2.IsRunning = 1
              AND ISNULL(bm2.IsPaid,0) = 0
            FOR XML PATH(''), TYPE
        ).value('.', 'NVARCHAR(MAX)'), 1, 2, '') AS BillNos
    FROM Bill_Master bm
    WHERE bm.IsRunning = 1 and isdayclosed = 0
      AND ISNULL(bm.IsPaid,0) = 0
    GROUP BY bm.Table_No
) b ON t.Table_no = b.Table_No
WHERE t.Useflag = 1
ORDER BY t.Table_no";
        SqlDataAdapter da = new SqlDataAdapter(query, cl.con);
        da.Fill(dt);
        cl.con.Close();
        rptBoxes.DataSource = dt;
        rptBoxes.DataBind();
    }
    protected void rptBoxes_ItemCommand(object source, RepeaterCommandEventArgs e)
    {
        if (e.CommandName == "SelectTable")
        {
            string[] args = e.CommandArgument.ToString().Split('|');
            string tableNo = args[0];
            int tableStatus = 0;
            if (args.Length > 1)
            {
                tableStatus = Convert.ToInt32(args[1]);
            }
            if (tableStatus == 2)
            {
                return;
            }
            Response.Redirect("Billing.aspx?table_no=" + tableNo);
        }
        else if (e.CommandName == "PrintBill")
        {
            string[] args = e.CommandArgument.ToString().Split('|');
            if (args.Length < 3) return;

            string tableNo = args[0];
            string kotNo1 = args[1]; 
            string[] parts = kotNo1.Split(',');

            for (int i = 0; i < parts.Length; i++)
            {
                parts[i] = parts[i].Trim();
            }
            string kotNo = parts[parts.Length - 1];
            string billNos = args[1];
            int tableStatus = Convert.ToInt32(args[2]);
            if (tableStatus == 1)
            {

                DataTable dt = new DataTable();
                string query = "SELECT ig.subpgroupname, bd.itemname, bd.rate, bd.qty, bd.amount, bm.total, bm.gstper, bm.grandtotal, bm.KOT_No, CONVERT(nvarchar,bm.KOT_Date,103) AS KOT_Date FROM KOT_Master bm LEFT JOIN KOT_Detail bd ON bm.KOT_ID = bd.KOT_ID LEFT JOIN item_detail id ON bd.sku = id.sku INNER JOIN Item_group_Master ig ON id.Item_group_name = ig.item_g_id WHERE bm.KOT_No=@KOTNo AND bm.table_no=@TableNo AND bm.isrunning = 1 ORDER BY ig.subpgroupname,bd.itemname";

                using (SqlCommand cmd = new SqlCommand(query, cl.con))
                {
                    cmd.Parameters.AddWithValue("@KOTNo", kotNo);
                    cmd.Parameters.AddWithValue("@TableNo", tableNo);

                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    da.Fill(dt);
                }

                if (dt.Rows.Count == 0) return;
                string html = "<div style='width:3.3in; font-family:Arial,sans-serif; font-size:12px;'>";
                html += "<h4 style='text-align:center; font-family:cursive; font-size:22px; font-weight:900; margin-bottom:-5px;'>Charans Club & Resorts</h4>";
                html += "<h4 style='text-align:center; font-size:14px; font-weight:550;margin-bottom:5px;'>KOT</h4>";
                html += "<table style='width:100%; font-size:12px; margin-bottom:2px;margin-top:2px;border-top: 1px solid black;'>";
                html += "<tr><td>KOT No.: " + dt.Rows[0]["KOT_No"] + "</td>";
                html += "<td style='text-align:center;'>Table No.: " + tableNo + "</td>";
                html += "<td style='text-align:right;'>Date: " + dt.Rows[0]["KOT_Date"] + "</td></tr></table>";
                html += "<table border='0' cellspacing='0' cellpadding='3' style='width:100%; border-collapse:collapse;'>";
                html += "<tr style='background-color:#e5ded8; font-weight:bold;'><th style='text-align:left;'>Item Name</th><th style='text-align:right;'>Qty</th></tr>";

                string lastGroup = "";
                int totalQty = 0;
                foreach (DataRow row in dt.Rows)
                {
                    if (row["subpgroupname"].ToString() != lastGroup)
                    {
                        html += "<tr><td colspan='2' style='background-color:#f0f0f0; font-weight:bold;font-size:14px; padding:3px;'>"
                            + row["subpgroupname"].ToString().ToUpper() + "</td></tr>";
                        lastGroup = row["subpgroupname"].ToString();
                    }

                    html += "<tr>";
                    html += "<td>" + row["itemname"] + "</td>";
                    html += "<td style='text-align:right;'>" + row["qty"] + "</td>";
                    html += "</tr>";

                    totalQty += Convert.ToInt32(row["qty"]);
                }
                html += "<tr style='border-top:1px solid black;border-bottom:1px solid black; font-weight:bold;'>";
                html += "<td>Total Qty:</td><td style='text-align:right;'>" + totalQty + "</td></tr>";
                html += "</table>";
                html += "</div>";
                string safeHtml = HttpUtility.JavaScriptStringEncode(html);

                string script = "directPrint('" + safeHtml + "');";
                ScriptManager.RegisterStartupScript(
                    this,
                    this.GetType(),
                    "DirectPrint",
                    script,
                    true
                );
            }
            else if (tableStatus == 2)
            {
                string foodBillNo = "";
                string barBillNo = "";

                if (!string.IsNullOrEmpty(billNos))
                {
                    string[] bills = billNos.Split(',');

                    foreach (string b in bills)
                    {
                        string bill = b.Trim();
                        if (bill.StartsWith("FR"))
                            foodBillNo = bill;
                        else if (bill.StartsWith("BR"))
                            barBillNo = bill;
                    }
                }

                string url = "Restaurant_Billing.aspx?" + "food=" + Server.UrlEncode(foodBillNo) + "&bar=" + Server.UrlEncode(barBillNo) + "&tableno=" + Server.UrlEncode(tableNo) + "&from=dashboard";  
                Response.Redirect(url);

            }

        }
        else if (e.CommandName == "SettleBill")
        {
            string billNo = e.CommandArgument.ToString();
            SqlCommand cmd = new SqlCommand("update tbl_generatebill set IsSettled = 1 where Bill_No = @BillNo", cl.con);
            cmd.Parameters.AddWithValue("@BillNo", billNo);
            cl.con.Open();
            cmd.ExecuteNonQuery();
            cl.con.Close();

            ClientScript.RegisterStartupScript(
                this.GetType(),
                "alert",
                "savealert('Bill settled successfully','success');",
                true
            );
            BindTables();
        }
        else if (e.CommandName == "ViewBill")
        {
            Response.Redirect("Billing.aspx?table_no=" + e.CommandArgument + "&view=1");
        }


    }
    protected void rptHoldTables_ItemCommand(object source, RepeaterCommandEventArgs e)
    {
        if (e.CommandName == "HoldThis")
        {
            string kotNo = e.CommandArgument.ToString();
            SqlCommand cmd = new SqlCommand("update KOT_Master set isclosed = 1 where KOT_no=@KOTNo",cl.con);
            cmd.Parameters.AddWithValue("@KOTNo", kotNo);
            cl.con.Open();
            cmd.ExecuteNonQuery();
            cl.con.Close();
            BindTables();
            LoadHoldTables();

            ScriptManager.RegisterStartupScript(
                this,
                this.GetType(),
                "ReopenModal",
                "var modal = new bootstrap.Modal(document.getElementById('holdModal')); modal.show();",
                true
            );
        }
    }

    void LoadHoldTables()
    {
        SqlDataAdapter da = new SqlDataAdapter("SELECT Table_No,STUFF((SELECT ', ' + KOT_No FROM KOT_Master km2 WHERE km2.Table_No = km1.Table_No AND km2.IsClosed = 0 FOR XML PATH(''), TYPE).value('.', 'NVARCHAR(MAX)'), 1, 2, '') AS KOT_Numbers, SUM(grandtotal) AS TableTotal FROM KOT_Master km1 WHERE km1.IsClosed = 0 GROUP BY Table_No ORDER BY Table_No", cl.con);
        DataTable dt = new DataTable();
        da.Fill(dt);
        rptHoldTables.DataSource = dt;
        rptHoldTables.DataBind();
    }

    protected void btnConfirmSettle_Click(object sender, EventArgs e)
    {
        try
        {
            string billNo = hfBillNo.Value;
            string tableNo = hfTableNo.Value;
            if (string.IsNullOrEmpty(billNo) || string.IsNullOrEmpty(tableNo))
            {
                ScriptManager.RegisterStartupScript(
                    this, this.GetType(),
                    "Script",
                    "savealert('Invalid bill or table','warning');",
                    true
                );
                return;
            }

            decimal cash = chkCash.Checked && txtCash.Text != "" ? Convert.ToDecimal(txtCash.Text) : 0;
            decimal card = chkCard.Checked && txtCard.Text != "" ? Convert.ToDecimal(txtCard.Text) : 0;
            decimal upi = chkUPI.Checked && txtUPI.Text != "" ? Convert.ToDecimal(txtUPI.Text) : 0;
            decimal credit = chkCredit.Checked && txtCredit.Text != "" ? Convert.ToDecimal(txtCredit.Text) : 0;
            string paymentMode = "CASH";

            int count =
                (cash > 0 ? 1 : 0) +
                (card > 0 ? 1 : 0) +
                (upi > 0 ? 1 : 0) +
                (credit > 0 ? 1 : 0);

            if (credit > 0)
                paymentMode = "CREDIT";
            else if (count > 1)
                paymentMode = "MIX";
            else if (card > 0)
                paymentMode = "CARD";
            else if (upi > 0)
                paymentMode = "UPI";

            if (chkCredit.Checked)
            {
                string mobile = txtMobile.Text.Trim();

                if (txtCustName.Text.Trim() == "" || mobile == "")
                {
                    ScriptManager.RegisterStartupScript(
                        this, this.GetType(), "Script",
                        "savealert('Credit ke liye Name aur Mobile zaruri hai','warning');",
                        true);
                    return;
                }
                if (!System.Text.RegularExpressions.Regex.IsMatch(mobile, @"^\d{10}$"))
                {
                    ScriptManager.RegisterStartupScript(
                        this, this.GetType(), "Script",
                        "savealert('Mobile number 10 digit ka hona chahiye','warning');",
                        true);
                    return;
                }
            }
            decimal billAmount = Convert.ToDecimal(hfBillAmount.Value);
            decimal tip = txttip.Text != "" ? Convert.ToDecimal(txttip.Text) : 0;
            decimal totalPaid = cash + card + upi + credit;

            if (totalPaid + tip != billAmount)
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "Script", "savealert('Paid amount bill total se match nahi ho raha','warning');", true);
                return;
            }

            cl.con.Open();
            string[] billArr = billNo.Split(',');
            foreach (string b in billArr)
            {
                string singleBillNo = b.Trim();
                SqlCommand getAmt = new SqlCommand("SELECT GrandTotal FROM bill_master WHERE bill_no=@bill AND table_no=@table",
                    cl.con);
                getAmt.Parameters.AddWithValue("@bill", singleBillNo);
                getAmt.Parameters.AddWithValue("@table", tableNo);
                decimal singleBillAmount = Convert.ToDecimal(getAmt.ExecuteScalar());
                decimal cashAmt = 0, cardAmt = 0, upiAmt = 0, creditAmt = 0;

                if (chkCash.Checked) cashAmt = singleBillAmount;
                if (chkCard.Checked) cardAmt = singleBillAmount;
                if (chkUPI.Checked) upiAmt = singleBillAmount;
                if (chkCredit.Checked) creditAmt = singleBillAmount;
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = cl.con;
                cmd.CommandText = "update bill_master set CashAmount = @casha,CardAmount = @carda, UpiAmount = @upia,CreditAmount = @credita, Tip = @tip,CustName = @cname,CustMobile = @mobile,ispaid = 1,Status = 'SUCCESS',order_type = 'Dine In',upduser = @upduser ,upddate = @upddate ,updtime = @updtime, cash = @IsCash,card = @IsCard,upi = @IsUpi, credit = @IsCredit,PaymentMode = @PaymentMode where bill_no = @bill and table_no = @table";

                cmd.Parameters.AddWithValue("@bill", singleBillNo);
                cmd.Parameters.AddWithValue("@table", tableNo);

                cmd.Parameters.AddWithValue("@casha", cashAmt);
                cmd.Parameters.AddWithValue("@carda", cardAmt);
                cmd.Parameters.AddWithValue("@upia", upiAmt);
                cmd.Parameters.AddWithValue("@credita", creditAmt);

                cmd.Parameters.AddWithValue("@tip", tip);
                cmd.Parameters.AddWithValue("@PaymentMode", paymentMode);
                cmd.Parameters.AddWithValue("@cname", txtCustName.Text);
                cmd.Parameters.AddWithValue("@mobile", txtMobile.Text);
                cmd.Parameters.AddWithValue("@upduser", lgdcookie["UserName"].ToString());
                cmd.Parameters.AddWithValue("@upddate", dateTime.ToString("yyyy-MM-dd"));
                cmd.Parameters.AddWithValue("@updtime", dateTime.ToString("hh:mm:ss tt"));

                cmd.Parameters.AddWithValue("@IsCash", chkCash.Checked ? 1 : 0);
                cmd.Parameters.AddWithValue("@IsCard", chkCard.Checked ? 1 : 0);
                cmd.Parameters.AddWithValue("@IsUpi", chkUPI.Checked ? 1 : 0);
                cmd.Parameters.AddWithValue("@IsCredit", chkCredit.Checked ? 1 : 0);

                cmd.ExecuteNonQuery();
            }

            cl.con.Close();

            string foodBillNo = "";
            string barBillNo = "";

            string[] billArr1 = billNo.Split(',');

            foreach (string b in billArr1)
            {
                string singleBill = b.Trim();

                if (singleBill.StartsWith("FR"))
                    foodBillNo = singleBill;
                else if (singleBill.StartsWith("BR"))
                    barBillNo = singleBill;
            }

            string url = "Restaurant_Billing.aspx?"
                + "food=" + Server.UrlEncode(foodBillNo)
                + "&bar=" + Server.UrlEncode(barBillNo)
                + "&tableno=" + Server.UrlEncode(tableNo)
                + "&from=dashboard"
                + "&copy=office";   

            Response.Redirect(url);

        }
        catch (Exception ex)
        {

        }
    }

    protected void btnDayClose_Click(object sender, EventArgs e)
    {
        DateTime businessDate = dateTime.Date;

        SqlCommand chk = new SqlCommand("SELECT COUNT(*) FROM Day_Close WHERE BusinessDate=@d", cl.con);
        chk.Parameters.AddWithValue("@d", businessDate);
        cl.con.Open();
        int exists = (int)chk.ExecuteScalar();
        cl.con.Close();

        if (exists > 0)
        {
            ScriptManager.RegisterStartupScript(this, GetType(), "msg", "savealert('Day already closed','warning');", true);
            return;
        }

        SqlCommand cmd = new SqlCommand("INSERT INTO Day_Close (BusinessDate,ClosedBy,CloseTime,IsAuto, TotalSales,CashTotal,CardTotal,UPITotal,CreditTotal) SELECT @d,@user,GETUTCDATE(),0, SUM(GrandTotal),SUM(CashAmount), SUM(CardAmount),SUM(UpiAmount), SUM(CreditAmount) FROM Bill_Master WHERE BusinessDate=@d AND IsPaid=1", cl.con);
        cmd.Parameters.AddWithValue("@d", businessDate);
        cmd.Parameters.AddWithValue("@user", lgdcookie["UserName"]);
        cl.con.Open();
        cmd.ExecuteNonQuery();
        SqlCommand lockBills = new SqlCommand("UPDATE Bill_Master SET IsDayClosed=1 WHERE BusinessDate=@d", cl.con);
        lockBills.Parameters.AddWithValue("@d", businessDate);
        lockBills.ExecuteNonQuery();

        cl.con.Close();

        ScriptManager.RegisterStartupScript(this, GetType(), "msg", "savealert('Day Closed Successfully','success');", true);
    }

    protected void btnHoldKOT_Click(object sender, EventArgs e)
    {
        string kotNumbers = hfHoldKOT.Value;
        if (string.IsNullOrEmpty(kotNumbers)) return;

        string[] kotArr = kotNumbers.Split(',');
        string firstKot = kotArr[0].Trim();

        cl.con.Open();

        // 🔹 Step 1: Table number nikalo
        SqlCommand getTable = new SqlCommand(
            "SELECT Table_No FROM KOT_Master WHERE KOT_No=@KOTNo",
            cl.con);
        getTable.Parameters.AddWithValue("@KOTNo", firstKot);

        object result = getTable.ExecuteScalar();

        if (result == null)
        {
            cl.con.Close();
            return;
        }

        string tableNo = result.ToString();
        if (string.IsNullOrEmpty(tableNo))
        {
            cl.con.Close();
            return;
        }

        // 🔹 Step 2: Check karo already hold hai kya
        SqlCommand checkCmd = new SqlCommand(
            "SELECT COUNT(*) FROM KOT_Master WHERE Table_No=@TableNo AND IsClosed=2",
            cl.con);
        checkCmd.Parameters.AddWithValue("@TableNo", tableNo);

        int alreadyHold = (int)checkCmd.ExecuteScalar();

        if (alreadyHold > 0)
        {
            cl.con.Close();

            ScriptManager.RegisterStartupScript(
                this,
                this.GetType(),
                "alert",
                "savealert('Table already on hold. First clear previous hold.','warning');",
                true
            );
            return; 
        }
        foreach (string kot in kotArr)
        {
            SqlCommand cmd = new SqlCommand("UPDATE KOT_Master SET IsClosed = 2 WHERE KOT_No=@KOTNo",
                cl.con);
            cmd.Parameters.AddWithValue("@KOTNo", kot.Trim());
            cmd.ExecuteNonQuery();
        }

        cl.con.Close();

        BindTables();
        LoadHoldTables();
        BindClearHoldTables();

        ScriptManager.RegisterStartupScript(
            this,
            this.GetType(),
            "alert",
            "savealert('KOT held successfully','success');",
            true
        );
    }


    private void BindClearHoldTables()
    {
        string query = @" SELECT 
        km1.Table_No,
        STUFF((
            SELECT ', ' + km2.KOT_No
            FROM KOT_Master km2
            WHERE km2.Table_No = km1.Table_No
              AND km2.IsClosed = 2
            FOR XML PATH(''), TYPE
        ).value('.', 'NVARCHAR(MAX)'), 1, 2, '') AS KOT_Numbers,
        SUM(km1.grandtotal) AS TableTotal
    FROM KOT_Master km1
    WHERE km1.IsClosed = 2
    GROUP BY km1.Table_No
    ORDER BY km1.Table_No";

        SqlDataAdapter da = new SqlDataAdapter(query, cl.con);
        DataTable dt = new DataTable();
        da.Fill(dt);

        rptClearHoldTables.DataSource = dt;
        rptClearHoldTables.DataBind();
    }
    protected void btnClearKOT_Click(object sender, EventArgs e)
    {
        string tableNo = hfTableNo1.Value;   
        if (!string.IsNullOrEmpty(tableNo))
        {
            Response.Redirect("Billing.aspx?table_no=" + tableNo + "&mode=hold");
        }
    }

}