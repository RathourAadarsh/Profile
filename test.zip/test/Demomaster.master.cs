﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Demomaster : System.Web.UI.MasterPage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        constr = "Data Source=SQL5098.site4now.net;Initial Catalog=db_a826a6_ccr;User Id=db_a826a6_ccr_admin;Password=ccr#159@!";
    }
}
