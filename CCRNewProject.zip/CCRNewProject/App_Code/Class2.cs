﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
//using System.Web.Security;
//using System.Web.UI;
//using System.Web.UI.HtmlControls;
//using System.Web.UI.WebControls;
//using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;

/// <summary>
/// Summary description for Class2
/// </summary>
public class Class2
{
    public SqlConnection con = new SqlConnection();
    SqlCommand cmd = new SqlCommand();
    //SqlDataReader dr = new SqlDataReader();
    public string constr;
	public Class2()
	{
        constr = "Data Source=DESKTOP-2F9M65R\\MSSQLSERVER12;Initial Catalog=CCRNEWProject;Integrated Security=True;"; 
        //constr = "Data Source=DESKTOP-MF3AF50\\SQLEXPRESS;Initial Catalog=CCRNEWProject;Integrated Security=True;"; 



        cb = new System.Data.SqlClient.SqlCommandBuilder(adp);
        adp.SelectCommand = new System.Data.SqlClient.SqlCommand(" ", con);
        adp.InsertCommand = new System.Data.SqlClient.SqlCommand(" ", con);
        adp.UpdateCommand = new System.Data.SqlClient.SqlCommand(" ", con);
        cmd = new System.Data.SqlClient.SqlCommand("", con);
        cmd.CommandTimeout = 0;
        con.ConnectionString = constr;
    }
    public void execute(string str)
    {
        if (con.State == ConnectionState.Open)
        {
            con.Close();
        }
        con.ConnectionString = constr;
        cmd.Connection = con;
        cmd.CommandText = str;
        cmd.CommandTimeout = 0;
        con.Open();
        cmd.ExecuteNonQuery();
        con.Close();
    }
    public string Scalar(string str)
    {
        if (con.State == ConnectionState.Open)
        {
            con.Close();
        }
        con.ConnectionString = constr;
        cmd.Connection = con;
        string   s = null;
        cmd.CommandText = str;
        con.Open();
        s = Convert.ToString(cmd.ExecuteScalar());
        con.Close();
        return s;
    }
    public SqlDataReader DataReader(string str)
    {
        SqlDataReader dr = default(SqlDataReader);
        if (con.State == ConnectionState.Open)
        {
            con.Close();
        }
        con.ConnectionString = constr;
        cmd.Connection = con;
        cmd.CommandText = str;
        cmd.CommandTimeout = 0;
        con.Open();
        dr = cmd.ExecuteReader();
        return dr;
    }
    public DataSet Dataset(string str)
    {
        SqlDataAdapter adp = new SqlDataAdapter();
        DataSet ds = new DataSet();
        if (con.State == ConnectionState.Open)
        {
            con.Close();
        }
        con.ConnectionString = constr;
        cmd.Connection = con;
        cmd.CommandText = str;
        cmd.CommandTimeout = 0;
        con.Open();
        adp.SelectCommand = cmd;
        adp.Fill(ds);
        return ds;
    }
    public DataTable DataTable(string str)
    {
        SqlDataReader dr = default(SqlDataReader);
        if (con.State == ConnectionState.Open)
        {
            con.Close();
        }
        con.ConnectionString = constr;
        cmd.Connection = con;
        cmd.CommandText = str;
        cmd.CommandTimeout = 0;
        con.Open();
        dr = cmd.ExecuteReader();
        DataTable dt = new DataTable();
        dt.Load(dr);
        return dt;
    }
    public int count(string tbname, string Fieldname, string value)
    {
        if (con.State == ConnectionState.Open)
        {
            con.Close();
        }
        int c = 0;
        con.ConnectionString = constr;
        con.Open();
        cmd.Connection = con;
        cmd.CommandText = "select count(*) from " + tbname + " where " + Fieldname + "='" + value + "'";
        c = Convert.ToInt32(cmd.ExecuteScalar());
        con.Close();
        return c;
    }
    public void update(string tblname, string fld, string user)
    {
        if (con.State == ConnectionState.Open)
        {
            con.Close();
        }
        con.ConnectionString = constr;
        con.Open();
        cmd.Connection = con;
        cmd.CommandText = "update " + tblname + " set " + fld + "=(select unit from access_permission where uname='" + user + "') where insUname='" + user + "'";
        cmd.ExecuteNonQuery();
        con.Close();
    }
    public string dtov(string d)
    {
        string n = null;
        string s = null;
        s = d;
        s = s.Replace(".", "/");
        s = s.Replace("-", "/");
        string mm = string.Empty;
        string dd = string.Empty;
        string year = string.Empty;
        int count = 0;
        int c = 0;
        for (c = 0; c <= 4; c++)
        {
            n = s.Substring(c, 1);
            if (n != "/")
            {
                mm = mm + n;
            }
            else
            {
                count = c;
                break; // TODO: might not be correct. Was : Exit For
            }
        }
        for (c = count + 1; c <= count + 5; c++)
        {
            n = s.Substring(c, 1);
            if (n != "/")
            {
                dd = dd + n;
            }
            else
            {
                count = c;
                break; // TODO: might not be correct. Was : Exit For
            }
        }
        year = s.Substring(count + 1, 4);
        string r = null;
        r = dd + "/" + mm + "/" + year;
        return r;
    }
    public string dtoyear(string d)
    {
        string n = null;
        string s = null;
        s = d;
        s = s.Replace(".", "/");
        s = s.Replace("-", "/");
        string mm = string.Empty;
        string dd = string.Empty;
        string year = string.Empty;
        int count = 0;
        int c = 0;
        for (c = 0; c <= 4; c++)
        {
            n = s.Substring(c, 1);
            if (n != "/")
            {
                mm = mm + n;
            }
            else
            {
                count = c;
                break; // TODO: might not be correct. Was : Exit For
            }
        }
        for (c = count + 1; c <= count + 5; c++)
        {
            n = s.Substring(c, 1);
            if (n != "/")
            {
                dd = dd + n;
            }
            else
            {
                count = c;
                break; // TODO: might not be correct. Was : Exit For
            }
        }
        year = s.Substring(count + 1, 4);
        string r = null;
        r = dd + "/" + mm + "/" + year;
        return year;
    }
    public string Y_M_D_Diff(DateTime DateOne, DateTime DateTwo)
    {
        int Year = 0;
        int Month = 0;
        int Day = 0;
        // Function to display difference between two dates in Years, Months and Days, calling routine ensures that DateOne is always earlier than DateTwo
        // If both dates the same then exit with zeros returned otherwise a difference of one year gets returned!!!
        if (DateOne != DateTwo)
        {
            // Years
            // If year is the same in both dates, an out of range exception is thrown!!!
            if (DateTwo.Year > DateOne.Year)
            {
                Year = DateTwo.AddYears(-DateOne.Year).Year;
                // Subtract DateOne years from DateTwo years to get difference
            }

            // Months
            Month = DateTwo.AddMonths(-DateOne.Month).Month;
            // Subtract DateOne months from DateTwo months
            // Decrement year by one if DateTwo months hasn't exceeded DateOne months, i.e. not full year yet
            if (DateTwo.Month <= DateOne.Month)
            {
                if (Year > 0)
                    Year -= 1;
            }

            // Days
            Day = DateTwo.AddDays(-DateOne.Day).Day;
            // Subtract DateOne days from DateTwo days
            // Decrement month by one if DateTwo days hasn't exceeded DateOne days - not full month yet
            if (DateTwo.Day <= DateOne.Day)
            {
                if (Month > 0)
                    Month -= 1;
            }
            // Avoid silliness like "1 month 31 days" instead of 2 months
            if (DateOne.Day == DateTwo.Day)
            {
                Day = 0;
                // Reset days
                Month += 1;
                // And increment month
            }

            // Corrections
            // Months value goes up to 12, and we want a maximum of 11, so:
            if (Month == 12)
            {
                Month = 0;
                // Reset months to zero
                Year += 1;
                // And increment year
            }
            // If year and month are the same in DateOne & DateTwo then month = 12 and therefore year has been incremented
            if (DateOne.Year == DateTwo.Year && DateOne.Month == DateOne.Month)
            {
                Year = 0;
                // So reset it
            }

        }
        // DateOne <> DateTwo

        return Year + "yr," + Month + "mth," + Day + "d";
        // Concatenate string and return to calling routine

    }

    //Public con As New System.Data.SqlClient.SqlConnection()
    public System.Data.SqlClient.SqlDataAdapter adp = new System.Data.SqlClient.SqlDataAdapter();
    public System.Data.SqlClient.SqlCommandBuilder cb;  

    public void open()
    {
        if (con.State == ConnectionState.Closed)
        {
            con.Open();
        }
    }
    public void close()
    {
        if (con.State == ConnectionState.Open)
        {
            con.Close();
        }
    }

	
}
