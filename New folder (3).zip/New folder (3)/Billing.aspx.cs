﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Billing : System.Web.UI.Page
{
    public static TimeZoneInfo timeZoneInfo = TimeZoneInfo.FindSystemTimeZoneById("India Standard Time");
    public static DateTime dateTime;
    HttpCookie lgdcookie;
    Class1 cl = new Class1();
    public static string sku = "";
    public static string kotbill = "";
    protected string TableNo = "";
    bool IsKotView
    {
        get
        {
            return ViewState["IsKotView"] != null && (bool)ViewState["IsKotView"];
        }
        set
        {
            ViewState["IsKotView"] = value;
        }
    }
    DateTime businessDate;
    protected void Page_Load(object sender, EventArgs e)
    {
        lgdcookie = Request.Cookies["loggeduser"];
        if (lgdcookie != null && !string.IsNullOrEmpty(lgdcookie["UserName"]))
        {
            dateTime = TimeZoneInfo.ConvertTime(DateTime.Now, timeZoneInfo);
            if (!IsPostBack)
            {
                if (string.IsNullOrWhiteSpace(Request.QueryString["table_no"]))
                {
                    Response.Redirect("Dashboard.aspx");
                    return;
                }

                hfTableNo.Value = Request.QueryString["table_no"];
                string view = Request.QueryString["view"];
                string mode = Request.QueryString["mode"];
                lblTableNo.Text = hfTableNo.Value;
                LoadKotNumbers(hfTableNo.Value);
                bindbill(hfTableNo.Value);
                BusinessDate = BusinessDate;
                if (view == "1")
                {
                    LoadOpenKOT(hfTableNo.Value, 0);   
                }
                else if (mode == "hold")
                {
                    LoadOpenKOT(hfTableNo.Value, 2);  
                }
                else
                {
                    Session["BillTable"] = null;
                    BindGrid(0);
                    lblSubTotal.Text = "0.00";
                    lblTax.Text = "0.00";
                    lblGrandTotal.Text = "0.00";
                    lblRoundOff.Text = "0.00";
                    lblReturn.Text = "0.00";
                }

                itemgroup();
                CalculateBill();
                lblNextKOT.Text = GenerateKOTNo();
            }
        }
        else
        {
            Response.Redirect("Login.aspx");
        }
    }       

    protected void lnkKotNo_Click(object sender, EventArgs e)
    {
        LinkButton lnk = (LinkButton)sender;
        string kotNo = lnk.CommandArgument;

        if (string.IsNullOrEmpty(kotNo)) return;

        IsKotView = true;

        if (Session["BillTable"] == null)
        {
            string mode = Request.QueryString["mode"];
            int status = 0;

            if (mode == "hold")
            {
                status = 2;
            }

            LoadOpenKOT(hfTableNo.Value, status);
        }

        FilterGridByKot(kotNo);
    }

    private void FilterGridByKot(string kotNo)
    {
        if (Session["BillTable"] == null) return;

        DataTable dt = (DataTable)Session["BillTable"];

        DataView dv = new DataView(dt);
        dv.RowFilter = "KOT_No = '" + kotNo + "'";

        gvBill.DataSource = dv;
        gvBill.DataBind();

        CalculateBill();
    }
    private void LoadOpenKOT(string tableNo, int status)
    {
        DataTable dt = new DataTable();
        dt.Columns.Add("ItemName");
        dt.Columns.Add("Rate", typeof(decimal));
        dt.Columns.Add("Qty", typeof(int));
        dt.Columns.Add("Amount", typeof(decimal));
        dt.Columns.Add("Flag", typeof(int));
        dt.Columns.Add("SKU", typeof(string));
        dt.Columns.Add("GST", typeof(decimal));
        dt.Columns.Add("GroupName", typeof(string));
        dt.Columns.Add("KOT_No", typeof(string));
        dt.Columns.Add("IsSaved", typeof(int));
        SqlCommand cmd = new SqlCommand(@"
        SELECT m.kot_no, d.ItemName, d.Rate, d.Qty, d.Amount,
        ISNULL(i.flag,1) Flag,d.sku,d.gst_per, igm.pgroupname
        FROM KOT_Master m
        INNER JOIN KOT_Detail d ON m.KOT_ID = d.KOT_ID
        LEFT JOIN item_detail i ON d.ItemName = i.item_name
        LEFT JOIN Item_group_Master igm ON i.Item_group_name = igm.Item_G_Id
        WHERE m.Table_No = @TableNo 
        AND m.IsClosed = @Status", cl.con);

        cmd.Parameters.AddWithValue("@TableNo", tableNo);
        cmd.Parameters.AddWithValue("@Status", status);

        cl.con.Open();
        SqlDataReader dr = cmd.ExecuteReader();
        while (dr.Read())
        {
            DataRow r = dt.NewRow();
            r["ItemName"] = dr["ItemName"];
            r["Rate"] = dr["Rate"];
            r["Qty"] = dr["Qty"];
            r["Amount"] = dr["Amount"];
            r["Flag"] = dr["Flag"];
            r["SKU"] = dr["sku"];
            r["GST"] = dr["gst_per"];
            r["KOT_No"] = dr["KOT_No"];
            r["GroupName"] = dr["pgroupname"] == DBNull.Value ? "" : dr["pgroupname"].ToString();
            r["IsSaved"] = 1;
            dt.Rows.Add(r);
        }
        cl.con.Close();
        Session["BillTable"] = dt;
        BindGrid(1);
    }
    private void LoadKotNumbers(string tableNo)
    {
        DataTable dt = new DataTable();
        dt.Columns.Add("KOT_No");
        string mode = Request.QueryString["mode"];
        int status = 0; 
        if (mode == "hold")
        {
            status = 2;
        }
        SqlCommand cmd = new SqlCommand("SELECT KOT_No FROM KOT_Master WHERE Table_No=@t AND IsClosed=@status ORDER BY KOT_No", cl.con);
        cmd.Parameters.AddWithValue("@t", tableNo);
        cmd.Parameters.AddWithValue("@status", status);
        cl.con.Open();
        SqlDataReader dr = cmd.ExecuteReader();
        while (dr.Read())
        {
            DataRow r = dt.NewRow();
            r["KOT_No"] = dr["KOT_No"].ToString();
            dt.Rows.Add(r);
        }
        cl.con.Close();
        rptKOT.DataSource = dt;
        rptKOT.DataBind();
    }
    public void itemgroup()
    {
        string query = "select item_g_id, item_g_name from Item_group_master where deactive = 0 order by item_g_name ";
        SqlDataAdapter sda = new SqlDataAdapter(query, cl.con);
        DataTable dt = new DataTable();
        sda.Fill(dt);
        if (dt.Rows.Count > 0)
        {
            lst.DataSource = dt;
            lst.DataBind();
        }
    }
    private DateTime BusinessDate
    {
        get
        {
            if (ViewState["BusinessDate"] != null)
                return (DateTime)ViewState["BusinessDate"];

            DateTime d;
            HttpCookie dc = Request.Cookies["BusinessDate"];

            if (dc != null && DateTime.TryParse(dc.Value, out d))
                ViewState["BusinessDate"] = d;
            else
                ViewState["BusinessDate"] = GetBusinessDate();

            return (DateTime)ViewState["BusinessDate"];
        }
        set
        {
            ViewState["BusinessDate"] = value;
        }
    }
    protected void lnlroom_Click(object sender, EventArgs e)
    {
        LinkButton btn = (LinkButton)sender;
        ListViewDataItem dataItem = (ListViewDataItem)btn.NamingContainer;

        int groupId = Convert.ToInt32(lst.DataKeys[dataItem.DataItemIndex].Value);

        string query2 = "select item_name from item_detail where item_group_name = @gid";

        SqlDataAdapter sda = new SqlDataAdapter(query2, cl.con);
        sda.SelectCommand.Parameters.AddWithValue("@gid", groupId);

        DataTable dt = new DataTable();
        sda.Fill(dt);

        if (dt.Rows.Count > 0)
        {
            ListView1.DataSource = dt;
            ListView1.DataBind();
            Panel1.Visible = true;
            lblmessage.Visible = false;
        }
        else
        {
            lblmessage.Text = "Item Not Found!!";
            lblmessage.Visible = true;
            Panel1.Visible = false;
        }
    }

    protected void itemname_Click(object sender, EventArgs e)
    {
        //if (IsDayClosed())
        //{
        //    ScriptManager.RegisterStartupScript( this, GetType(), "msg", "savealert('Day closed. Item add not allowed','error');", true);
        //    return;
        //}

        IsKotView = false;
        LinkButton btn = (LinkButton)sender;
        string itemName = btn.Text;

        string query = "SELECT item_sale_rate, flag, sku, gst_per, igm.pgroupname, rate_X1, rate_X12, rate_X25, Rate_X4 FROM item_detail id  LEFT JOIN Item_group_Master igm ON id.Item_group_name = igm.Item_G_Id WHERE item_name = @name";

        SqlCommand cmd = new SqlCommand(query, cl.con);
        cmd.Parameters.AddWithValue("@name", itemName);

        int flag = 1;
        string sku = "";
        decimal gst = 0;
        string groupName = "";
        bool isFood = false;
        Dictionary<string, decimal> rateList = new Dictionary<string, decimal>();

        cl.con.Open();
        SqlDataReader dr = cmd.ExecuteReader();
        if (dr.Read())
        {
            flag = dr["flag"] == DBNull.Value ? 0 : Convert.ToInt32(dr["flag"]);
            sku = dr["sku"] == DBNull.Value ? "" : dr["sku"].ToString();
            gst = dr["gst_per"] == DBNull.Value ? 0 : Convert.ToDecimal(dr["gst_per"]);
            groupName = dr["pgroupname"].ToString();

            string grp = groupName.ToUpper().Trim();
            isFood = grp == "FOODING" || grp == "BEVERAGE" || grp == "COMPL";

            if (isFood)
            {
                if (dr["item_sale_rate"] != DBNull.Value)
                    rateList.Add("", Convert.ToDecimal(dr["item_sale_rate"]));
            }
            else
            {
                if (dr["rate_X1"] != DBNull.Value)
                    rateList.Add("X1", Convert.ToDecimal(dr["rate_X1"]));

                if (dr["rate_X12"] != DBNull.Value)
                    rateList.Add("X12", Convert.ToDecimal(dr["rate_X12"]));

                if (dr["rate_X25"] != DBNull.Value)
                    rateList.Add("X25", Convert.ToDecimal(dr["rate_X25"]));

                if (dr["Rate_X4"] != DBNull.Value)
                    rateList.Add("X4", Convert.ToDecimal(dr["Rate_X4"]));
            }

        }
        cl.con.Close();
        if (rateList.Count == 1 || isFood)
        {
            var r = rateList.First();
            string rateLabel = r.Key;
            decimal rate = r.Value;

            string displayName = string.IsNullOrEmpty(rateLabel)
                ? itemName
                : itemName + " (" + rateLabel + ")";

            AddItemDirect(displayName, rate, flag, sku, gst, groupName);
            return;
        }

        Session["RateList"] = rateList;
        Session["RateItemName"] = itemName;
        Session["RateFlag"] = flag;
        Session["RateSku"] = sku;
        Session["RateGST"] = gst;
        Session["RateGroup"] = groupName;

        lblModalItemName.Text = itemName;
        hfItemName.Value = itemName;

        DataTable rateDT = new DataTable();
        rateDT.Columns.Add("Label");
        rateDT.Columns.Add("Rate", typeof(decimal));

        foreach (var r in rateList)
        {
            rateDT.Rows.Add(r.Key, r.Value);
        }
        rptRates.DataSource = rateDT;
        rptRates.DataBind();
        ScriptManager.RegisterStartupScript(
            this, this.GetType(),
            "ratePopup",
            "var m = new bootstrap.Modal(document.getElementById('rateModal')); m.show();",
            true
        );
    }
    private void AddItemDirect(string itemName, decimal rate, int flag, string sku, decimal gst, string groupName)
    {
        DataTable dt;
        if (Session["BillTable"] == null)
            dt = CreateBillTable();
        else
            dt = (DataTable)Session["BillTable"];

        DataRow row = dt.AsEnumerable()
            .FirstOrDefault(r => r.Field<string>("ItemName") == itemName
                              && Convert.ToInt32(r["IsSaved"]) == 0
                              && Convert.ToDecimal(r["Rate"]) == rate);

        if (row != null)
        {
            row["Qty"] = Convert.ToInt32(row["Qty"]) + 1;
            row["Amount"] = Convert.ToDecimal(row["Qty"]) * rate;
        }
        else
        {
            DataRow drNew = dt.NewRow();
            drNew["ItemName"] = itemName;
            drNew["Rate"] = rate;
            drNew["Qty"] = 1;
            drNew["Amount"] = rate;
            drNew["Flag"] = flag;
            drNew["SKU"] = sku;
            drNew["GST"] = gst;
            drNew["GroupName"] = groupName;
            drNew["IsSaved"] = 0;
            dt.Rows.Add(drNew);
        }

        Session["BillTable"] = dt;
        BindGrid(0);
        CalculateBill();
    }
    protected void btnAddRate_Click(object sender, EventArgs e)
    {
        if (string.IsNullOrEmpty(hfSelectedRate.Value))
            return;

        decimal rate = Convert.ToDecimal(hfSelectedRate.Value);
        string rateLabel = hfRateLabel.Value;

        string itemName = Session["RateItemName"].ToString();
        int flag = Convert.ToInt32(Session["RateFlag"]);
        string sku = Session["RateSku"].ToString();
        decimal gst = Convert.ToDecimal(Session["RateGST"]);
        string groupName = Session["RateGroup"].ToString();

        string displayName = string.IsNullOrEmpty(rateLabel)
            ? itemName
            : itemName + " (" + rateLabel + ")";
        AddItemDirect(displayName, rate, flag, sku, gst, groupName);

        ScriptManager.RegisterStartupScript(
            this, this.GetType(),
            "closeModal",
            "bootstrap.Modal.getInstance(document.getElementById('rateModal')).hide();",
            true
        );
    }
    private DataTable CreateBillTable()
    {
        DataTable dt = new DataTable();

        dt.Columns.Add("ItemName", typeof(string));
        dt.Columns.Add("Rate", typeof(decimal));
        dt.Columns.Add("Qty", typeof(int));
        dt.Columns.Add("Amount", typeof(decimal));
        dt.Columns.Add("Flag", typeof(int));
        dt.Columns.Add("SKU", typeof(string));
        dt.Columns.Add("GST", typeof(decimal));
        dt.Columns.Add("GroupName", typeof(string));
        dt.Columns.Add("KOT_No", typeof(string));
        dt.Columns.Add("IsSaved", typeof(int));

        return dt;
    }

    protected void gvBill_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (IsKotView) return;
        if (Session["BillTable"] == null) return;

        GridViewRow gvRow = (GridViewRow)((Control)e.CommandSource).NamingContainer;
        string itemName = gvBill.DataKeys[gvRow.RowIndex].Value.ToString();

        DataTable dt = (DataTable)Session["BillTable"];
        DataRow row = dt.AsEnumerable()
            .FirstOrDefault(r => r.Field<string>("ItemName") == itemName &&
                !(Request.QueryString["view"] == "1" && Convert.ToInt32(r["IsSaved"]) == 1));

        if (row == null) return;

        if (e.CommandName == "Plus")
        {
            row["Qty"] = Convert.ToInt32(row["Qty"]) + 1;
            row["Amount"] = Convert.ToDecimal(row["Rate"]) * Convert.ToInt32(row["Qty"]);
        }
        else if (e.CommandName == "Minus")
        {
            int q = Convert.ToInt32(row["Qty"]);
            if (q > 1)
            {
                row["Qty"] = q - 1;
                row["Amount"] = Convert.ToDecimal(row["Rate"]) * Convert.ToInt32(row["Qty"]);
            }
            else
            {
                dt.Rows.Remove(row);
            }
        }
        else if (e.CommandName == "Remove")
        {
            dt.Rows.Remove(row);
        }

        Session["BillTable"] = dt;
        BindGrid(0);
        CalculateBill();
    }
    private void CalculateBill()
    {
        if (Session["BillTable"] == null) return;

        DataTable dt = (DataTable)Session["BillTable"];
        string view = Request.QueryString["view"];

        decimal subTotal = 0;
        decimal foodSubTotal = 0;
        decimal tax = 0;

        foreach (DataRow row in dt.Rows)
        {
            int isSaved = Convert.ToInt32(row["IsSaved"]);

            if (view == "1")
            {
                if (isSaved != 1) continue;
            }
            else
            {
                if (isSaved != 0) continue;
            }

            decimal amt = Convert.ToDecimal(row["Amount"]);
            decimal gstPer = row["GST"] == DBNull.Value ? 0 : Convert.ToDecimal(row["GST"]);
            string groupName = row["GroupName"] == DBNull.Value ? "" : row["GroupName"].ToString().ToUpper();

            subTotal += amt;
            if (groupName == "FOODING")
            {
                foodSubTotal += amt;
            }

            tax += Math.Round((amt * gstPer) / 100, 2);
        }
        decimal discountPer = 0;
        decimal.TryParse(txtdiscount.Text, out discountPer);

        if (discountPer > 40)
        {
            discountPer = 40;
            txtdiscount.Text = "40";
        }

        decimal discountAmount = 0;
        if (discountPer > 0 && foodSubTotal > 0)
        {
            discountAmount = Math.Round((foodSubTotal * discountPer) / 100, 2);
        }
        decimal netAmount = subTotal - discountAmount;
        decimal deliveryCharge = 0;
        decimal.TryParse(txtdilivery.Text, out deliveryCharge);

        decimal exactTotal = netAmount + tax + deliveryCharge;
        decimal grandTotal = Math.Round(exactTotal);
        decimal roundOff = grandTotal - exactTotal;

        lblSubTotal.Text = subTotal.ToString("0.00");
        lblTax.Text = tax.ToString("0.00");
        lblRoundOff.Text = roundOff.ToString("0.00");
        lblGrandTotal.Text = grandTotal.ToString("0.00");

        CalculateReturn(grandTotal);
    }
    private void CalculateReturn(decimal grandTotal)
    {
        decimal paid = 0;
        decimal.TryParse(txtCustomerPaid.Text, out paid);

        decimal ret = paid - grandTotal;
        if (ret < 0) ret = 0;

        lblReturn.Text = ret.ToString("0.00");
    }
    protected void txtdilivery_TextChanged(object sender, EventArgs e)
    {
        CalculateBill();
    }
    protected void txtdiscount_TextChanged(object sender, EventArgs e)
    {
        CalculateBill();
    }
    protected void txtCustomerPaid_TextChanged(object sender, EventArgs e)
    {
        decimal grandTotal = Convert.ToDecimal(lblGrandTotal.Text);
        CalculateReturn(grandTotal);
    }
    protected void txtnumber_TextChanged(object sender, EventArgs e)
    {
        string search = txtnumber.Text.Trim();

        if (string.IsNullOrEmpty(search))
        {
            ListView1.DataSource = null;
            ListView1.DataBind();
            return;
        }

        string query = "SELECT item_name FROM item_detail WHERE item_name LIKE @search";

        SqlDataAdapter sda = new SqlDataAdapter(query, cl.con);
        sda.SelectCommand.Parameters.AddWithValue("@search", "%" + search + "%");

        DataTable dt = new DataTable();
        sda.Fill(dt);

        if (dt.Rows.Count > 0)
        {
            ListView1.DataSource = dt;
            ListView1.DataBind();
            Panel1.Visible = true;
            lblmessage.Visible = false;
        }
        else
        {
            lblmessage.Text = "Item Not Found!";
            lblmessage.Visible = true;
            Panel1.Visible = false;
        }
    }
    protected void chkPaid_CheckedChanged(object sender, EventArgs e)
    {
        if (chkPaid.Checked)
        {
            txtCustomerPaid.Text = lblGrandTotal.Text;
            CalculateReturn(Convert.ToDecimal(lblGrandTotal.Text));
        }
    }
    protected void btnKot_Click(object sender, EventArgs e)
    {
        SaveKOTSplit(false);
    }
    protected void btnKotPrint_Click(object sender, EventArgs e)
    {
        SaveKOTSplit(true);
    }
    private int GetCurrentBillNo(int tableNo)
    {
        SqlCommand cmd = new SqlCommand("SELECT ISNULL(MAX(Bill_No),0) + 1 FROM KOT_Master WHERE Table_No=@t AND IsClosed=1", cl.con);

        cmd.Parameters.AddWithValue("@t", tableNo);

        cl.con.Open();
        int billNo = Convert.ToInt32(cmd.ExecuteScalar());
        cl.con.Close();

        return billNo == 0 ? 1 : billNo;
    }
    private void ClearGridAfterKOT()
    {
        DataTable dt = (DataTable)Session["BillTable"];
        dt.Clear();
        Session["BillTable"] = dt;
        BindGrid(0);
        CalculateBill();
    }
    private void SaveKOTSplit(bool isPrint)
    {
        if (Session["BillTable"] == null) return;

        DataTable dt = (DataTable)Session["BillTable"];
        if (dt.Rows.Count == 0) return;

        string tableNo = hfTableNo.Value;
        string kotNo = GenerateKOTNo();

        DataRow[] foodRows =
            dt.Select("GroupName IN ('FOODING','BEVERAGE','COMPL') AND IsSaved = 0");

        DataRow[] barRows =
            dt.Select("GroupName = 'BAR' AND IsSaved = 0");

        if (foodRows.Length > 0)
            SaveKOTByGroup(foodRows, tableNo, kotNo, "FOOD", isPrint);

        if (barRows.Length > 0)
            SaveKOTByGroup(barRows, tableNo, kotNo, "BAR", isPrint);

        BindGrid(0);
        CalculateBill();

        if (isPrint)
        {
            Response.Redirect(
                "Print_KOT.aspx?table_no=" + tableNo + "&kotno=" + kotNo,
                false
            );
            Context.ApplicationInstance.CompleteRequest();
        }
        else
        {
            Response.Redirect("Dashboard.aspx");
        }
        IsKotView = false;
        LoadKotNumbers(hfTableNo.Value);

    }
    private void SaveKOTByGroup(DataRow[] rows, string tableNo, string kotNo, string orderType, bool isPrint)
    {
        DataTable kotDT = rows.CopyToDataTable();

        decimal total = 0;
        decimal gst = 0;

        foreach (DataRow r in kotDT.Rows)
        {
            decimal amt = Convert.ToDecimal(r["Amount"]);
            decimal gstPer = r["GST"] == DBNull.Value ? 0 : Convert.ToDecimal(r["GST"]);

            total += amt;
            gst += Math.Round((amt * gstPer) / 100, 2);
        }
        decimal grandTotal = total + gst;
        cl.con.Open();
        SqlTransaction tran = cl.con.BeginTransaction();

        try
        {
            SqlCommand cmdKot = new SqlCommand("INSERT INTO KOT_Master (Table_No,KOT_No,KOT_Date,IsPrinted,IsClosed, IsRunning,KOTTime,total,Gstper,Grandtotal,order_type,insuser,insdate) OUTPUT INSERTED.KOT_ID  VALUES (@Table,@KOT,@kotdate,@Print,0,1, @Time,@Total,@GST,@Grand,@Type,@insuser,@insdate)", cl.con, tran);

            cmdKot.Parameters.AddWithValue("@Table", tableNo);
            cmdKot.Parameters.AddWithValue("@KOT", kotNo);
            cmdKot.Parameters.AddWithValue("@kotdate", System.Data.SqlDbType.Date)
                     .Value = BusinessDate.Date;
            cmdKot.Parameters.AddWithValue("@Print", isPrint);
            cmdKot.Parameters.AddWithValue("@Time", dateTime.ToString("hh:mm tt"));
            cmdKot.Parameters.AddWithValue("@Total", total);
            cmdKot.Parameters.AddWithValue("@GST", gst);
            cmdKot.Parameters.AddWithValue("@Grand", grandTotal);
            cmdKot.Parameters.AddWithValue("@Type", orderType);
            cmdKot.Parameters.AddWithValue("@insuser", lgdcookie["UserName"]);
            cmdKot.Parameters.AddWithValue("@insdate", dateTime.ToString("yyyy-MM-dd"));

            int kotId = Convert.ToInt32(cmdKot.ExecuteScalar());

            foreach (DataRow r in kotDT.Rows)
            {
                SqlCommand cmdItem = new SqlCommand("INSERT INTO KOT_Detail (KOT_ID,ItemName,Rate,Qty,Amount,sku,gst_per) VALUES  (@ID,@Item,@Rate,@Qty,@Amt,@SKU,@GST)", cl.con, tran);

                cmdItem.Parameters.AddWithValue("@ID", kotId);
                cmdItem.Parameters.AddWithValue("@Item", r["ItemName"]);
                cmdItem.Parameters.AddWithValue("@Rate", r["Rate"]);
                cmdItem.Parameters.AddWithValue("@Qty", r["Qty"]);
                cmdItem.Parameters.AddWithValue("@Amt", r["Amount"]);
                cmdItem.Parameters.AddWithValue("@SKU", r["SKU"]);
                cmdItem.Parameters.AddWithValue("@GST", r["GST"]);

                cmdItem.ExecuteNonQuery();

                r["IsSaved"] = 1;
            }
            tran.Commit();
        }
        catch
        {
            tran.Rollback();
            throw;
        }
        finally
        {
            cl.con.Close();
        }
    }
    private string GenerateKOTNo()
    {
        SqlCommand cmd = new SqlCommand("SELECT ISNULL(MAX(CAST(KOT_No AS INT)), 0) + 1 FROM KOT_Master", cl.con);
        cl.con.Open();
        int nextNo = Convert.ToInt32(cmd.ExecuteScalar());
        cl.con.Close();
        return nextNo.ToString("000");
    }
    protected void btnSave_Click(object sender, EventArgs e)
    {
        SaveFinalBill(false);
    }
    protected void btnSavePrint_Click(object sender, EventArgs e)
    {
        SaveFinalBill(true);
    }
    private string GenerateBillNo(string prefix)
    {
        int nextNo;
        using (SqlCommand cmd = new SqlCommand("SELECT ISNULL(MAX(CAST(RIGHT(Bill_No,5) AS INT)),0) FROM Bill_Master WHERE Bill_No LIKE @p + '%'", cl.con))
        {
            cmd.Parameters.AddWithValue("@p", prefix);
            cl.con.Open();
            nextNo = (int)cmd.ExecuteScalar() + 1;
            cl.con.Close();
        }
        return prefix + nextNo.ToString().PadLeft(5, '0');
    }

    private void SaveFinalBill(bool isPrint)
    {
        if (Session["BillTable"] == null) return;

        DataTable dt = (DataTable)Session["BillTable"];
        if (dt.Rows.Count == 0) return;

        DataRow[] foodRows = dt.Select("GroupName IN ('FOODING','BEVERAGE','COMPL')");
        DataRow[] barRows = dt.Select("GroupName NOT IN ('FOODING','BEVERAGE','COMPL')");


        string foodBillNo = SaveBillByGroup(foodRows, "FOOD");
        string barBillNo = SaveBillByGroup(barRows, "BAR");

        if (!string.IsNullOrEmpty(foodBillNo))
        {
            using (SqlCommand cmd = new SqlCommand("UPDATE KOT_Master SET IsClosed = 1, billno = @billno WHERE Table_No = @t AND IsClosed = 0 AND order_type = 'FOOD'", cl.con))
            {
                cmd.Parameters.AddWithValue("@billno", foodBillNo);
                cmd.Parameters.AddWithValue("@t", hfTableNo.Value);

                cl.con.Open();
                cmd.ExecuteNonQuery();
                cl.con.Close();
            }
        }
        if (!string.IsNullOrEmpty(barBillNo))
        {
            using (SqlCommand cmd = new SqlCommand("UPDATE KOT_Master SET IsClosed = 1, billno = @billno WHERE Table_No = @t AND IsClosed = 0 AND order_type = 'BAR'", cl.con))
            {
                cmd.Parameters.AddWithValue("@billno", barBillNo);
                cmd.Parameters.AddWithValue("@t", hfTableNo.Value);

                cl.con.Open();
                cmd.ExecuteNonQuery();
                cl.con.Close();
            }
        }
        dt.Clear();
        Session["BillTable"] = dt;
        gvBill.DataSource = dt;
        gvBill.DataBind();
        if (isPrint)
        {
            string url = "Restaurant_Billing.aspx?" + "food=" + Server.UrlEncode(foodBillNo) + "&bar=" + Server.UrlEncode(barBillNo) + "&tableno=" + Server.UrlEncode(hfTableNo.Value);
            string script = "window.location.href = '" + url + @"';"; ClientScript.RegisterStartupScript(this.GetType(), "print", script, true);

        }
        else
        {
            Response.Redirect("Dashboard.aspx");
        }
    }

    private string SaveBillByGroup(DataRow[] rows, string billType)
    {
        if (rows == null || rows.Length == 0)
            return string.Empty;

        DataTable billDT = rows.CopyToDataTable();

        decimal subTotal = 0;
        decimal tax = 0;

        foreach (DataRow r in billDT.Rows)
        {
            decimal amt = Convert.ToDecimal(r["Amount"]);
            decimal gst = r["GST"] == DBNull.Value ? 0 : Convert.ToDecimal(r["GST"]);

            subTotal += amt;
            tax += Math.Round((amt * gst) / 100, 2);
        }
        decimal discountAmount = 0;
        decimal discountPer = 0;

        if (billType == "FOOD")
        {
            decimal.TryParse(txtdiscount.Text, out discountPer);
            if (discountPer > 40) discountPer = 40;

            discountAmount = Math.Round((subTotal * discountPer) / 100, 2);
        }
        decimal exactTotal = subTotal - discountAmount + tax;
        decimal grandTotal = Math.Round(exactTotal);
        decimal roundOff = grandTotal - exactTotal;

        string billNo = billType == "FOOD" ? GenerateBillNo("FR") : GenerateBillNo("BR");

        string tableNo = hfTableNo.Value;

        cl.con.Open();
        SqlTransaction tran = cl.con.BeginTransaction();
        string payMode = "";
        int cash = 0, card = 0, upi = 0, credit = 0;

        decimal cashAmt = 0, cardAmt = 0, upiAmt = 0, creditAmt = 0;

        if (rbCash.Checked)
        {
            payMode = "CASH";
            cash = 1;
            cashAmt = grandTotal;
        }
        else if (rbCard.Checked)
        {
            payMode = "CARD";
            card = 1;
            cardAmt = grandTotal;
        }
        else if (rbUPI.Checked)
        {
            payMode = "UPI";
            upi = 1;
            upiAmt = grandTotal;
        }
        else if (rbOther.Checked)
        {
            payMode = "CREDIT";
            credit = 1;
            creditAmt = grandTotal;
        }
        try
        {
            SqlCommand cmdBill = new SqlCommand("INSERT INTO Bill_Master (Bill_No,Table_No,SubTotal,Tax,GrandTotal,PaidAmount,ReturnAmount,IsPaid,IsRunning,billTime, Discount,DeliveryCharge,Bill_date,RoundOff,Status, order_type,insuser,insdate,instime,insyear,CashAmount,CardAmount,UpiAmount,CreditAmount,cash,card,upi,credit) OUTPUT INSERTED.Bill_ID VALUES (@BillNo,@TableNo,@SubTotal,@Tax,@GrandTotal,@Paid, @Return,@IsPaid,1,@billTime, @Discount,@DeliveryCharge,@billdate,@RoundOff,@Status, @order_type,@insuser,@insdate,@instime,@insyear,@CashAmount,@CardAmount,@UpiAmount, @CreditAmount, @Cash,@Card ,@Upi,@Credit)", cl.con, tran);

            cmdBill.Parameters.AddWithValue("@BillNo", billNo);
            cmdBill.Parameters.AddWithValue("@TableNo", tableNo);
            cmdBill.Parameters.AddWithValue("@SubTotal", subTotal);
            cmdBill.Parameters.AddWithValue("@Tax", tax);
            cmdBill.Parameters.AddWithValue("@GrandTotal", grandTotal);
            cmdBill.Parameters.Add("@billdate", System.Data.SqlDbType.Date).Value = BusinessDate.Date;
            cmdBill.Parameters.AddWithValue("@Paid", string.IsNullOrEmpty(txtCustomerPaid.Text) ? 0 : Convert.ToDecimal(txtCustomerPaid.Text));
            cmdBill.Parameters.AddWithValue("@Return", lblReturn.Text);
            cmdBill.Parameters.AddWithValue("@PaymentMode", payMode);
            cmdBill.Parameters.AddWithValue("@CashAmount", cashAmt);
            cmdBill.Parameters.AddWithValue("@CardAmount", cardAmt);
            cmdBill.Parameters.AddWithValue("@UpiAmount", upiAmt);
            cmdBill.Parameters.AddWithValue("@CreditAmount", creditAmt);

            cmdBill.Parameters.AddWithValue("@Cash", cash);
            cmdBill.Parameters.AddWithValue("@Card", card);
            cmdBill.Parameters.AddWithValue("@UPI", upi);
            cmdBill.Parameters.AddWithValue("@Credit", credit);
            cmdBill.Parameters.AddWithValue("@IsPaid", chkPaid.Checked);
            cmdBill.Parameters.AddWithValue("@billTime", DateTime.Now.ToString("hh:mm tt"));
            cmdBill.Parameters.AddWithValue("@Discount", discountAmount);
            cmdBill.Parameters.AddWithValue("@DeliveryCharge", txtdilivery.Text);
            cmdBill.Parameters.AddWithValue("@RoundOff", roundOff);
            cmdBill.Parameters.AddWithValue("@Status", chkPaid.Checked ? "SUCCESS" : "PENDING");
            cmdBill.Parameters.AddWithValue("@order_type", "Dine In");
            cmdBill.Parameters.AddWithValue("@insuser", lgdcookie["UserName"]);
            cmdBill.Parameters.AddWithValue("@insdate", DateTime.Now.ToString("yyyy-MM-dd"));
            cmdBill.Parameters.AddWithValue("@instime", DateTime.Now.ToString("hh:mm:ss tt"));
            cmdBill.Parameters.AddWithValue("@insyear", DateTime.Now.ToString("yyyy"));

            int billId = Convert.ToInt32(cmdBill.ExecuteScalar());

            foreach (DataRow r in billDT.Rows)
            {
                SqlCommand cmdItem = new SqlCommand("INSERT INTO Bill_Detail (Bill_ID,ItemName,Rate,Qty,Amount,sku,gst_per) VALUES  (@BillID,@Item,@Rate,@Qty,@Amount,@sku,@gst)", cl.con, tran);

                cmdItem.Parameters.AddWithValue("@BillID", billId);
                cmdItem.Parameters.AddWithValue("@Item", r["ItemName"]);
                cmdItem.Parameters.AddWithValue("@Rate", r["Rate"]);
                cmdItem.Parameters.AddWithValue("@Qty", r["Qty"]);
                cmdItem.Parameters.AddWithValue("@Amount", r["Amount"]);
                cmdItem.Parameters.AddWithValue("@sku", r["SKU"]);
                cmdItem.Parameters.AddWithValue("@gst", r["GST"]);
                cmdItem.ExecuteNonQuery();
            }
            tran.Commit();
            return billNo;
        }
        catch
        {
            tran.Rollback();
            throw;
        }
        finally
        {
            cl.con.Close();
        }
    }
    private DateTime GetBusinessDate()
    {
        DateTime now = TimeZoneInfo.ConvertTime(DateTime.Now, timeZoneInfo);
        DateTime today = now.Date;

        DateTime businessDate;

        if (now.Hour < 3)
            businessDate = today.AddDays(-1);
        else
            businessDate = today;

        // 🔥 SQL DATETIME SAFETY
        if (businessDate < new DateTime(1753, 1, 1))
            businessDate = new DateTime(1753, 1, 1);

        return businessDate;
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        Response.Redirect("Dashboard.aspx");
    }
    private void CancelKot(string kotNo, string reason)
    {

        if (string.IsNullOrEmpty(kotNo)) return;
        if (string.IsNullOrEmpty(reason))
        {
            string message = "Cancel Reason Required";
            string type = "warning";
            ScriptManager.RegisterStartupScript(this, this.GetType(), "Script", "savealert('" + message + "','" + type + "')", true);
            return;
        }
        try
        {
            cl.con.Open();
            SqlTransaction tran = cl.con.BeginTransaction();
            SqlCommand cmd = new SqlCommand("UPDATE KOT_Master SET IsClosed = 1, Cancel_kot = 'Cancel', cancelby = @user, canceltime = @time, iscancelled = 1, cancelreason = @reason,canceldate = @canceldate WHERE KOT_No = @KOTNo AND IsClosed = 0", cl.con, tran);

            cmd.Parameters.AddWithValue("@KOTNo", kotNo);
            cmd.Parameters.AddWithValue("@user", lgdcookie["UserName"]);
            cmd.Parameters.AddWithValue("@time", dateTime.ToString("hh:mm tt"));
            cmd.Parameters.AddWithValue("@reason", reason);
            cmd.Parameters.AddWithValue("@canceldate", dateTime.ToString("yyyy-MM-dd"));
            cmd.ExecuteNonQuery();

            SqlCommand cmdDetail = new SqlCommand("UPDATE KOT_Detail SET Cancel_kot='Cancel' WHERE KOT_ID IN (SELECT KOT_ID FROM KOT_Master WHERE KOT_No=@KOTNo)",
                cl.con, tran);
            cmdDetail.Parameters.AddWithValue("@KOTNo", kotNo);
            cmdDetail.ExecuteNonQuery();
            tran.Commit();
            Response.Redirect("Dashboard.aspx");
        }
        catch (Exception ex)
        {
            ScriptManager.RegisterStartupScript(this, this.GetType(), "err", "Swal.fire({ icon: 'error', title: 'Error', text: '" + ex.Message.Replace("'", "") + "' });", true);
        }
        finally
        {
            cl.con.Close();
        }
    }

    protected void btncancel_Click(object sender, EventArgs e)
    {
        string tableNo = hfTableNo.Value;

        string qry = "SELECT KOT_No, format(KOT_Date, 'dd/MM/yyyy') as KOT_Date, order_type,total FROM KOT_Master WHERE Table_No = @TableNo and isclosed = 0 ";

        using (SqlCommand cmd = new SqlCommand(qry, cl.con))
        {
            cmd.Parameters.AddWithValue("@TableNo", tableNo);

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            gvKotList.DataSource = dt;
            gvKotList.DataBind();
        }

        ScriptManager.RegisterStartupScript(this, this.GetType(), "openCancelModal", "var m = new bootstrap.Modal(document.getElementById('cancelKotModal')); m.show();", true);
    }
    protected void gvKotList_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "SelectKot")
        {
            GridViewRow row = (GridViewRow)((Control)e.CommandSource).NamingContainer;

            string kotNo = e.CommandArgument.ToString();
            TextBox txtReason = (TextBox)row.FindControl("txtRowCancelReason");
            string reason = txtReason.Text.Trim();
            if (string.IsNullOrEmpty(reason))
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "warn", "Swal.fire({ icon: 'warning', title: 'Cancel Reason Required', text: 'Please enter cancel reason' });", true);
                return;
            }
            CancelKot(kotNo, reason);
            ScriptManager.RegisterStartupScript(this, this.GetType(), "done", @"Swal.fire({ icon: 'success', title: 'KOT Cancelled' });", true);


        }
    }
    public void bindbill(String table)
    {
        try
        {
            string query = "SELECT bd.itemname, sum(bd.qty) as qty FROM KOT_Master bm LEFT JOIN KOT_Detail bd ON bm.KOT_ID = bd.KOT_ID LEFT JOIN item_detail id ON bd.itemname = id.item_name WHERE bm.IsClosed = 0 and bm.table_no= '" + table + "' AND bm.isrunning = 1 group by bd.ItemName ORDER BY bd.itemname ";

            SqlDataAdapter sda = new SqlDataAdapter(query, cl.con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                gvPopupItems.DataSource = dt;
                gvPopupItems.DataBind();
            }
        }
        catch (Exception ex)
        {

        }
    }
    protected void gvBill_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (IsKotView)
        {
            LinkButton btnMinus = (LinkButton)e.Row.FindControl("Minus");
            LinkButton btnPlus = (LinkButton)e.Row.FindControl("Plus");
            LinkButton btnRemove = (LinkButton)e.Row.FindControl("Remove");

            if (btnMinus != null)
            {
                btnMinus.Enabled = false;
                btnMinus.CssClass += " disabled-btn";
            }
            if (btnPlus != null)
            {
                btnPlus.Enabled = false;
                btnPlus.CssClass += " disabled-btn";
            }
            if (btnRemove != null)
            {
                btnRemove.Enabled = false;
                btnRemove.CssClass += " disabled-btn";
            }
        }

    }
    private void BindGrid(int isSaved)
    {
        if (Session["BillTable"] == null) return;

        DataView dv = new DataView((DataTable)Session["BillTable"]);
        dv.RowFilter = "IsSaved = " + isSaved;

        gvBill.DataSource = dv;
        gvBill.DataBind();
    }

}