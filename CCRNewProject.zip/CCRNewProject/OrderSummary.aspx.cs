﻿//using Org.BouncyCastle.Utilities.Collections;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class OrderSummary : System.Web.UI.Page
{
    Class1 cl = new Class1();
    public static TimeZoneInfo timeZoneInfo = TimeZoneInfo.FindSystemTimeZoneById("India Standard Time");
    public static DateTime dateTime;
    HttpCookie lgdcookie;
    protected void Page_Load(object sender, EventArgs e)
    {
        lgdcookie = Request.Cookies["loggeduser"];
        dateTime = TimeZoneInfo.ConvertTime(DateTime.Now, timeZoneInfo);
        if (!IsPostBack)
        {             
            var masterFooter = this.Master.FindControl("masterFooter");
            if (masterFooter != null)
            {
                masterFooter.Visible = false;
            }

            lbltableno.Text = Request.QueryString["tblno"] ?? "";
            bindwaiter();
            lbldate.Text = dateTime.ToString("dd/MM/yyyy");
            lblkotno.Text = cl.Scalar("Select ISNULL(max(convert(int,kot_no)),0)+1 as kot_no  from restaurant where kot_flag=1 ");
            lblkotbill.Text = cl.Scalar("Select ISNULL(max(convert(int,kot_Bill)),0)+1 as kot_Bill from restaurant");
            lblitembill.Text = cl.Scalar("Select ISNULL(max(convert(int,item_bill)),0)+1 as item_bill from Temp_item_Save");
            CleanZeroQtyItems();
            LoadSelectedItems();
            bindkot();
        }
    }
    public void bindwaiter()
    {
        string query = "select autoid, waiter_name from waiter_master where deactive = 0";
        SqlDataAdapter sda = new SqlDataAdapter(query, cl.con);
        DataTable dt = new DataTable();
        sda.Fill(dt);
        if (dt.Rows.Count > 0)
        {
            ddlwaiter.DataValueField = "autoid";
            ddlwaiter.DataTextField = "waiter_name";
            ddlwaiter.DataSource = dt;
            ddlwaiter.DataBind();
            ddlwaiter.Items.Insert(0, new ListItem("--Select Waiter--", "-1"));
        }
    }        
    private void CleanZeroQtyItems()
    {
        string tableNo = Request.QueryString["tblno"];

        if (Session["SelectedItems_" + tableNo] != null)
        {
            List<Itemdata> items = (List<Itemdata>)Session["SelectedItems_" + tableNo];
            items = items.Where(x => Convert.ToInt32(x.qty) > 0).ToList();
            Session["SelectedItems_" + tableNo] = items;
        }
    }

    private void LoadSelectedItems()
    {
        string tableNo = Request.QueryString["tblno"];

        if (Session["SelectedItems_" + tableNo] != null)
        {
            var items = (List<Itemdata>)Session["SelectedItems_" + tableNo];

            rptOrder.DataSource = items;
            rptOrder.DataBind();

            decimal total = 0;
            decimal gstTotal = 0;

            foreach (var item in items)
            {
                decimal qty = Convert.ToDecimal(item.qty);
                decimal rate = Convert.ToDecimal(item.item_rate);
                decimal amount = qty * rate;

                decimal gstPer = (item.flag == 1) ? 5 : 0;
                decimal gstAmount = Math.Round((amount * gstPer) / 100, 2);

                total += amount;
                gstTotal += gstAmount;
            }

            decimal grandTotal = total + gstTotal;

            lblTotal.Text = total.ToString("0.00");
            lblgst.Text = gstTotal.ToString("0.00");
            lblgrandtotal.Text = grandTotal.ToString("0.00");
        }
        else
        {
            lblTotal.Text = "0.00";
            lblgst.Text = "0.00";
            lblgrandtotal.Text = "0.00";
        }
    }


    [WebMethod]
    public static void UpdateQtyToSession(List<Itemdata> items, string tableNo)
    {
        string key = "SelectedItems_" + tableNo;
        var sessionItems = (List<Itemdata>)HttpContext.Current.Session[key];

        foreach (var it in items)
        {
            var match = sessionItems.FirstOrDefault(x => x.item_id == it.item_id);
            if (match != null)
                match.qty = it.qty;
        }

        sessionItems = sessionItems.Where(x => Convert.ToInt32(x.qty) > 0).ToList();

        HttpContext.Current.Session[key] = sessionItems;
    }

    public class CartUpdate
    {
        public string item_id { get; set; }
        public string qty { get; set; }
    }
    [WebMethod]
    public static void ClearSessionCart(string tableNo)
    {
        HttpContext.Current.Session["SelectedItems_" + tableNo] = null;
    }

    [WebMethod]
    public static void RemoveItem(string itemId, string tableNo)
    {
        string key = "SelectedItems_" + tableNo;

        var sessionItems = (List<Itemdata>)HttpContext.Current.Session[key];

        sessionItems = sessionItems.Where(x => x.item_id != itemId).ToList();

        HttpContext.Current.Session[key] = sessionItems;
    }
    private string GenerateKOTNo()
    {
        SqlCommand cmd = new SqlCommand("SELECT ISNULL(MAX(CAST(KOT_No AS INT)), 0) + 1 FROM KOT_Master", cl.con);

        cl.con.Open();
        int nextNo = Convert.ToInt32(cmd.ExecuteScalar());
        cl.con.Close();

        return nextNo.ToString("000");
    }
    protected void btnBack_Click(object sender, EventArgs e)
    {
        Response.Redirect("Newpage12.aspx?tblno=" + Request.QueryString["tblno"].ToString());
    }
    [WebMethod]
    //public static void RemoveItem(string itemId, string tableNo)
    //{
    //    string key = "SelectedItems_" + tableNo;

    //    if (HttpContext.Current.Session[key] == null)
    //        return;

    //    var sessionItems = (List<Itemdata>)HttpContext.Current.Session[key];

    //    sessionItems = sessionItems
    //        .Where(x => x.item_id != itemId)
    //        .ToList();

    //    HttpContext.Current.Session[key] = sessionItems;
    //}
    //[WebMethod]
    //public static void UpdateQtyToSession(List<Itemdata> items, string tableNo)
    //{
    //    string key = "SelectedItems_" + tableNo;

    //    if (HttpContext.Current.Session[key] == null)
    //        return;

    //    var sessionItems = (List<Itemdata>)HttpContext.Current.Session[key];

    //    foreach (var it in items)
    //    {
    //        var match = sessionItems.FirstOrDefault(x => x.item_id == it.item_id);
    //        if (match != null)
    //            match.qty = it.qty;
    //    }

    //    sessionItems = sessionItems
    //        .Where(x => Convert.ToInt32(x.qty) > 0)
    //        .ToList();

    //    HttpContext.Current.Session[key] = sessionItems;
    //}

    protected void btnConfirm_Click(object sender, EventArgs e)
    {
        string tableNo = Request.QueryString["tblno"];
        var items = Session["SelectedItems_" + tableNo] as List<Itemdata>;

        if (items == null || items.Count == 0)
        {
            ClientScript.RegisterStartupScript(this.GetType(),
                "alert", "alert('No items to save!');", true);
            return;
        }

        items = items.Where(x => Convert.ToInt32(x.qty) > 0).ToList();

        decimal kotTotal = 0;
        decimal kotGST = 0;

        foreach (var it in items)
        {
            decimal amt = Convert.ToDecimal(it.item_rate) * Convert.ToInt32(it.qty);
            decimal gstPer = Convert.ToDecimal(it.gst_per);

            kotTotal += amt;
            kotGST += Math.Round((amt * gstPer) / 100, 2);
        }

        if (kotTotal == 0) return;

        decimal kotGrandTotal = kotTotal + kotGST;
        string kotNo = GenerateKOTNo();

        SqlConnection con = cl.con;
        con.Open();
        SqlTransaction trans = con.BeginTransaction();

        try
        {
            SqlCommand cmdKot = new SqlCommand(@"INSERT INTO KOT_Master (Table_No, KOT_No, KOT_Date, IsPrinted, IsClosed, IsRunning, KOTTime, total, Gstper, Grandtotal)
        OUTPUT INSERTED.KOT_ID VALUES  (@TableNo, @KOTNo, GETDATE(), 0, 0, 1,
         @KOTTime, @total, @GstAmount, @Grandtotal)",
            con, trans);

            cmdKot.Parameters.AddWithValue("@TableNo", tableNo);
            cmdKot.Parameters.AddWithValue("@KOTNo", kotNo);
            cmdKot.Parameters.AddWithValue("@KOTTime", dateTime.ToString("hh:mm tt"));
            cmdKot.Parameters.AddWithValue("@total", lblTotal.Text);
            cmdKot.Parameters.AddWithValue("@GstAmount", lblgst.Text);
            cmdKot.Parameters.AddWithValue("@Grandtotal", lblgrandtotal.Text);

            int kotId = Convert.ToInt32(cmdKot.ExecuteScalar());

            foreach (var it in items)
            {
                decimal amount = Convert.ToDecimal(it.item_rate) * Convert.ToInt32(it.qty);

                SqlCommand cmdItem = new SqlCommand(@"INSERT INTO KOT_Detail (KOT_ID, ItemName, Rate, Qty, Amount, sku, gst_per) VALUES (@KOT_ID, @ItemName, @Rate, @Qty, @Amount, @SKU, @GST)",
                con, trans);

                cmdItem.Parameters.AddWithValue("@KOT_ID", kotId);
                cmdItem.Parameters.AddWithValue("@ItemName", it.item_name);
                cmdItem.Parameters.AddWithValue("@Rate", it.item_rate);
                cmdItem.Parameters.AddWithValue("@Qty", it.qty);
                cmdItem.Parameters.AddWithValue("@Amount", amount);
                cmdItem.Parameters.AddWithValue("@SKU", it.item_id);
                cmdItem.Parameters.AddWithValue("@GST", it.gst_per);

                cmdItem.ExecuteNonQuery();
            }

            trans.Commit();
            con.Close();

            Session["SelectedItems_" + tableNo] = null;

            ClientScript.RegisterStartupScript(this.GetType(),
                "alertRedirect",
                "alert('Order Saved Successfully!'); window.location='kotbilling1.aspx';",
                true);
        }
        catch (Exception ex)
        {
            trans.Rollback();
            con.Close();

            ClientScript.RegisterStartupScript(this.GetType(),
                "alert", "alert('Error: " + ex.Message.Replace("'", "") + "');", true);
        }
    }

    public void bindkot()
    {
        string query = "SELECT STUFF((SELECT DISTINCT ',' + kot_no FROM Restaurant WHERE Table_no=@TableNo AND Bill_print='0' FOR XML PATH('')), 1, 1, '') AS kot_no,STUFF((SELECT DISTINCT ',' + Bill_no FROM Restaurant WHERE Table_no=@TableNo AND Bill_print='0' FOR XML PATH('')), 1, 1, '') AS bill";

        SqlDataAdapter sda = new SqlDataAdapter(query, cl.con);
        sda.SelectCommand.Parameters.AddWithValue("@TableNo", lbltableno.Text);
        DataTable dt = new DataTable();
        sda.Fill(dt);

        if (dt.Rows.Count > 0)
        {
            string kot = dt.Rows[0]["kot_no"].ToString();
            string Bill_no = dt.Rows[0]["bill"].ToString();
            if (kot != "" && kot != null && kot != " " && Bill_no != "" && Bill_no != null && Bill_no != " ")
            {
                lblbillno.Text = dt.Rows[0]["bill"].ToString();
            }             
        }
    }

}