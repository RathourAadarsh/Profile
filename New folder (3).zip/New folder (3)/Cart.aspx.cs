﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Cart : System.Web.UI.Page
{
    Class1 cl = new Class1();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {

        }
    }
    public class CartItem
    {
        public decimal price { get; set; }
        public int qty { get; set; }
    }

    [WebMethod]
    public static string SaveOrder(string cartData, decimal grandTotal, string paymentMode)
    {
        Class1 cl = new Class1();
        JavaScriptSerializer js = new JavaScriptSerializer();
        var cart = js.Deserialize<Dictionary<string, CartItem>>(cartData);

        cl.con.Open();
        SqlTransaction trans = cl.con.BeginTransaction();

        try
        {
            string masterQuery = "INSERT INTO OrderMaster1 (OrderDate,TotalAmount,PaymentMode) OUTPUT INSERTED.OrderId VALUES (@date,@total,@mode)";
            SqlCommand masterCmd = new SqlCommand(masterQuery, cl.con, trans);
            masterCmd.Parameters.AddWithValue("@date", DateTime.Now);
            masterCmd.Parameters.AddWithValue("@total", grandTotal);
            masterCmd.Parameters.AddWithValue("@mode", paymentMode);

            int orderId = (int)masterCmd.ExecuteScalar();
            foreach (var item in cart)
            {
                string detailQuery = "INSERT INTO OrderDetail (OrderId,ItemName,Qty,Price,Amount) VALUES (@orderId,@name,@qty,@price,@amount)";
                SqlCommand detailCmd = new SqlCommand(detailQuery, cl.con, trans);

                detailCmd.Parameters.AddWithValue("@orderId", orderId);
                detailCmd.Parameters.AddWithValue("@name", item.Key);
                detailCmd.Parameters.AddWithValue("@qty", item.Value.qty);
                detailCmd.Parameters.AddWithValue("@price", item.Value.price);
                detailCmd.Parameters.AddWithValue("@amount", item.Value.qty * item.Value.price);

                detailCmd.ExecuteNonQuery();
            }

            trans.Commit();
            return orderId.ToString();
        }
        catch 
        {
            trans.Rollback();
            return "Error";
        }
    }
}
