﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Newpage : System.Web.UI.Page
{
    Class1 cl = new Class1();
    public static TimeZoneInfo timeZoneInfo = TimeZoneInfo.FindSystemTimeZoneById("India Standard Time");
    public static DateTime dateTime;

    protected void Page_Load(object sender, EventArgs e)
    {
        dateTime = TimeZoneInfo.ConvertTime(DateTime.Now, timeZoneInfo);
        if (!IsPostBack)
        {
           
            string tableNo = Request.QueryString["tblno"];

            if (Session["SelectedItems_" + tableNo] != null)
            {
                List<Itemdata> items = (List<Itemdata>)Session["SelectedItems_" + tableNo];

                items = items.Where(x => Convert.ToInt32(x.qty) > 0).ToList();

                Session["SelectedItems_" + tableNo] = items;

                string json = new JavaScriptSerializer().Serialize(items);

                ScriptManager.RegisterStartupScript(
                    this,
                    this.GetType(),
                    "fillData",
                    "Sys.Application.add_load(function(){ restoreSelectedItems(" + json + "); });",
                    true
                );
            }
            BindGroupData();
        }
    }
    private void BindGroupData()
    {
        SqlCommand cmd = new SqlCommand("SELECT id.SKU as item_id, ig.Item_G_Name AS group_name, id.item_name, id.item_sale_rate, ('../' + id.Productimage) AS Productimage FROM Item_detail id INNER JOIN item_group_master ig ON id.item_group_name = ig.Item_G_Name ORDER BY ig.Item_G_Name, id.item_name", cl.con);
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataTable dt = new DataTable();
        da.Fill(dt);
        if (dt.Rows.Count > 0)
        {
            var groups = dt.AsEnumerable()
                           .GroupBy(r => r.Field<string>("group_name"))
                           .Select(g => new
                           {
                               GroupName = g.Key,
                               Items = g.CopyToDataTable(),
                               ItemCount = g.Count()
                           }).ToList();
            rptGroup.DataSource = groups;
            rptGroup.DataBind();
            rptGroupMenu.DataSource = groups.Select(x => new
            {
                GroupName = x.GroupName,
                ItemCount = x.ItemCount
            });
            rptGroupMenu.DataBind();
        }
    }
    protected void rptGroup_ItemDataBound(object sender, RepeaterItemEventArgs e)
    {
        if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
        {
            dynamic group = e.Item.DataItem;
            Repeater rptItems = (Repeater)e.Item.FindControl("rptItems");
            rptItems.DataSource = group.Items;
            rptItems.DataBind();
        }
    }
    protected void btnNext_Click(object sender, EventArgs e)
    {
       
        hfItems.Value = Request.QueryString["tblno"].ToString();
        string json = hfItems.Value;
        if (string.IsNullOrEmpty(json))
        {
            ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert('No item selected!');", true);
            return;
        }

        JavaScriptSerializer js = new JavaScriptSerializer();
        List<Itemdata> items = js.Deserialize<List<Itemdata>>(json);

        if (items == null || items.Count == 0)
        {
            ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert('No valid item data found!');", true);
            return;
        }

        string tableNo = "";
        int kotFlag = 1;
        int billPrint = 0;

        using (SqlCommand cmd = new SqlCommand("SELECT TOP 1 Table_No FROM Restaurant WHERE kot_flag=1 AND Bill_print=0", cl.con))
        {
            if (cl.con.State == ConnectionState.Closed)
                cl.con.Open();

            object result = cmd.ExecuteScalar();
            cl.con.Close();

            if (result != null)
                tableNo = result.ToString();
        }
        foreach (var item in items)
        {
            item.TableNo = tableNo;
            item.kot_flag = kotFlag;
            item.Bill_print = billPrint;
        }

        Session["SelectedItems"] = items;

        Response.Redirect("OrderSummary.aspx");
    }

    private void BindSelectedItems(List<Itemdata> items)
    {
        itemCount.InnerText = items.Count.ToString();
    }
    [WebMethod]
    public static string SaveItems(List<Itemdata> items)
    {
        HttpContext.Current.Session["SelectedItems"] = items;
        return "OK";
    }

}