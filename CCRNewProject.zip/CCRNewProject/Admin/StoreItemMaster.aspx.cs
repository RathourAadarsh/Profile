﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class Admin_StoreItemMaster : System.Web.UI.Page
{
    public static TimeZoneInfo timeZoneInfo = TimeZoneInfo.FindSystemTimeZoneById("India Standard Time");
    public static DateTime dateTime;
    HttpCookie lgdcookie;
    Class1 cl = new Class1();
    protected void Page_Load(object sender, EventArgs e)
    {
        lgdcookie = Request.Cookies["loggeduser"];
        dateTime = TimeZoneInfo.ConvertTime(DateTime.Now, timeZoneInfo);

        if (lgdcookie != null && !string.IsNullOrEmpty(lgdcookie["UserName"]))
        {
            if (!IsPostBack)
            {
                bindetail();
                txtitemcode.Text = cl.Scalar("SELECT isnull(Max(sku+1),1)sku from StoreItem_detail where deactive='0'");
                txtitemcode.ReadOnly = true;
                bindgroup();
            }
        }
        else
        {
            Response.Redirect("Login.aspx");
        }
    }

    public void bindgroup()
    {
        try
        {
            string str = "select item_g_id,item_g_name from storeitem_group_master where deactive='0' order by item_g_name";
            SqlCommand cmd = new SqlCommand(str, cl.con);
            SqlDataAdapter adp = new SqlDataAdapter(cmd);
            DataTable dt1 = new DataTable();
            adp.Fill(dt1);
            if (dt1.Rows.Count > 0)
            {
                ddlgroup.DataSource = dt1;
                ddlgroup.DataTextField = "item_g_name";
                ddlgroup.DataValueField = "item_g_id";
                ddlgroup.DataBind();
                ddlgroup.Items.Insert(0, new ListItem("--Select--", "0"));
            }
        }
        catch (Exception)
        {

        }
    }
    protected void btnsave_Click(object sender, EventArgs e)
    {
        try
        {
            if(txtitemcode.Text=="" || txtitemname.Text==""||ddlgroup.SelectedValue=="0" || ddlunit.SelectedValue=="")
            {
                string message = "Please Fill All Fields !!";
                string type = "warning";
                ScriptManager.RegisterStartupScript(this, this.GetType(), "Script", "savealert('" + message + "','" + type + "')", true);
                return;
            }
            else
            {
                if (btnsave.Text == "Save")
                {
                    string ins = lgdcookie["username"];
                    string query = "insert into StoreItem_detail (item_group_name,sku,item_name,deactive,item_unit,indate,instime,insuser) values('" + ddlgroup.SelectedValue + "','" + txtitemcode.Text + "','" + txtitemname.Text + "','0','" + ddlunit.SelectedValue + "','" + dateTime.ToString("yyyy-MM-dd") + "','" + dateTime.ToString("hh:mm:ss tt") + "','" + lgdcookie["username"].ToString() + "')";
                    SqlCommand cmd = new SqlCommand(query, cl.con);
                    cl.con.Open();
                    int n = cmd.ExecuteNonQuery();
                    cl.con.Close();
                    if (n > 0)
                    {
                        bindetail();
                        string redirectUrl = "StoreItemMaster.aspx";
                        string message = "Record Saved Successfully !!";
                        string type = "success";
                        string script = "savealert('" + message + "', '" + type + "'); setTimeout(function() {{ window.location.href = '" + redirectUrl + "'; }}, 1000);"; ScriptManager.RegisterStartupScript(this, this.GetType(), "Script", script, true);
                        return;
                    }
                }
                else
                {
                    string query = @"UPDATE StoreItem_detail 
                 SET item_group_name = @group,
                     item_name = @name,
                     item_unit = @unit,
                     upddate = @indate,
                     updtime = @instime,
                     upduser = @user
                 WHERE sku = @sku";

                    SqlCommand cmd = new SqlCommand(query, cl.con);
                    cmd.Parameters.AddWithValue("@group", ddlgroup.SelectedValue);
                    cmd.Parameters.AddWithValue("@name", txtitemname.Text);
                    cmd.Parameters.AddWithValue("@unit", ddlunit.SelectedValue);
                    cmd.Parameters.AddWithValue("@indate", dateTime.ToString("yyyy-MM-dd"));
                    cmd.Parameters.AddWithValue("@instime", dateTime.ToString("hh:mm:ss tt"));
                    cmd.Parameters.AddWithValue("@user", lgdcookie["username"].ToString());
                    cmd.Parameters.AddWithValue("@sku", txtitemcode.Text);

                    cl.con.Open();
                    int n = cmd.ExecuteNonQuery();
                    cl.con.Close();
                    if (n > 0)
                    {
                        bindetail();
                        ScriptManager.RegisterStartupScript(this,this.GetType(),"Script","savealert('Record Updated Successfully !!','success'); setTimeout(function(){ window.location='StoreItemMaster.aspx'; },1000);",
                            true
                        );
                    }
                }
            }
        }
        catch(Exception ex)
        {

        }
    }

    protected void btnback_Click(object sender, EventArgs e)
    {
        Response.Redirect("Dashboard.aspx");
    }

    protected void btnedit_Click(object sender, EventArgs e)
    {
        try
        {
            Button button1 = (Button)sender;
            ListViewItem item = (ListViewItem)button1.NamingContainer;
            Label lblid1 = (Label)item.FindControl("lblcode");
            string query = "select item_group_name,sku,item_name,deactive,item_unit from StoreItem_detail where deactive='0' and sku='" + lblid1.Text + "'";
            SqlDataAdapter sda = new SqlDataAdapter(query, cl.con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                ddlgroup.SelectedValue = dt.Rows[0]["item_group_name"].ToString();
                txtitemcode.Text= dt.Rows[0]["sku"].ToString();
                txtitemname.Text= dt.Rows[0]["item_name"].ToString();
                ddlunit.SelectedValue= dt.Rows[0]["item_unit"].ToString();
                btnsave.Text = "Update";
            }
            else
            {
                string message = "Something Went Wrong !!";
                string type = "error";
                ScriptManager.RegisterStartupScript(this, this.GetType(), "Script", "savealert('" + message + "','" + type + "')", true);
                return;
            }
        }
        catch (Exception ex)
        {

        }
    }

    protected void btndelete_Click(object sender, EventArgs e)
    {
        try
        {
            Button button1 = (Button)sender;
            ListViewItem item = (ListViewItem)button1.NamingContainer;
            Label lblid1 = (Label)item.FindControl("lblcode");
            Button btndelete = (Button)item.FindControl("btndelete");
            if (btndelete.Text == "De-Active")
            {
                string up = "update StoreItem_detail set deactive='1' where sku='" + lblid1.Text + "'";
                cl.execute(up);
                bindetail();
                string redirectUrl = "StoreItemMaster.aspx";
                string message = "Record Deactivated Successfully !!";
                string type = "info";
                string script = "savealert('" + message + "', '" + type + "'); setTimeout(function() {{ window.location.href = '" + redirectUrl + "'; }},1500);"; ScriptManager.RegisterStartupScript(this, this.GetType(), "Script", script, true);
            }
            else if (btndelete.Text == "Active")
            {
                string up = "update StoreItem_detail set deactive='0' where sku='" + lblid1.Text + "'";
                cl.execute(up);
                bindetail();
                string redirectUrl = "StoreItemMaster.aspx";
                string message = "Record Activated Successfully !!";
                string type = "info";
                string script = "savealert('" + message + "', '" + type + "'); setTimeout(function() {{ window.location.href = '" + redirectUrl + "'; }},1500);"; ScriptManager.RegisterStartupScript(this, this.GetType(), "Script", script, true);
            }
        }
        catch (Exception ex)
        {

        }
    }
    public void bindetail()
    {
        try
        {
            string query = "select item_g_name as item_group_name,s.sku,s.item_name,s.deactive,s.item_unit,case when(s.Deactive='0') then 'De-Active' else 'Active' end as inactive from StoreItem_detail s inner join storeitem_group_Master spm on s.item_group_name=spm.Item_G_Id";
            SqlDataAdapter sda = new SqlDataAdapter(query, cl.con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                listview2.DataSource = dt;
                listview2.DataBind();
            }
        }
        catch (Exception ex)
        {

        }
    }
}