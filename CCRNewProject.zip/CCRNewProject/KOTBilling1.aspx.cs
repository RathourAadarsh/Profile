﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class KOTBilling1 : System.Web.UI.Page
{
    Class1 cl = new Class1();
    //Cls_connection cls = new Cls_connection();
    public static TimeZoneInfo timeZoneInfo = TimeZoneInfo.FindSystemTimeZoneById("India Standard Time");
    public static DateTime dateTime;
    public static string table = "";
    protected void Page_Load(object sender, EventArgs e)
    {
        dateTime = TimeZoneInfo.ConvertTime(DateTime.Now, timeZoneInfo);
        tablestatus();
        //SetRedTables();
        SetBlueTables();

    }
    protected void tbl_1_Click(object sender, ImageClickEventArgs e)
    {
        table = "01";
        Response.Redirect("Newpage12.aspx?tblno=" + table);
    }
    protected void tbl_2_Click(object sender, ImageClickEventArgs e)
    {
        table = "02";
        Response.Redirect("Newpage12.aspx?tblno=" + table + "");
    }
    protected void tbl_3_Click(object sender, ImageClickEventArgs e)
    {
        table = "03";
        Response.Redirect("Newpage12.aspx?tblno=" + table + "");
    }
    protected void tbl_4_Click(object sender, ImageClickEventArgs e)
    {
        table = "04";
        Response.Redirect("Newpage12.aspx?tblno=" + table + "");
    }
    protected void tbl_5_Click(object sender, ImageClickEventArgs e)
    {
        table = "05";
        Response.Redirect("Newpage12.aspx?tblno=" + table + "");
    }
    protected void tbl_6_Click(object sender, ImageClickEventArgs e)
    {
        table = "06";
        Response.Redirect("Newpage12.aspx?tblno=" + table + "");
    }
    protected void tbl_7_Click(object sender, ImageClickEventArgs e)
    {
        table = "07";
        Response.Redirect("Newpage12.aspx?tblno=" + table + "");
    }
    protected void tbl_8_Click(object sender, ImageClickEventArgs e)
    {
        table = "08";
        Response.Redirect("Newpage12.aspx?tblno=" + table + "");
    }
    protected void tbl_9_Click(object sender, ImageClickEventArgs e)
    {
        table = "09";
        Response.Redirect("Newpage12.aspx?tblno=" + table + "");

    }
    protected void tbl_10_Click(object sender, ImageClickEventArgs e)
    {
        table = "10";
        Response.Redirect("Newpage12.aspx?tblno=" + table + "");
    }
    protected void tbl_11_Click(object sender, ImageClickEventArgs e)
    {
        table = "11";
        Response.Redirect("Newpage12.aspx?tblno=" + table + "");
    }
    protected void tbl_12_Click(object sender, ImageClickEventArgs e)
    {
        table = "12";
        Response.Redirect("Newpage12.aspx?tblno=" + table + "");
    }
    protected void tbl_13_Click(object sender, ImageClickEventArgs e)
    {
        table = "13";
        Response.Redirect("Newpage12.aspx?tblno=" + table + "");
    }

    protected void tbl_14_Click(object sender, ImageClickEventArgs e)
    {
        table = "14";
        Response.Redirect("Newpage12.aspx?tblno=" + table + "");
    }
    protected void tbl_15_Click(object sender, ImageClickEventArgs e)
    {
        table = "15";
        Response.Redirect("Newpage12.aspx?tblno=" + table + "");
    }
    protected void tbl_16_Click(object sender, ImageClickEventArgs e)
    {
        table = "16";
        Response.Redirect("Newpage12.aspx?tblno=" + table + "");
    }
    protected void tbl_17_Click(object sender, ImageClickEventArgs e)
    {
        table = "17";
        Response.Redirect("Newpage12.aspx?tblno=" + table + "");
    }
    protected void tbl_18_Click(object sender, ImageClickEventArgs e)
    {
        table = "18";
        Response.Redirect("Newpage12.aspx?tblno=" + table + "");
    }
    protected void tbl_19_Click(object sender, ImageClickEventArgs e)
    {
        table = "19";
        Response.Redirect("Newpage12.aspx?tblno=" + table + "");
    }

    public void tablestatus()
    {
        string table = "";
        string tab1 = "select Table_No from kot_master where isclosed=0 and isprinted=0";
        SqlDataAdapter sda = new SqlDataAdapter(tab1, cl.con);
        DataTable dt = new DataTable();
        sda.Fill(dt);

        foreach (DataRow row in dt.Rows)
        {
            table = row["table_no"].ToString();

            switch (table)
            {
                case "01":
                    tbl_1.ImageUrl = "red/1.png";
                    break;

                case "02":
                    tbl_2.ImageUrl = "red/2.png";
                    break;

                case "03":
                    tbl_3.ImageUrl = "red/3.png";
                    break;

                case "04":
                    tbl_4.ImageUrl = "red/4.png";
                    break;

                case "05":
                    tbl_5.ImageUrl = "red/5.png";
                    break;

                case "06":
                    tbl_6.ImageUrl = "red/6.png";
                    break;

                case "07":
                    tbl_7.ImageUrl = "red/7.png";
                    break;

                case "08":
                    tbl_8.ImageUrl = "red/8.png";
                    break;

                case "09":
                    tbl_9.ImageUrl = "red/9.png";
                    break;

                case "10":
                    tbl_10.ImageUrl = "red/10.png";
                    break;

                case "11":
                    tbl_11.ImageUrl = "red/11.png";
                    break;

                case "12":
                    tbl_12.ImageUrl = "red/12.png";
                    break;

                case "13":
                    tbl_13.ImageUrl = "red/13.png";
                    break;

                case "14":
                    tbl_14.ImageUrl = "red/14.png";
                    break;

                case "15":
                    tbl_15.ImageUrl = "red/15.png";
                    break;

                case "16":
                    tbl_16.ImageUrl = "red/16.png";
                    break;

                case "17":
                    tbl_17.ImageUrl = "red/17.png";
                    break;

                case "18":
                    tbl_18.ImageUrl = "red/18.png";
                    break;

                case "19":
                    tbl_19.ImageUrl = "red/19.png";
                    break;
            }
        }
    }
    public void SetBlueTables()
    {
        string table = "";
        string tab1 = "select Table_No from Restaurant where flagblue = 0";
        SqlDataAdapter sda = new SqlDataAdapter(tab1, cl.con);
        DataTable dt = new DataTable();
        sda.Fill(dt);

        foreach (DataRow row in dt.Rows)
        {
            table = row["table_no"].ToString();

            switch (table)
            {
                case "01":
                    tbl_1.ImageUrl = "Blue/1.png";
                    break;

                case "02":
                    tbl_2.ImageUrl = "Blue/2.png";
                    break;

                case "03":
                    tbl_3.ImageUrl = "Blue/3.png";
                    break;

                case "04":
                    tbl_4.ImageUrl = "Blue/4.png";
                    break;

                case "05":
                    tbl_5.ImageUrl = "Blue/5.png";
                    break;

                case "06":
                    tbl_6.ImageUrl = "Blue/6.png";
                    break;

                case "07":
                    tbl_7.ImageUrl = "Blue/7.png";
                    break;

                case "08":
                    tbl_8.ImageUrl = "Blue/8.png";
                    break;

                case "09":
                    tbl_9.ImageUrl = "Blue/9.png";
                    break;

                case "10":
                    tbl_10.ImageUrl = "Blue/10.png";
                    break;

                case "11":
                    tbl_11.ImageUrl = "Blue/11.png";
                    break;

                case "12":
                    tbl_12.ImageUrl = "Blue/12.png";
                    break;

                case "13":
                    tbl_13.ImageUrl = "Blue/13.png";
                    break;

                case "14":
                    tbl_14.ImageUrl = "Blue/14.png";
                    break;

                case "15":
                    tbl_15.ImageUrl = "Blue/15.png";
                    break;

                case "16":
                    tbl_16.ImageUrl = "Blue/16.png";
                    break;

                case "17":
                    tbl_17.ImageUrl = "Blue/17.png";
                    break;

                case "18":
                    tbl_18.ImageUrl = "Blue/18.png";
                    break;

                case "19":
                    tbl_19.ImageUrl = "Blue/19.png";
                    break;
            }
        }
    }          
}