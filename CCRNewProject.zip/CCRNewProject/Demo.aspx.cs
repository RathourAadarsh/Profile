﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Demo : System.Web.UI.Page
{
    Class1 cl = new Class1();

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            LoadTree();
        }
    }

    void LoadTree()
    {
        string q1 = "select item_g_id, item_g_name from Item_group_master";
        SqlDataAdapter sda1 = new SqlDataAdapter(q1, cl.con);
        DataTable dtGroup = new DataTable();
        sda1.Fill(dtGroup);

        rptGroup.DataSource = dtGroup;
        rptGroup.DataBind();
    }

    protected void rptGroup_ItemDataBound(object sender, RepeaterItemEventArgs e)
    {
        if (e.Item.ItemType == ListItemType.Item ||
            e.Item.ItemType == ListItemType.AlternatingItem)
        {
            DataRowView drv = (DataRowView)e.Item.DataItem;

            string q2 = "select Sku, item_name from item_detail where item_group_name=@gid";
            SqlDataAdapter sda2 = new SqlDataAdapter(q2, cl.con);
            sda2.SelectCommand.Parameters.AddWithValue("@gid", drv["item_g_name"]);

            DataTable dtItem = new DataTable();
            sda2.Fill(dtItem);

            Repeater rptItem = (Repeater)e.Item.FindControl("rptItem");
            rptItem.DataSource = dtItem;
            rptItem.DataBind();
        }
    }
}