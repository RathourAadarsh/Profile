﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Dashboard : System.Web.UI.Page
{
    Class1 cl = new Class1();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            BindTables();
        }
    }
    void BindTables()
    {
        DataTable dt = new DataTable();
        cl.con.Open();
        SqlDataAdapter da = new SqlDataAdapter("SELECT Table_no FROM Table_Master WHERE Useflag = 1 ORDER BY Id", cl.con);
        da.Fill(dt);
        cl.con.Close();
        rptBoxes.DataSource = dt;
        rptBoxes.DataBind();
    }


    protected void rptBoxes_ItemCommand(object source, RepeaterCommandEventArgs e)
    {
        if(e.CommandName == "SelectTable")
        {
            string tableno = e.CommandArgument.ToString();
            Response.Redirect("Billing.aspx?table_no=" + tableno);
        }
    }
}