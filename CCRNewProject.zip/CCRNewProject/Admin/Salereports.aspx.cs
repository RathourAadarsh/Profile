﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;

public partial class Admin_Salereports : System.Web.UI.Page
{
    Class1 cl = new Class1();  
    public static TimeZoneInfo timeZoneInfo = TimeZoneInfo.FindSystemTimeZoneById("India Standard Time");
    public static DateTime dateTime;
    protected void Page_Load(object sender, EventArgs e)
    {
        dateTime = TimeZoneInfo.ConvertTime(DateTime.Now, timeZoneInfo);
        if (!IsPostBack)
        {

            txtfrom.Text = dateTime.ToString("yyyy-MM-dd");
            txtto.Text = dateTime.ToString("yyyy-MM-dd");
            Bindcate();
           

        }
    }
    public void Bindcate()
    {
        string query = "SELECT * from Item_group_Master order by item_g_name";
        SqlDataAdapter sda = new SqlDataAdapter(query, cl.con);
        DataTable dt = new DataTable();
        sda.Fill(dt);
        if (dt.Rows.Count > 0)
        {
            ddlcategory.DataSource = dt;
            ddlcategory.DataTextField = "item_g_name";
            ddlcategory.DataValueField = "item_g_id";
            ddlcategory.DataBind();
            ddlcategory.Items.Insert(0, new ListItem("All Category", "0"));
        }
    }    
    protected void btnpreview_Click(object sender, EventArgs e)
    {
        try
        {     
            if (string.IsNullOrWhiteSpace(txtfrom.Text) || string.IsNullOrWhiteSpace(txtto.Text))
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "Script",
                    "savealert('Please select both From and To date.!!','warning');", true);
                return;
            }

            DateTime fromDate = DateTime.Parse(txtfrom.Text);
            DateTime toDate = DateTime.Parse(txtto.Text);
            from.Text = fromDate.ToString("dd-MM-yyyy");
            lbto.Text = toDate.ToString("dd-MM-yyyy");
            int categoryId = Convert.ToInt32(ddlcategory.SelectedValue);
            string baseQuery = @"WITH BillLevel AS
(
    SELECT
        bm.bill_id,
        ISNULL(bm.discount,0) AS discount,
        ISNULL(bm.tax,0) AS tax,
        ISNULL(bm.grandtotal,0) AS grandtotal,
        ISNULL(bm.service_charge,0) AS service_charge,
        ISNULL(bm.roundoff,0) AS roundoff
    FROM bill_master bm
    WHERE bm.bill_date >= @fromdate
      AND bm.bill_date < DATEADD(DAY,1,@todate)
),

BillTotals AS
(
    SELECT
        SUM(discount) AS TotalDiscount,
        SUM(tax) AS TotalTax,
        SUM(grandtotal) AS TotalSales,
        SUM(grandtotal - discount) AS NetSales,
        SUM(service_charge) AS ServiceCharge,
        MAX(roundoff) AS RoundOff
    FROM BillLevel
),

CategoryData AS
(
    SELECT  
        ig.item_g_name AS Category,
        COUNT(DISTINCT bd.itemname) AS OrderCount,
        SUM(bd.qty) AS TotalItems,
        SUM(bd.amount) AS NetAmount,
        SUM(CAST(bd.amount * bd.gst_per / 100.0 AS DECIMAL(10,2))) AS TotalTax,
        SUM(bd.amount) + SUM(bd.amount * bd.gst_per / 100.0) AS TotalSales,
        SUM(BillNet.NetSalePerBill) AS NetSales  
    FROM bill_detail bd
    INNER JOIN item_detail id ON bd.itemname = id.item_name
    INNER JOIN item_group_master ig ON id.item_group_name = ig.item_g_id
    INNER JOIN 
        (
            SELECT bl.bill_id, bl.grandtotal - bl.discount AS NetSalePerBill
            FROM BillLevel bl
        ) BillNet ON bd.bill_id = BillNet.bill_id
    WHERE (@categoryId = 0 OR ig.item_g_id = @categoryId)
    GROUP BY ig.item_g_name
)
,

Totals AS
(
    SELECT  
        COUNT(*) AS CategoryCount,
        SUM(OrderCount) AS OrderCount,
        SUM(TotalItems) AS TotalItems,
        SUM(NetAmount) AS NetAmount,
        SUM(TotalTax) AS TotalTax,
        SUM(TotalSales) AS TotalSales
    FROM CategoryData
)

SELECT  
    Category,
    OrderCount,
    TotalItems,
    NetAmount,
    TotalDiscount,
    TotalTax,
    TotalSales,
    NetSales,
    SalePercent
FROM
(
    -- TOTAL
    SELECT  
        'TOTAL' AS Category,
        t.OrderCount,
        t.TotalItems,
        t.NetAmount,
        bt.TotalDiscount,
        t.TotalTax,
        t.TotalSales,
       (t.NetAmount- bt.TotalDiscount) as NetSales,
        NULL AS SalePercent,
        1 AS SortOrder
    FROM Totals t
    CROSS JOIN BillTotals bt

    UNION ALL
    -- MIN
    SELECT  
        'MIN',
        MIN(OrderCount),
        MIN(TotalItems),
        MIN(NetAmount),
        0,
        MIN(TotalTax),
        MIN(TotalSales),
        MIN(NetAmount),
        NULL,
        2
    FROM CategoryData

    UNION ALL
    SELECT  
        'MAX',
        MAX(OrderCount),
        MAX(TotalItems),
        MAX(NetAmount),
        0,
        MAX(TotalTax),
        MAX(TotalSales),
        MAX(NetAmount),
        NULL,
        3
    FROM CategoryData

    UNION ALL
    SELECT  
        'AVG',
        CAST(t.OrderCount * 1.0 / t.CategoryCount AS INT),
        CAST(t.TotalItems * 1.0 / t.CategoryCount AS INT),
        CAST(t.NetAmount * 1.0 / t.CategoryCount AS INT),
        0,
        CAST(t.TotalTax * 1.0 / t.CategoryCount AS INT),
        CAST(t.TotalSales * 1.0 / t.CategoryCount AS INT),
        CAST(NetAmount * 1.0 / t.CategoryCount AS INT),
        NULL,
        4
    FROM Totals t
      UNION ALL
SELECT  
    '' AS Category,
    NULL AS OrderCount,
    NULL AS TotalItems,
    NULL AS NetAmount,
    NULL AS TotalDiscount,
    NULL AS TotalTax,
    NULL AS TotalSales,
    NULL AS NetSales,
    NULL AS SalePercent,
    4.5 AS SortOrder

    UNION ALL
    SELECT  
        c.Category,
        c.OrderCount,
        c.TotalItems,
        c.NetAmount,
        0,
        c.TotalTax,
        c.TotalSales,
        c.NetAmount,
        CAST(c.TotalSales * 100.0 / NULLIF(bt.TotalSales,0) AS DECIMAL(10,2)),
        5
    FROM CategoryData c
    CROSS JOIN BillTotals bt

    UNION ALL
    SELECT  
        'ServiceCharge',
        0,0,0,0,0,
        bt.ServiceCharge,
        0,
        NULL,
        6
    FROM BillTotals bt

    UNION ALL
    SELECT  
        'RoundOff',
        0,0,0,0,0,
        bt.RoundOff,
        0,
        NULL,
        7
    FROM BillTotals bt
) X
ORDER BY X.SortOrder, X.Category";  
            
            SqlCommand cmd = new SqlCommand(baseQuery, cl.con);
            cmd.Parameters.AddWithValue("@fromdate", Convert.ToDateTime(fromDate));
            cmd.Parameters.AddWithValue("@todate", Convert.ToDateTime(toDate));
            cmd.Parameters.AddWithValue("@categoryId", categoryId);
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            sda.Fill(dt);

            if (dt.Rows.Count > 0)
            {
                rptStock.DataSource = dt;
                rptStock.DataBind();
            }
            else
            {
                rptStock.DataSource = null;
                rptStock.DataBind();
                ScriptManager.RegisterStartupScript(this, this.GetType(), "Script", "savealert('No data found !!','warning');", true);
            }
        }
        catch (Exception ex)
        {
            Response.Write("Error: " + ex.Message);
        }
    }
    protected void btnback_Click(object sender, EventArgs e)
    {
        Response.Redirect("Salereports.aspx");
    }
    protected void btnExportExcel_Click(object sender, EventArgs e)
    {
        DateTime fromDate = DateTime.Parse(txtfrom.Text);
        DateTime toDate = DateTime.Parse(txtto.Text);
        int categoryId = Convert.ToInt32(ddlcategory.SelectedValue);

        DataTable dt = GetSaleReportData(fromDate, toDate, categoryId);

        if (dt.Rows.Count == 0)
        {
            ScriptManager.RegisterStartupScript(this, this.GetType(),
                "Script", "savealert('No data to export','warning');", true);
            return;
        }

        ExportToExcel(dt, fromDate, toDate, ddlcategory.SelectedItem.Text);
    }
    private DataTable GetSaleReportData(DateTime fromDate, DateTime toDate, int categoryId)
    {
        string baseQuery = @"WITH BillLevel AS
(
    SELECT
        bm.bill_id,
        ISNULL(bm.discount,0) AS discount,
        ISNULL(bm.tax,0) AS tax,
        ISNULL(bm.grandtotal,0) AS grandtotal,
        ISNULL(bm.service_charge,0) AS service_charge,
        ISNULL(bm.roundoff,0) AS roundoff
    FROM bill_master bm
    WHERE bm.bill_date >= @fromdate
      AND bm.bill_date < DATEADD(DAY,1,@todate)
),

BillTotals AS
(
    SELECT
        SUM(discount) AS TotalDiscount,
        SUM(tax) AS TotalTax,
        SUM(grandtotal) AS TotalSales,
        SUM(grandtotal - discount) AS NetSales,
        SUM(service_charge) AS ServiceCharge,
        MAX(roundoff) AS RoundOff
    FROM BillLevel
),

CategoryData AS
(
    SELECT  
        ig.item_g_name AS Category,
        COUNT(DISTINCT bd.itemname) AS OrderCount,
        SUM(bd.qty) AS TotalItems,
        SUM(bd.amount) AS NetAmount,
        SUM(bd.amount * bd.gst_per / 100.0) AS TotalTax,
        SUM(bd.amount) + SUM(bd.amount * bd.gst_per / 100.0) AS TotalSales,
        SUM(BillNet.NetSalePerBill) AS NetSales  
    FROM bill_detail bd
    INNER JOIN item_detail id ON bd.itemname = id.item_name
    INNER JOIN item_group_master ig ON id.item_group_name = ig.item_g_id
    INNER JOIN 
        (
            SELECT bl.bill_id, bl.grandtotal - bl.discount AS NetSalePerBill
            FROM BillLevel bl
        ) BillNet ON bd.bill_id = BillNet.bill_id
    WHERE (@categoryId = 0 OR ig.item_g_id = @categoryId)
    GROUP BY ig.item_g_name
)
,

Totals AS
(
    SELECT  
        COUNT(*) AS CategoryCount,
        SUM(OrderCount) AS OrderCount,
        SUM(TotalItems) AS TotalItems,
        SUM(NetAmount) AS NetAmount,
        SUM(TotalTax) AS TotalTax,
        SUM(TotalSales) AS TotalSales
    FROM CategoryData
)

SELECT  
    Category,
    OrderCount,
    TotalItems,
    NetAmount,
    TotalDiscount,
    TotalTax,
    TotalSales,
    NetSales,
    SalePercent
FROM
(
    -- TOTAL
    SELECT  
        'TOTAL' AS Category,
        t.OrderCount,
        t.TotalItems,
        t.NetAmount,
        bt.TotalDiscount,
        t.TotalTax,
        t.TotalSales,
       (t.NetAmount- bt.TotalDiscount) as NetSales,
        NULL AS SalePercent,
        1 AS SortOrder
    FROM Totals t
    CROSS JOIN BillTotals bt

    UNION ALL
    -- MIN
    SELECT  
        'MIN',
        MIN(OrderCount),
        MIN(TotalItems),
        MIN(NetAmount),
        0,
        MIN(TotalTax),
        MIN(TotalSales),
        MIN(NetAmount),
        NULL,
        2
    FROM CategoryData

    UNION ALL
    SELECT  
        'MAX',
        MAX(OrderCount),
        MAX(TotalItems),
        MAX(NetAmount),
        0,
        MAX(TotalTax),
        MAX(TotalSales),
        MAX(NetAmount),
        NULL,
        3
    FROM CategoryData

    UNION ALL
    SELECT  
        'AVG',
        CAST(t.OrderCount * 1.0 / t.CategoryCount AS INT),
        CAST(t.TotalItems * 1.0 / t.CategoryCount AS INT),
        CAST(t.NetAmount * 1.0 / t.CategoryCount AS INT),
        0,
        CAST(t.TotalTax * 1.0 / t.CategoryCount AS INT),
        CAST(t.TotalSales * 1.0 / t.CategoryCount AS INT),
        CAST(NetAmount * 1.0 / t.CategoryCount AS INT),
        NULL,
        4
    FROM Totals t

    UNION ALL
    SELECT  
        c.Category,
        c.OrderCount,
        c.TotalItems,
        c.NetAmount,
        0,
        c.TotalTax,
        c.TotalSales,
        c.NetAmount,
        CAST(c.TotalSales * 100.0 / NULLIF(bt.TotalSales,0) AS DECIMAL(10,2)),
        5
    FROM CategoryData c
    CROSS JOIN BillTotals bt

    UNION ALL
    SELECT  
        'ServiceCharge',
        0,0,0,0,0,
        bt.ServiceCharge,
        0,
        NULL,
        6
    FROM BillTotals bt

    UNION ALL
    SELECT  
        'RoundOff',
        0,0,0,0,0,
        bt.RoundOff,
        0,
        NULL,
        7
    FROM BillTotals bt
) X
ORDER BY X.SortOrder, X.Category";
        SqlCommand cmd = new SqlCommand(baseQuery, cl.con);
        cmd.Parameters.AddWithValue("@fromdate", fromDate);
        cmd.Parameters.AddWithValue("@todate", toDate);
        cmd.Parameters.AddWithValue("@categoryId", categoryId);

        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataTable dt = new DataTable();
        da.Fill(dt);
        return dt;
    }

    private void ExportToExcel(DataTable dt, DateTime fromDate, DateTime toDate, string category)
    {
        Response.Clear();
        Response.Buffer = true;
        Response.AddHeader("content-disposition",
            "attachment;filename=SaleReport_" + DateTime.Now.ToString("ddMMyyyy") + ".xls");
        Response.ContentType = "application/vnd.ms-excel";

        System.IO.StringWriter sw = new System.IO.StringWriter();
        HtmlTextWriter hw = new HtmlTextWriter(sw);
        sw.Write("<table border='1'>");
        sw.Write("<tr><td colspan='" + dt.Columns.Count + "' style='font-size:18px;font-weight:bold;text-align:center;'>SALE REPORT</td></tr>");
        sw.Write("<tr><td colspan='" + dt.Columns.Count + "'><b>Charans Club & Resort Pvt. Ltd.</b></td></tr>");
        sw.Write("<tr><td colspan='" + dt.Columns.Count + "'><b>Date Range :</b> " +
                 fromDate.ToString("dd-MM-yyyy") + " to " + toDate.ToString("dd-MM-yyyy") + "</td></tr>");
        sw.Write("<tr><td colspan='" + dt.Columns.Count + "'><b>Category :</b> " + category + "</td></tr>");
        sw.Write("<tr><td colspan='" + dt.Columns.Count + "'></td></tr>");

        /* ===== TABLE HEADER ===== */
        sw.Write("<tr>");
        foreach (DataColumn col in dt.Columns)
            sw.Write("<th style='background:#2f5597;color:white'>" + col.ColumnName + "</th>");
        sw.Write("</tr>");

        /* ===== DATA ===== */
        foreach (DataRow row in dt.Rows)
        {
            sw.Write("<tr>");
            foreach (var cell in row.ItemArray)
                sw.Write("<td>" + cell + "</td>");
            sw.Write("</tr>");
        }
        sw.Write("</table>");

        Response.Write(sw.ToString());
        Response.End();
    }

    public override void VerifyRenderingInServerForm(Control control)
    {
        // Required for Excel export
    }     

}