﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.IO;

public partial class Restaurant_Billing : System.Web.UI.Page
{
    Class1 cl = new Class1();
    public static TimeZoneInfo timeZoneInfo = TimeZoneInfo.FindSystemTimeZoneById("India Standard Time");
    public static DateTime dateTime;
    HttpCookie lgdcookie;
    protected void Page_Load(object sender, EventArgs e)
    {
        lgdcookie = Request.Cookies["loggeduser"];
        if (lgdcookie != null && !string.IsNullOrEmpty(lgdcookie["UserName"]))
        {
            dateTime = TimeZoneInfo.ConvertTime(DateTime.Now, timeZoneInfo);
            if (!IsPostBack)
            {
                if (Request.QueryString["billno"] != null &&
                    Request.QueryString["tableno"] != null)
                {
                    lblbillno.Text = Request.QueryString["billno"];
                    lbltable.Text = Request.QueryString["tableno"];
                    lbltablee.Text = lbltable.Text;
                    bindbill();
                }
            }
        }
    }
    protected void btncancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("Dashboard.aspx");
    }
    protected void btnPrint_Click(object sender, EventArgs e)
    {
        bill.Visible = true;
        bindbill();

        ScriptManager.RegisterStartupScript(
            this,
            this.GetType(),
            "Print",
            "window.print();",
            true
        );
    }

    public void bindbill()
    {
        try
        {
            Label6.Text = lblbillno.Text;
            //Label10.Text = lbltable.Text;
            string query = "SELECT bd.itemname, bd.rate, SUM(bd.qty)  AS qty, SUM(bd.amount) AS amount,CONVERT(nvarchar, bm.bill_date, 103) AS insdate,bm.bill_no,bm.grandtotal,bm.tax,bm.Discount,bm.subtotal FROM Bill_Master bm LEFT JOIN Bill_Detail bd ON bm.bill_id = bd.bill_id WHERE bm.isrunning = 1 and bill_no='" + lblbillno.Text + "' and table_no='" + lbltable.Text + "' GROUP BY bd.itemname,bd.rate,bm.bill_date,bm.bill_no,bm.grandtotal,bm.tax, bm.Discount,bm.subtotal";
            SqlDataAdapter sda = new SqlDataAdapter(query, cl.con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                gridbill.DataSource = dt;
                gridbill.DataBind();
                lblbilldate.Text = dt.Rows[0]["insdate"].ToString();
                lbldate.Text = dt.Rows[0]["insdate"].ToString();
                lblptotal.Text = dt.Rows[0]["subtotal"].ToString();
                lblsuttotal.Text = dt.Rows[0]["subtotal"].ToString();
                lbldiscount.Text = dt.Rows[0]["Discount"].ToString();
                lbldisamount.Text = dt.Rows[0]["Discount"].ToString();
                Label17.Text = dt.Rows[0]["tax"].ToString();
                txtgst.Text = dt.Rows[0]["tax"].ToString();
                Label18.Text = dt.Rows[0]["grandtotal"].ToString();
                lblgtotal.Text = dt.Rows[0]["grandtotal"].ToString();
                string billno = dt.Rows[0]["bill_no"].ToString();
                bindkot(billno);
                lblid.Text = lgdcookie["UserName"].ToString();
                lbldatee.Text = dateTime.ToString("dd/MM/yyyy");
                lbltime.Text = dateTime.ToString("hh:mm tt");
                decimal grandTotal = Convert.ToDecimal(dt.Rows[0]["grandtotal"]);
                lblinword.Text = NumberToWords(grandTotal);
            }
        }
        catch (Exception ex)
        {

        }
    }
    // Helper function to convert numbers to words
    public string NumberToWords(decimal number)
    {
        long intPart = (long)Math.Floor(number);
        int fraction = (int)((number - intPart) * 100); // For 2 decimal places

        string words = NumberToWords(intPart);

        if (fraction > 0)
        {
            words += " and " + NumberToWords(fraction) + " Paise";
        }

        return words + " Only";
    }

    // Recursive function for integer part
    private string NumberToWords(long number)
    {
        if (number == 0)
            return "Zero";

        if (number < 0)
            return "Minus " + NumberToWords(Math.Abs(number));

        string words = "";

        if ((number / 10000000) > 0)
        {
            words += NumberToWords(number / 10000000) + " Crore ";
            number %= 10000000;
        }

        if ((number / 100000) > 0)
        {
            words += NumberToWords(number / 100000) + " Lakh ";
            number %= 100000;
        }

        if ((number / 1000) > 0)
        {
            words += NumberToWords(number / 1000) + " Thousand ";
            number %= 1000;
        }

        if ((number / 100) > 0)
        {
            words += NumberToWords(number / 100) + " Hundred ";
            number %= 100;
        }

        if (number > 0)
        {
            string[] units = { "", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten",
                           "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen", "Seventeen", "Eighteen", "Nineteen" };
            string[] tens = { "", "", "Twenty", "Thirty", "Forty", "Fifty", "Sixty", "Seventy", "Eighty", "Ninety" };

            if (number < 20)
                words += units[number];
            else
            {
                words += tens[number / 10];
                if ((number % 10) > 0)
                    words += " " + units[number % 10];
            }
        }

        return words.Trim();
    }

    public void bindkot(string blno)
    {
        try
        {
            List<string> kotList = new List<string>();
            string query = "SELECT kot_no FROM kot_Master WHERE billno=@billno ORDER BY kot_no";
            SqlCommand cmd = new SqlCommand(query, cl.con);
            cmd.Parameters.AddWithValue("@billno", blno);

            cl.con.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                kotList.Add(dr["kot_no"].ToString());
            }
            lblkotnoo.Text = string.Join(", ", kotList);
        }
        catch (Exception ex)
        {

        }
    }
    protected void gridbill_RowDataBound(object sender, GridViewRowEventArgs e)
    {

        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            Label lblDisc = (Label)e.Row.FindControl("lbldisc");

            if (lblDisc != null && (lblDisc.Text == "0" || lblDisc.Text == "0.00"))
            {
                lblDisc.Visible = false;
            }
        }
    }

}

