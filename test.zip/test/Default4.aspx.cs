﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Default4 : System.Web.UI.Page
{
    Class1 cl = new Class1();

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            //if (Session["Admin"] == null || Session["Admin"] == "")
            //{
            //    Response.Redirect("login.aspx");
            //}
            var masterFooter = this.Master.FindControl("masterFooter");
            if (masterFooter != null)
            {
                masterFooter.Visible = false;
            }   
            BindGroupData();
        }
    }
    private void BindGroupData()
    {
        SqlCommand cmd = new SqlCommand("SELECT id.id as item_id, ig.Item_G_Name AS group_name, id.item_name, id.item_sale_rate, ('../' + id.Productimage) AS Productimage FROM Item_detail id INNER JOIN item_group_master ig ON id.item_group_name = ig.Item_G_Name ORDER BY ig.Item_G_Name, id.item_name", cl.con);
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataTable dt = new DataTable();
        da.Fill(dt);
        if (dt.Rows.Count > 0)
        {
            var groups = dt.AsEnumerable()
                           .GroupBy(r => r.Field<string>("group_name"))
                           .Select(g => new
                           {
                               GroupName = g.Key,
                               Items = g.CopyToDataTable(),
                               ItemCount = g.Count()
                           }).ToList();
            rptGroup.DataSource = groups;
            rptGroup.DataBind();
            rptGroupMenu.DataSource = groups.Select(x => new
            {
                GroupName = x.GroupName,
                ItemCount = x.ItemCount
            });
            rptGroupMenu.DataBind();
        }
    }
    protected void rptGroup_ItemDataBound(object sender, RepeaterItemEventArgs e)
    {
        if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
        {
            dynamic group = e.Item.DataItem;
            Repeater rptItems = (Repeater)e.Item.FindControl("rptItems");
            rptItems.DataSource = group.Items;
            rptItems.DataBind();
        }
    }
    protected void btnNext_Click(object sender, EventArgs e)
    {
        string json = hfItems.Value;
        string tableNo = Request.QueryString["tblno"];

        if (string.IsNullOrEmpty(json))
        {
            ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert('No item selected!');", true);
            return;
        }

        JavaScriptSerializer js = new JavaScriptSerializer();
        List<Itemdata> items = js.Deserialize<List<Itemdata>>(json);

        if (items == null || items.Count == 0)
        {
            ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert('No valid item data found!');", true);
            return;
        }

        int kotId = 0;

        if (cl.con.State == ConnectionState.Closed)
            cl.con.Open();
        SqlCommand cmdKot = new SqlCommand("SELECT ISNULL(MAX(kot_id),0) + 1 FROM RestaurantItems", cl.con);
        kotId = Convert.ToInt32(cmdKot.ExecuteScalar());

        foreach (var item in items)
        {
            decimal qty = Convert.ToDecimal(item.qty);
            decimal rate = Convert.ToDecimal(item.item_rate);
            decimal amount = qty * rate;

            SqlCommand cmdItem = new SqlCommand("INSERT INTO RestaurantItems (kot_id, Table_No, itemcode, itemname, qty, rate, Amount) VALUES (@kot_id, @Table_No, @itemcode, @itemname, @qty, @rate, @Amount)", cl.con);

            cmdItem.Parameters.AddWithValue("@kot_id", kotId);
            cmdItem.Parameters.AddWithValue("@Table_No", tableNo);
            cmdItem.Parameters.AddWithValue("@itemcode", item.item_id);
            cmdItem.Parameters.AddWithValue("@itemname", item.item_name);
            cmdItem.Parameters.AddWithValue("@qty", item.qty);
            cmdItem.Parameters.AddWithValue("@rate", item.item_rate);
            cmdItem.Parameters.AddWithValue("@Amount", amount);

            cmdItem.ExecuteNonQuery();
        }

        cl.con.Close();

        Session["SelectedItems_" + tableNo] = items;
        Session["KOT_ID_" + tableNo] = kotId;

        Response.Redirect("OrderSummary.aspx?tblno=" + tableNo);
    }
    private void BindSelectedItems(List<Itemdata> items)
    {
        itemCount.InnerText = items.Count.ToString();
    }
    [WebMethod]
    public static string SaveItems(List<Itemdata> items)
    {
        HttpContext.Current.Session["SelectedItems"] = items;
        return "OK";
    }
    protected void txtSearch_TextChanged(object sender, EventArgs e)
    {
        string search = txtSearch.Text.Trim().ToLower();
        SqlCommand cmd = new SqlCommand("SELECT id.id as item_id, ig.Item_G_Name AS group_name, id.item_name, id.item_sale_rate, ('../' + id.Productimage) AS Productimage FROM Item_detail id INNER JOIN item_group_master ig ON id.item_group_name = ig.Item_G_Name WHERE id.item_name LIKE @search + '%' ORDER BY ig.Item_G_Name, id.item_name", cl.con);

        cmd.Parameters.AddWithValue("@search", search);
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataTable dt = new DataTable();
        da.Fill(dt);

        if (dt.Rows.Count > 0)
        {
            var groups = dt.AsEnumerable()
                           .GroupBy(r => r.Field<string>("group_name"))
                           .Select(g => new
                           {
                               GroupName = g.Key,
                               Items = g.CopyToDataTable(),
                               ItemCount = g.Count()
                           }).ToList();
            rptGroup.DataSource = groups;
            rptGroup.DataBind();

            rptGroupMenu.DataSource = groups.Select(x => new
            {
                GroupName = x.GroupName,
                ItemCount = x.ItemCount
            });
            rptGroupMenu.DataBind();
        }
        else
        {
            rptGroup.DataSource = null;
            rptGroup.DataBind();
            rptGroupMenu.DataSource = null;
            rptGroupMenu.DataBind();
        }
    }
}