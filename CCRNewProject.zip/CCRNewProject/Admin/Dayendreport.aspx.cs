﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Admin_Dayendreport : System.Web.UI.Page
{
    Class1 cl = new Class1();
    public static TimeZoneInfo timeZoneInfo = TimeZoneInfo.FindSystemTimeZoneById("India Standard Time");
    public static DateTime dateTime;
    protected void Page_Load(object sender, EventArgs e)
    {
        dateTime = TimeZoneInfo.ConvertTime(DateTime.Now, timeZoneInfo);
        if (!IsPostBack)
        {
            txtfrom.Text = dateTime.ToString("yyyy-MM-dd");
            txtto.Text = dateTime.ToString("yyyy-MM-dd");
        }
    }
    protected void btnback_Click(object sender, EventArgs e)
    {
        Response.Redirect("Dayendreport.aspx");
    }
    protected void btnpreview_Click(object sender, EventArgs e)
    {
        try
        {
            if (string.IsNullOrWhiteSpace(txtfrom.Text) || string.IsNullOrWhiteSpace(txtto.Text))
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "Script",
                    "savealert('Please select both From and To date.!!','warning');", true);
                return;
            }

            DateTime fromDate = DateTime.Parse(txtfrom.Text);
            DateTime toDate = DateTime.Parse(txtto.Text);
            from.Text = fromDate.ToString("dd-MM-yyyy");
            lbto.Text = toDate.ToString("dd-MM-yyyy");
            string baseQuery = @"";

            SqlCommand cmd = new SqlCommand(baseQuery, cl.con);
            cmd.Parameters.AddWithValue("@fromdate", Convert.ToDateTime(fromDate));
            cmd.Parameters.AddWithValue("@todate", Convert.ToDateTime(toDate));
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            sda.Fill(dt);

            if (dt.Rows.Count > 0)
            {
                rptStock.DataSource = dt;
                rptStock.DataBind();
            }
            else
            {
                rptStock.DataSource = null;
                rptStock.DataBind();
                ScriptManager.RegisterStartupScript(this, this.GetType(), "Script", "savealert('No data found !!','warning');", true);
            }
        }
        catch (Exception ex)
        {
            Response.Write("Error: " + ex.Message);
        }
    }
    protected void btnExportExcel_Click(object sender, EventArgs e)
    {
        DateTime fromDate = DateTime.Parse(txtfrom.Text);
        DateTime toDate = DateTime.Parse(txtto.Text);

        DataTable dt = new DataTable();

        string query = @"WITH BillLevel AS
(
    SELECT
        bm.Bill_ID,
        bm.bill_date,
        bm.bill_no,
        bm.status,
        bm.order_type,
        bm.grandtotal,
        bm.discount,
        bm.tax,
        bm.roundoff,
        bm.subtotal,
        bm.DeliveryCharge,
        bm.container_charge,
        bm.additional_charge,
        bm.deduction_charge,
        bm.Insuser,
        bm.BillTime
    FROM bill_master bm
    WHERE ispaid = 1 and  bm.bill_date >= @fromdate
      AND bm.bill_date < DATEADD(DAY,1,@todate)   -- 🔥 FIX
)
SELECT
/* ================= SUCCESS ================= */
ISNULL(SUM(CASE WHEN status='SUCCESS' AND order_type='Delivery' THEN 1 ELSE 0 END),0) AS S_DeliveryCount,
ISNULL(SUM(CASE WHEN status='SUCCESS' AND order_type='Delivery' THEN grandtotal ELSE 0 END),0) AS S_DeliveryTotal,
ISNULL(SUM(CASE WHEN status='SUCCESS' AND order_type='Dine In' THEN 1 ELSE 0 END),0) AS S_DineInCount,
ISNULL(SUM(CASE WHEN status='SUCCESS' AND order_type='Dine In' THEN grandtotal ELSE 0 END),0) AS S_DineInTotal,
ISNULL(SUM(CASE WHEN status='SUCCESS' AND order_type='Pick Up' THEN 1 ELSE 0 END),0) AS S_PickUpCount,
ISNULL(SUM(CASE WHEN status='SUCCESS' AND order_type='Pick Up' THEN grandtotal ELSE 0 END),0) AS S_PickUpTotal,
ISNULL(SUM(CASE WHEN status='SUCCESS' AND order_type='Online' THEN 1 ELSE 0 END),0) AS S_OnlineCount,
ISNULL(SUM(CASE WHEN status='SUCCESS' AND order_type='Online' THEN grandtotal ELSE 0 END),0) AS S_OnlineTotal,
/* ================= CANCELLED ================= */
ISNULL(SUM(CASE WHEN status='CANCELLED' AND order_type='Delivery' THEN 1 ELSE 0 END),0) AS C_DeliveryCount,
ISNULL(SUM(CASE WHEN status='CANCELLED' AND order_type='Delivery' THEN grandtotal ELSE 0 END),0) AS C_DeliveryTotal,
ISNULL(SUM(CASE WHEN status='CANCELLED' AND order_type='Dine In' THEN 1 ELSE 0 END),0) AS C_DineInCount,
ISNULL(SUM(CASE WHEN status='CANCELLED' AND order_type='Dine In' THEN grandtotal ELSE 0 END),0) AS C_DineInTotal,
ISNULL(SUM(CASE WHEN status='CANCELLED' AND order_type='Pick Up' THEN 1 ELSE 0 END),0) AS C_PickUpCount,
ISNULL(SUM(CASE WHEN status='CANCELLED' AND order_type='Pick Up' THEN grandtotal ELSE 0 END),0) AS C_PickUpTotal,
ISNULL(SUM(CASE WHEN status='CANCELLED' AND order_type='Online' THEN 1 ELSE 0 END),0) AS C_OnlineCount,
ISNULL(SUM(CASE WHEN status='CANCELLED' AND order_type='Online' THEN grandtotal ELSE 0 END),0) AS C_OnlineTotal,
/* ================= COMPLIMENTARY ================= */
ISNULL(SUM(CASE WHEN status='COMPLIMENTARY' AND order_type='Delivery' THEN 1 ELSE 0 END),0) AS CP_DeliveryCount,
ISNULL(SUM(CASE WHEN status='COMPLIMENTARY' AND order_type='Delivery' THEN grandtotal ELSE 0 END),0) AS CP_DeliveryTotal,
ISNULL(SUM(CASE WHEN status='COMPLIMENTARY' AND order_type='Dine In' THEN 1 ELSE 0 END),0) AS CP_DineInCount,
ISNULL(SUM(CASE WHEN status='COMPLIMENTARY' AND order_type='Dine In' THEN grandtotal ELSE 0 END),0) AS CP_DineInTotal,
ISNULL(SUM(CASE WHEN status='COMPLIMENTARY' AND order_type='Pick Up' THEN 1 ELSE 0 END),0) AS CP_PickUpCount,
ISNULL(SUM(CASE WHEN status='COMPLIMENTARY' AND order_type='Pick Up' THEN grandtotal ELSE 0 END),0) AS CP_PickUpTotal,
ISNULL(SUM(CASE WHEN status='COMPLIMENTARY' AND order_type='Online' THEN 1 ELSE 0 END),0) AS CP_OnlineCount,
ISNULL(SUM(CASE WHEN status='COMPLIMENTARY' AND order_type='Online' THEN grandtotal ELSE 0 END),0) AS CP_OnlineTotal,

/* ================= SALES RETURN ================= */
ISNULL(SUM(CASE WHEN status='SALES_RETURN' AND order_type='Pick Up' THEN grandtotal ELSE 0 END),0) AS R_PickUpTotal,
ISNULL(SUM(CASE WHEN status='SALES_RETURN' AND order_type='Online' THEN 1 ELSE 0 END),0) AS R_OnlineCount,
ISNULL(SUM(CASE WHEN status='SALES_RETURN' AND order_type='Delivery' THEN 1 ELSE 0 END),0) AS R_DeliveryCount,
ISNULL(SUM(CASE WHEN status='SALES_RETURN' AND order_type='Delivery' THEN grandtotal ELSE 0 END),0) AS R_DeliveryTotal,
ISNULL(SUM(CASE WHEN status='SALES_RETURN' AND order_type='Dine In' THEN 1 ELSE 0 END),0) AS R_DineInCount,
ISNULL(SUM(CASE WHEN status='SALES_RETURN' AND order_type='Dine In' THEN grandtotal ELSE 0 END),0) AS R_DineInTotal,
ISNULL(SUM(CASE WHEN status='SALES_RETURN' AND order_type='Pick Up' THEN 1 ELSE 0 END),0) AS R_PickUpCount,
ISNULL(SUM(CASE WHEN status='SALES_RETURN' AND order_type='Online' THEN grandtotal ELSE 0 END),0) AS R_OnlineTotal,

/* ================= TOTALS ================= */
SUM(grandtotal) AS TotalSales,
SUM(discount) AS Discount,
SUM(tax) AS Tax,
SUM(roundoff) AS RoundOff,
SUM(subtotal) AS SubTotal,
SUM(DeliveryCharge) AS DeliveryCharge,
ISNULL(SUM(container_charge),0) AS ContainerCharge,
ISNULL(SUM(additional_charge),0) AS AdditionalCharge,
ISNULL(SUM(deduction_charge),0) AS DeductionCharge,

/* ================= DATE / BILL RANGE ================= */
MIN(bill_date) AS StartDateTime,
MAX(bill_date) AS EndDateTime,
MIN(bill_no) AS BillFrom,
MAX(bill_no) AS BillTo,

MAX(Insuser) AS Insuser,
max(BillTime) as BillTime,
/* ================= FOOD / BAR (SEPARATE SUBQUERY) ================= */
(
    SELECT  CAST(
            ISNULL(
                SUM(
                    bd.Amount + (bd.Amount * id.gst_per / 100.0)
                ), 
            0)
        AS DECIMAL(18,2))
    FROM Bill_Detail bd
    JOIN item_detail id ON bd.itemname = id.item_name
    JOIN item_group_master ig ON id.item_group_name = ig.item_g_id
    WHERE ig.pgroupname='FOOD'
      AND bd.Bill_ID IN (SELECT Bill_ID FROM BillLevel)
) AS FoodTotal,

(
    SELECT ISNULL(SUM(bd.Amount),0)
    FROM Bill_Detail bd
    JOIN item_detail id ON bd.itemname = id.item_name
    JOIN item_group_master ig ON id.item_group_name = ig.item_g_id
    WHERE ig.pgroupname='BAR'
      AND bd.Bill_ID IN (SELECT Bill_ID FROM BillLevel)
) AS BarTotal

FROM BillLevel;";


        SqlCommand cmd = new SqlCommand(query, cl.con);
        cmd.Parameters.AddWithValue("@fromdate", fromDate);
        cmd.Parameters.AddWithValue("@todate", toDate);

        SqlDataAdapter da = new SqlDataAdapter(cmd);
        da.Fill(dt);
        DataRow r = dt.Rows[0];

        /* SUCCESS */
        int sDelC = Convert.ToInt32(r["S_DeliveryCount"]);
        decimal sDelT = Convert.ToDecimal(r["S_DeliveryTotal"]);

        int sDinC = Convert.ToInt32(r["S_DineInCount"]);
        decimal sDinT = Convert.ToDecimal(r["S_DineInTotal"]);

        int sPickC = Convert.ToInt32(r["S_PickUpCount"]);
        decimal sPickT = Convert.ToDecimal(r["S_PickUpTotal"]);

        int sOnC = Convert.ToInt32(r["S_OnlineCount"]);
        decimal sOnT = Convert.ToDecimal(r["S_OnlineTotal"]);
        int stotalcount = sDelC + sDinC + sPickC + sOnC;
        /* CANCELLED */
        int cDelC = Convert.ToInt32(r["C_DeliveryCount"]);
        decimal cDelT = Convert.ToDecimal(r["C_DeliveryTotal"]);

        int cDinC = Convert.ToInt32(r["C_DineInCount"]);
        decimal cDinT = Convert.ToDecimal(r["C_DineInTotal"]);

        int cPickC = Convert.ToInt32(r["C_PickUpCount"]);
        decimal cPickT = Convert.ToDecimal(r["C_PickUpTotal"]);

        int cOnC = Convert.ToInt32(r["C_OnlineCount"]);
        decimal cOnT = Convert.ToDecimal(r["C_OnlineTotal"]);
        int ctotalcount = cDelC + cDinC + cPickC + cOnC;
        /* COMPLIMENTARY */
        int cpDelC = Convert.ToInt32(r["CP_DeliveryCount"]);
        decimal cpDelT = Convert.ToDecimal(r["CP_DeliveryTotal"]);

        int cpDinC = Convert.ToInt32(r["CP_DineInCount"]);
        decimal cpDinT = Convert.ToDecimal(r["CP_DineInTotal"]);

        int cpPickC = Convert.ToInt32(r["CP_PickUpCount"]);
        decimal cpPickT = Convert.ToDecimal(r["CP_PickUpTotal"]);

        int cpOnC = Convert.ToInt32(r["CP_OnlineCount"]);
        decimal cpOnT = Convert.ToDecimal(r["CP_OnlineTotal"]);
        int cototalcount = cpDelC + cpDinC + cpPickC + cpOnC;
        /* SALES RETURN */
        int rDelC = Convert.ToInt32(r["R_DeliveryCount"]);
        decimal rDelT = Convert.ToDecimal(r["R_DeliveryTotal"]);

        int rDinC = Convert.ToInt32(r["R_DineInCount"]);
        decimal rDinT = Convert.ToDecimal(r["R_DineInTotal"]);

        int rPickC = Convert.ToInt32(r["R_PickUpCount"]);
        decimal rPickT = Convert.ToDecimal(r["R_PickUpTotal"]);

        int rOnC = Convert.ToInt32(r["R_OnlineCount"]);
        decimal rOnT = Convert.ToDecimal(r["R_OnlineTotal"]);

        int satotalcount = rDelC + rDinC + rPickC + rOnC;

        decimal subtotal = r["subtotal"] == DBNull.Value ? 0 : Convert.ToDecimal(r["subtotal"]);
        decimal totalSales = r["TotalSales"] == DBNull.Value ? 0 : Convert.ToDecimal(r["TotalSales"]);
        decimal discount = r["Discount"] == DBNull.Value ? 0 : Convert.ToDecimal(r["Discount"]);
        decimal tax = r["Tax"] == DBNull.Value ? 0 : Convert.ToDecimal(r["Tax"]);
        decimal roundoff = r["RoundOff"] == DBNull.Value ? 0 : Convert.ToDecimal(r["RoundOff"]);
        decimal DeliveryCharge = r["DeliveryCharge"] == DBNull.Value ? 0 : Convert.ToDecimal(r["DeliveryCharge"]);
        decimal container_charge = r["ContainerCharge"] == DBNull.Value ? 0 : Convert.ToDecimal(r["ContainerCharge"]);
        decimal additional_charge = r["AdditionalCharge"] == DBNull.Value ? 0 : Convert.ToDecimal(r["AdditionalCharge"]);
        decimal deduction_charge = r["DeductionCharge"] == DBNull.Value ? 0 : Convert.ToDecimal(r["DeductionCharge"]);
        decimal FoodTotal = r["FoodTotal"] == DBNull.Value ? 0 : Convert.ToDecimal(r["FoodTotal"]);
        decimal BarTotal = r["BarTotal"] == DBNull.Value ? 0 : Convert.ToDecimal(r["BarTotal"]);
        string Insuser = r["Insuser"].ToString();
        DateTime startDateTime = r.Field<DateTime?>("StartDateTime") ?? DateTime.MinValue;
        DateTime endDateTime = r.Field<DateTime?>("EndDateTime") ?? DateTime.MinValue;
        DateTime BillTime;
        BillTime = r["BillTime"] == DBNull.Value
            ? DateTime.MinValue
            : Convert.ToDateTime(r["BillTime"]);


        //DateTime BillTime = Convert.ToDateTime(r["BillTime"]);

        string billFrom = r["BillFrom"].ToString();
        string billTo = r["BillTo"].ToString();


        Response.Clear();
        Response.Buffer = true;
        Response.AddHeader("content-disposition",
            "attachment;filename=DayEndReport_" + DateTime.Now.ToString("ddMMyyyy") + ".xls");
        Response.ContentType = "application/vnd.ms-excel";

        System.IO.StringWriter sw = new System.IO.StringWriter();

        sw.Write("<table border='1' style='font-family:Calibri;font-size:14px;width:100%'>");

        /* HEADER */
        sw.Write("<tr><td colspan='3' style='font-size:20px;font-weight:bold;text-align:center'>Charans Club & Resort Pvt Ltd</td></tr>");
        sw.Write("<tr><td colspan='3' style='text-align:center;font-weight:bold'>Day End Report</td></tr>");
        sw.Write("<tr><td colspan='3'><b>Period :</b> " + fromDate.ToString("dd-MM-yyyy") +
                 " to " + toDate.ToString("dd-MM-yyyy") + "</td></tr>");
        sw.Write("<tr><td colspan='3'></td></tr>");

        /* SUCCESS ORDERS */
        sw.Write("<tr><td colspan='3' style='font-weight:bold'>Success Orders</td></tr>");
        sw.Write("<tr><th>Type</th><th>Count</th><th colspan='1'>Total</th></tr>");
        sw.Write("<tr><td>Delivery</td><td>" + sDelC + "</td><td>" + sDelT + "</td></tr>");
        sw.Write("<tr><td>Dine In</td><td>" + sDinC + "</td><td>" + sDinT + "</td></tr>");
        sw.Write("<tr><td>Pick Up</td><td>" + sPickC + "</td><td>" + sPickT + "</td></tr>");
        sw.Write("<tr><td>Online</td><td>" + sOnC + "</td><td>" + sOnT + "</td></tr>");
        sw.Write("<tr><td><b>Total</b></td><td><b>" + stotalcount +
                 "</b></td><td colspan='1'><b>" + totalSales + "</b></td></tr>");
        /* Cancelled ORDERS */
        sw.Write("<tr><td colspan='3'></td></tr>");
        sw.Write("<tr><td colspan='3' style='font-weight:bold'>Cancelled Orders</td></tr>");
        sw.Write("<tr><th>Type</th><th>Count</th><th colspan='1'>Total</th></tr>");
        sw.Write("<tr><td>Delivery</td><td>" + cDelC + "</td><td>" + cDelT + "</td></tr>");
        sw.Write("<tr><td>Dine In</td><td>" + cDinC + "</td><td>" + cDinT + "</td></tr>");
        sw.Write("<tr><td>Pick Up</td><td>" + cPickC + "</td><td>" + cPickT + "</td></tr>");
        sw.Write("<tr><td>Online</td><td>" + cOnC + "</td><td>" + cOnT + "</td></tr>");
        sw.Write("<tr><td><b>Total</b></td><td><b>" + ctotalcount +
                 "</b></td><td colspan='1'><b>" + ctotalcount + "</b></td></tr>");
        /* Complimentary ORDERS */
        sw.Write("<tr><td colspan='3'></td></tr>");
        sw.Write("<tr><td colspan='3' style='font-weight:bold'>Complimentary Orders</td></tr>");
        sw.Write("<tr><th>Type</th><th>Count</th><th colspan='1'>Total</th></tr>");
        sw.Write("<tr><td>Delivery</td><td>" + cpDelC + "</td><td>" + cpDelT + "</td></tr>");
        sw.Write("<tr><td>Dine In</td><td>" + cpDinC + "</td><td>" + cpDinT + "</td></tr>");
        sw.Write("<tr><td>Pick Up</td><td>" + cpPickC + "</td><td>" + cpPickT + "</td></tr>");
        sw.Write("<tr><td><b>Total</b></td><td><b>" + cototalcount +
                 "</b></td><td colspan='1'><b>" + cototalcount + "</b></td></tr>");
        /* sale ORDERS */
        sw.Write("<tr><td colspan='3'></td></tr>");
        sw.Write("<tr><td colspan='3' style='font-weight:bold'>Sales Return Orders</td></tr>");
        sw.Write("<tr><th>Type</th><th>Count</th><th colspan='1'>Total</th></tr>");
        sw.Write("<tr><td>Delivery</td><td>" + rDelC + "</td><td>" + rDelT + "</td></tr>");
        sw.Write("<tr><td>Dine In</td><td>" + rDinC + "</td><td>" + rDinT + "</td></tr>");
        sw.Write("<tr><td>Pick Up</td><td>" + rPickC + "</td><td>" + rPickT + "</td></tr>");
        sw.Write("<tr><td><b>Total</b></td><td><b>" + satotalcount +
                 "</b></td><td colspan='1'><b>" + satotalcount + "</b></td></tr>");

        /* PAYMENT INFO */
        sw.Write("<tr><td colspan='3'></td></tr>");
        sw.Write("<tr><td colspan='3' style='font-weight:bold'>Advance Order (Due Payment Received)</td></tr>");
        sw.Write("<tr><td colspan='3'></td></tr>");
        sw.Write("<tr><td colspan='3' style='font-weight:bold'>Order Payment Details</td></tr>");
        sw.Write("<tr><th>Payment Type</th><th colspan='2'>Total</th></tr>");
        sw.Write("<tr><td>Cash</td><td colspan='2'>" + totalSales + "</td></tr>");
        sw.Write("<tr><td><b>Total</b></td><td colspan='2'><b>" + totalSales + "</b></td></tr>");
        /* PAYMENT INFO */
        sw.Write("<tr><td colspan='3'></td></tr>");
        sw.Write("<tr><td colspan='3' style='font-weight:bold'>Payment Information</td></tr>");
        sw.Write("<tr><td>Sub Total</td><td colspan='2'>" + subtotal + "</td></tr>");
        sw.Write("<tr><td>Discount</td><td colspan='2'>" + discount + "</td></tr>");
        sw.Write("<tr><td>Tax</td><td colspan='2'>" + tax + "</td></tr>");
        sw.Write("<tr><td>Delivery Charge</td><td colspan='2'>" + DeliveryCharge + "</td></tr>");
        sw.Write("<tr><td>Container Charge</td><td colspan='2'>" + container_charge + "</td></tr>");
        sw.Write("<tr><td>Additional Charge</td><td colspan='2'>" + additional_charge + "</td></tr>");
        sw.Write("<tr><td>Deduction Charge</td><td colspan='2'>" + deduction_charge + "</td></tr>");
        sw.Write("<tr><td>TEMP. MMSHIP CHARGEINCL 18% GST</td><td colspan='2'>" + 0 + "</td></tr>");
        sw.Write("<tr><td>Round Off</td><td colspan='2'>" + roundoff + "</td></tr>");
        sw.Write("<tr><td>Waived Off</td><td colspan='2'>" + 0 + "</td></tr>");
        sw.Write("<tr><td><b>Grand Total</b></td><td colspan='2'><b>" + totalSales + "</b></td></tr>");
        /*group summary */
        sw.Write("<tr><td colspan='3'></td></tr>");
        sw.Write("<tr><td colspan='3' style='font-weight:bold'>Group Summary</td></tr>");
        sw.Write("<tr><td>Restaurant Fooding</td><td colspan='2'>" + FoodTotal + "</td></tr>");
        sw.Write("<tr><td>Bar</td><td colspan='2'>" + BarTotal + "</td></tr>");
        sw.Write("<tr><td>Club Membership</td><td colspan='2'>" + 0 + "</td></tr>");
        sw.Write("<tr><td>SWIMMING POOL </td><td colspan='2'>" + 0 + "</td></tr>");
        sw.Write("<tr><td>COMPL</td><td colspan='2'>" + 0 + "</td></tr>");
        sw.Write("<tr><td>Round Off</td><td colspan='2'>" + roundoff + "</td></tr>");
        sw.Write("<tr><td>TEMP. MMSHIP CHARGEINCL 18% GST</td><td colspan='2'>" + 0 + "</td></tr>");
        sw.Write("<tr><td><b>Total</b></td><td colspan='2'><b>" + totalSales + "</b></td></tr>");

        /* DAY END */
        sw.Write("<tr><td colspan='3'></td></tr>");
        sw.Write("<tr><td colspan='3' style='font-weight:bold'>Day Start Details</td></tr>");
        sw.Write("<tr><td>User Name</td><td colspan='2'>" + Insuser + "</td></tr>");
        sw.Write("<tr><td>Start Date</td><td colspan='2'>" + startDateTime + "</td></tr>");
        sw.Write("<tr><td>Previous Closing Balance in Drawer</td><td colspan='2'>" + 0 + "</td></tr>");
        sw.Write("<tr><td>Current Cash Balance in Drawer</td><td colspan='2'>" + 0 + "</td></tr>");

        /* DAY END */
        sw.Write("<tr><td colspan='3'></td></tr>");
        sw.Write("<tr><td colspan='3' style='font-weight:bold'>Day End Details</td></tr>");
        sw.Write("<tr><td>User Name</td><td colspan='2'>" + Insuser + "</td></tr>");
        sw.Write("<tr><td>End Date</td><td colspan='2'>" + endDateTime.ToString("dd/MM/yyyy") + " " + BillTime.ToString("hh:mm tt") + "</td></tr>");

        sw.Write("<tr><td>Invoice Range </td><td colspan='2'>" + billFrom + " - "+ billTo + "</td></tr>");
        sw.Write("<tr><td>Previous Day Balance</td><td colspan='2'>" + 0 + "</td></tr>");
        sw.Write("<tr><td>Total Cash</td><td colspan='2'>" + totalSales + "</td></tr>");
        sw.Write("<tr><td>Total Other Cash</td><td colspan='2'>" + 0 + "</td></tr>");
        sw.Write("<tr><td>Total Cash Top-Up</td><td colspan='2'>" + 0 + "</td></tr>");
        sw.Write("<tr><td>Total Cash Expense</td><td colspan='2'>" + 0 + "</td></tr>");
        sw.Write("<tr><td>Total Withdrawal</td><td colspan='2'>" + 0 + "</td></tr>");
        sw.Write("<tr><td>Total Cash Sales Return</td><td colspan='2'>" + 0 + "</td></tr>");
        sw.Write("<tr><td>Expected Remaining Total</td><td colspan='2'>" + totalSales + "</td></tr>");
        sw.Write("<tr><td><b>Final Total</b></td><td colspan='2'><b>" + totalSales + "</b></td></tr>");
        sw.Write("<tr><td><b>Final Card Total</b></td><td colspan='2'><b>" + 0 + "</b></td></tr>");

        sw.Write("</table>");

        Response.Write(sw.ToString());
        Response.End();
    }

    public override void VerifyRenderingInServerForm(Control control)
    {

    }
}