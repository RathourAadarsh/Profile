﻿using Org.BouncyCastle.Utilities.Collections;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class OrderSummary : System.Web.UI.Page
{
    Class1 cl = new Class1();
    Cls_connection cls = new Cls_connection();
    public static TimeZoneInfo timeZoneInfo = TimeZoneInfo.FindSystemTimeZoneById("India Standard Time");
    public static DateTime dateTime;
    protected void Page_Load(object sender, EventArgs e)
    {
        dateTime = TimeZoneInfo.ConvertTime(DateTime.Now, timeZoneInfo);
        if (!IsPostBack)
        {
            if (Session["Admin"] == null || Session["Admin"] == "")
            {
                Response.Redirect("login.aspx");
            }
            var masterFooter = this.Master.FindControl("masterFooter");
            if (masterFooter != null)
            {
                masterFooter.Visible = false;
            }

            lbltableno.Text = Request.QueryString["tblno"] ?? "";
            bindwaiter();
            lbldate.Text = dateTime.ToString("dd/MM/yyyy");
            lblkotno.Text = cl.Scalar("Select ISNULL(max(convert(int,kot_no)),0)+1 as kot_no  from restaurant where kot_flag=1 ");
            lblkotbill.Text = cl.Scalar("Select ISNULL(max(convert(int,kot_Bill)),0)+1 as kot_Bill from restaurant");
            lblitembill.Text = cl.Scalar("Select ISNULL(max(convert(int,item_bill)),0)+1 as item_bill from Temp_item_Save");
            CleanZeroQtyItems();
            LoadSelectedItems();
            bindkot();
        }         
    }
    public void bindwaiter()
    {
        string query = "select autoid, waiter_name from waiter_master where deactive = 0";
        SqlDataAdapter sda = new SqlDataAdapter(query, cl.con);
        DataTable dt = new DataTable();
        sda.Fill(dt);
        if (dt.Rows.Count > 0)
        {
            ddlwaiter.DataValueField = "autoid";
            ddlwaiter.DataTextField = "waiter_name";
            ddlwaiter.DataSource = dt;
            ddlwaiter.DataBind();
            ddlwaiter.Items.Insert(0, new ListItem("--Select Waiter--", "-1"));
        }
    }
    public void GenerateBill()
    {         
        int len = 0;
        string id = null;
        string st = null;
        int i = 0;
        cls.con.Open();
        st = cl.Scalar("Select ISNULL(max(convert(int,replace(Bill_no,'CR',''))),0) as Bill_no from Restaurant");
        i = Convert.ToInt32(st);
        id = (i + 1).ToString();
        len = id.Length;
        switch (len)
        {
            case 1:
                id = "00000" + id;
                break;
            case 2:
                id = "0000" + id;
                break;
            case 3:
                id = "000" + id;
                break;
            case 4:
                id = "00" + id;
                break;
            case 5:
                id = "0" + id;
                break;
        }
        string re = "CR";
        lblbillno.Text = re + id;
        cls.con.Close();
    }

    //public void GenerateBill()
    //{
    //    // अगर Bill already generate हो चुका है तो नया मत बनाओ
    //    if (ViewState["BillNo"] != null)
    //    {
    //        lblbillno.Text = ViewState["BillNo"].ToString();
    //        return;
    //    }

    //    cls.con.Open();
    //    string st = cl.Scalar(
    //        "Select ISNULL(max(convert(int,replace(Bill_no,'CR',''))),0) from Restaurant WITH (TABLOCKX)"
    //    );

    //    cls.con.Close();

    //    int i = Convert.ToInt32(st);
    //    string id = (i + 1).ToString().PadLeft(6, '0');

    //    string bill = "CR" + id;

    //    lblbillno.Text = bill;

    //    // Bill को lock कर दो Page के life-cycle में
    //    ViewState["BillNo"] = bill;
    //}

    private void CleanZeroQtyItems()
    {
        string tableNo = Request.QueryString["tblno"];

        if (Session["SelectedItems_" + tableNo] != null)
        {
            List<Itemdata> items = (List<Itemdata>)Session["SelectedItems_" + tableNo];
            items = items.Where(x => Convert.ToInt32(x.qty) > 0).ToList();
            Session["SelectedItems_" + tableNo] = items;
        }
    }

    private void LoadSelectedItems()
    {
        string tableNo = Request.QueryString["tblno"];

        if (Session["SelectedItems_" + tableNo] != null)
        {
            var items = (List<Itemdata>)Session["SelectedItems_" + tableNo];

            rptOrder.DataSource = items;
            rptOrder.DataBind();

            decimal total = items.Sum(i => Convert.ToDecimal(i.item_rate) * Convert.ToInt32(i.qty));
            lblTotal.Text = total.ToString("0.00");
        }
        else
        {
            lblTotal.Text = "0.00";
        }
    }

    [WebMethod]
    public static void UpdateQtyToSession(List<Itemdata> items, string tableNo)
    {
        string key = "SelectedItems_" + tableNo;
        var sessionItems = (List<Itemdata>)HttpContext.Current.Session[key];

        foreach (var it in items)
        {
            var match = sessionItems.FirstOrDefault(x => x.item_id == it.item_id);
            if (match != null)
                match.qty = it.qty;
        }

        sessionItems = sessionItems.Where(x => Convert.ToInt32(x.qty) > 0).ToList();

        HttpContext.Current.Session[key] = sessionItems;
    }


    public class CartUpdate
    {
        public string item_id { get; set; }
        public string qty { get; set; }
    }
    [WebMethod]
    public static void ClearSessionCart(string tableNo)
    {
        HttpContext.Current.Session["SelectedItems_" + tableNo] = null;
    }

    [WebMethod]
    public static void RemoveItem(string itemId, string tableNo)
    {
        string key = "SelectedItems_" + tableNo;

        var sessionItems = (List<Itemdata>)HttpContext.Current.Session[key];

        sessionItems = sessionItems.Where(x => x.item_id != itemId).ToList();

        HttpContext.Current.Session[key] = sessionItems;
    }
    protected void btnBack_Click(object sender, EventArgs e)
    {
        Response.Redirect("Newpage12.aspx?tblno=" + Request.QueryString["tblno"].ToString());
    }

    protected void btnConfirm_Click(object sender, EventArgs e)
    {
        string tableNo = Request.QueryString["tblno"];

        if (Session["SelectedItems_" + tableNo] == null)
        {
            ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert('No items found!');", true);
            return;
        }

        List<Itemdata> items = (List<Itemdata>)Session["SelectedItems_" + tableNo];
        items = items.Where(x => Convert.ToInt32(x.qty) > 0).ToList();

        if (items.Count == 0)
        {
            ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert('No items to save!');", true);
            return;
        }

        SqlConnection con = cl.con;
        con.Open();
        SqlTransaction trans = con.BeginTransaction();

        try
        {
          
            decimal totalAmount = items.Sum(it => Convert.ToDecimal(it.item_rate) * Convert.ToInt32(it.qty));
            SqlCommand cmdMaster = new SqlCommand("INSERT INTO OrderMaster (OrderDate,TotalAmount) OUTPUT INSERTED.OrderID VALUES (@OrderDate, @TotalAmount)",
                con, trans);

            cmdMaster.Parameters.AddWithValue("@OrderDate", DateTime.Now);
            cmdMaster.Parameters.AddWithValue("@TotalAmount", totalAmount);
            int orderID = (int)cmdMaster.ExecuteScalar();

            foreach (var item in items)
            {
                decimal itemAmount = Convert.ToDecimal(item.item_rate) * Convert.ToInt32(item.qty);

                string query = "INSERT INTO Restaurant (Table_no, SKU, Item_name, Rate, Qty, Amount, KOT_no, InsUser, InsDate, InsTime, Waiter_name, kot_flag, kot_bill, Bill_no, Bill_print, room_service, roomno, room_billno, groupitem, mobileno) VALUES (@Table_no, @SKU, @Item_name, @Rate, @Qty, @Amount, @KOT_no, @InsUser, CONVERT(datetime, @InsDate, 103), @InsTime, @Waiter_name, '1', @kot_bill,@billno, '0', @room_service, @roomno, @room_billno, @groupitem, @mobileno)";

                SqlCommand cmd = new SqlCommand(query, con, trans);

                cmd.Parameters.AddWithValue("@Table_no", lbltableno.Text);
                cmd.Parameters.AddWithValue("@SKU", item.item_id);
                cmd.Parameters.AddWithValue("@Item_name", item.item_name);
                cmd.Parameters.AddWithValue("@Rate", item.item_rate);
                cmd.Parameters.AddWithValue("@Qty", item.qty);
                cmd.Parameters.AddWithValue("@Amount", itemAmount);
                cmd.Parameters.AddWithValue("@KOT_no", lblkotno.Text);
                cmd.Parameters.AddWithValue("@Waiter_name", ddlwaiter.SelectedItem.Text);
                cmd.Parameters.AddWithValue("@kot_bill", lblkotbill.Text);
                cmd.Parameters.AddWithValue("@billno", lblbillno.Text);
                cmd.Parameters.AddWithValue("@InsUser", Session["Admin"].ToString());
                cmd.Parameters.AddWithValue("@InsDate", lbldate.Text);
                cmd.Parameters.AddWithValue("@InsTime", DateTime.Now.ToString("hh:mm tt"));
                cmd.Parameters.AddWithValue("@room_service", "0");
                cmd.Parameters.AddWithValue("@roomno", "");
                cmd.Parameters.AddWithValue("@room_billno", "");
                cmd.Parameters.AddWithValue("@groupitem", "");
                cmd.Parameters.AddWithValue("@mobileno", "");

                cmd.ExecuteNonQuery();
                SqlCommand cmdTable = new SqlCommand(
                    "UPDATE Table_master SET Useflag='1' WHERE Table_no=@TableNo",
                    con, trans);

                cmdTable.Parameters.AddWithValue("@TableNo", lbltableno.Text);
                cmdTable.ExecuteNonQuery();
            }

            trans.Commit();
            con.Close();
            if (ViewState["BillNo"] != null)
            {
                lblbillno.Text = ViewState["BillNo"].ToString();
            }

            Session["SelectedItems_" + tableNo] = null;
            string script = "alert('Order Saved Successfully! Order ID: " + orderID + "');" +
                 "window.location='kotbilling1.aspx';";

            ClientScript.RegisterStartupScript(this.GetType(), "alertRedirect", script, true);

        }
        catch (Exception ex)
        {
            trans.Rollback();
            con.Close();

            ClientScript.RegisterStartupScript(this.GetType(),
                "alert", "alert('Error: " + ex.Message.Replace("'", "") + "');", true);
        }
    }
    public void bindkot()
    {
        string query = "SELECT STUFF((SELECT DISTINCT ',' + kot_no FROM Restaurant WHERE Table_no=@TableNo AND Bill_print='0' FOR XML PATH('')), 1, 1, '') AS kot_no,STUFF((SELECT DISTINCT ',' + Bill_no FROM Restaurant WHERE Table_no=@TableNo AND Bill_print='0' FOR XML PATH('')), 1, 1, '') AS bill";

        SqlDataAdapter sda = new SqlDataAdapter(query, cls.con);
        sda.SelectCommand.Parameters.AddWithValue("@TableNo", lbltableno.Text);
        DataTable dt = new DataTable();
        sda.Fill(dt);

        if (dt.Rows.Count > 0)
        {
            string kot = dt.Rows[0]["kot_no"].ToString();
            string Bill_no = dt.Rows[0]["bill"].ToString();
            if (kot != "" && kot != null && kot != " " && Bill_no != "" && Bill_no != null && Bill_no != " ")
            {                 
                lblbillno.Text = dt.Rows[0]["bill"].ToString();
            }
            else
            {
                GenerateBill();
            }
        }
    }

}