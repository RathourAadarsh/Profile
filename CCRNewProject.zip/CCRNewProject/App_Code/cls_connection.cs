﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Linq;
using System.Xml.Linq;

/// <summary>
/// Summary description for cls_connection
/// </summary>
public class cls_connection
{
    public System.Data.SqlClient.SqlConnection con = new System.Data.SqlClient.SqlConnection();
    public System.Data.SqlClient.SqlDataAdapter adp = new System.Data.SqlClient.SqlDataAdapter();
    public System.Data.SqlClient.SqlCommandBuilder cb;
    public System.Data.SqlClient.SqlCommand cmd;
    public string sconnect = System.Configuration.ConfigurationManager.ConnectionStrings["conn"].ToString();
    public cls_connection()
    {    
        cb = new System.Data.SqlClient.SqlCommandBuilder(adp);
        adp.SelectCommand = new System.Data.SqlClient.SqlCommand(" ", con);
        adp.InsertCommand = new System.Data.SqlClient.SqlCommand(" ", con);
        adp.UpdateCommand = new System.Data.SqlClient.SqlCommand(" ", con);

        cmd = new System.Data.SqlClient.SqlCommand("", con);
        cmd.CommandTimeout = 0;
        con.ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["conn"].ToString();
    }

    public void open()
    {
        if (con.State == ConnectionState.Closed)
        {
            con.Open();
        }
    }
    public void close()
    {
        if (con.State == ConnectionState.Open)
        {
            con.Close();
        }
    }
}



