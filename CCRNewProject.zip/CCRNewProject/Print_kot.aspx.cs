﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Print_kot : System.Web.UI.Page
{
    Class1 cl = new Class1();
    public static TimeZoneInfo timeZoneInfo = TimeZoneInfo.FindSystemTimeZoneById("India Standard Time");
    public static DateTime dateTime;
    string lastSubGroup = "";

    protected void Page_Load(object sender, EventArgs e)
    {
        dateTime = TimeZoneInfo.ConvertTime(DateTime.Now, timeZoneInfo);
        if (!IsPostBack)
        {
            if (Request.QueryString["kotno"] != null &&
                Request.QueryString["table_no"] != null)
            {
                lblbillno.Text = Request.QueryString["kotno"];
                lbltable.Text = Request.QueryString["table_no"];
                bindbill(lbltable.Text);
            }
        }

    }
    protected void btncancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("Dashboard.aspx");
    }
    protected void btnPrint_Click(object sender, EventArgs e)
    {
        bill.Visible = true;
        bindbill(lbltable.Text);

        SqlCommand cmd = new SqlCommand("UPDATE KOT_Master SET Isprinted = 1 WHERE Table_No=@TableNo AND IsClosed=0", cl.con);
        cmd.Parameters.AddWithValue("@TableNo", lbltable.Text);
        if (cl.con.State != ConnectionState.Open)
            cl.con.Open();
        cmd.ExecuteNonQuery();
        cl.con.Close();

        ScriptManager.RegisterStartupScript(
            this,
            this.GetType(),
            "Print",
            "window.print();",
            true
        );
    }

    public void bindbill(String table)
    {
        try
        {
            Label6.Text = lblbillno.Text;
            Label10.Text = lbltable.Text;
           string query = @"
SELECT 
    ig.subpgroupname,
    bd.itemname,
    bd.rate,
    bd.qty,
    bd.amount,
    CONVERT(nvarchar,bm.KOT_Date,103) insdate,
    bm.total,
    bm.gstper,
    bm.grandtotal,
    bm.KOT_No
FROM KOT_Master bm
INNER JOIN KOT_Detail bd ON bm.KOT_ID = bd.KOT_ID
INNER JOIN item_detail id ON bd.itemname = id.item_name
INNER JOIN Item_group_Master ig ON id.Item_group_name = ig.item_g_id
where bm.isrunning = 1 and bm.KOT_No='" + lblbillno.Text + "' and bm.table_no='" + table + "' ORDER BY ig.subpgroupname, bd.itemname";

            SqlDataAdapter sda = new SqlDataAdapter(query, cl.con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                gridbill.DataSource = dt;
                gridbill.DataBind();
                lblbilldate.Text = dt.Rows[0]["insdate"].ToString();
                lbldate.Text = dt.Rows[0]["insdate"].ToString();                
                lbltotal.Text = dt.Rows[0]["total"].ToString(); 
                txtgst.Text = dt.Rows[0]["gstper"].ToString();
                lblgtotal.Text = dt.Rows[0]["grandtotal"].ToString();
            }
        }
        catch (Exception ex)
        {

        }
    }

    int totalQty = 0;

    protected void gridbill_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            string currentGroup =
                DataBinder.Eval(e.Row.DataItem, "subpgroupname").ToString();

            // 🔥 GROUP HEADER
            if (lastSubGroup != currentGroup)
            {
                GridView grid = (GridView)sender;

                GridViewRow groupRow = new GridViewRow(
                    -1, -1,
                    DataControlRowType.DataRow,
                    DataControlRowState.Normal
                );

                TableCell cell = new TableCell();
                cell.ColumnSpan = grid.Columns.Count;
                cell.Text = currentGroup.ToUpper();
                cell.BackColor = Color.LightGray;
                cell.Font.Bold = true;
                cell.HorizontalAlign = HorizontalAlign.Left;
                cell.Style.Add("padding", "6px");

                groupRow.Cells.Add(cell);

                grid.Controls[0].Controls.AddAt(
                    grid.Controls[0].Controls.Count - 1,
                    groupRow
                );

                lastSubGroup = currentGroup;
            }

            // 🔢 TOTAL QTY
            totalQty += Convert.ToInt32(DataBinder.Eval(e.Row.DataItem, "qty"));
        }

        // 🔻 FOOTER
        if (e.Row.RowType == DataControlRowType.Footer)
        {
            Label lbl = (Label)e.Row.FindControl("lblTotalQty");
            if (lbl != null)
                lbl.Text = totalQty.ToString();
        }
    }



}