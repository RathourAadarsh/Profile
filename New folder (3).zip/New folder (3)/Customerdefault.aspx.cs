﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Customerdefault : System.Web.UI.Page
{
    Class1 cl = new Class1();
    public static TimeZoneInfo timeZoneInfo = TimeZoneInfo.FindSystemTimeZoneById("India Standard Time");
    public static DateTime dateTime;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
        }
    }
    protected void btnSave_Click(object sender, EventArgs e)
    {
        if (txtName.Text.Trim() == "" || txtMobile.Text.Trim() == "")
        {
            ScriptManager.RegisterStartupScript(this, this.GetType(), "alert",
                "alert('Name and Mobile are required');", true);
            return;
        }

        cl.con.Open();
        SqlCommand checkCmd = new SqlCommand(
            "SELECT COUNT(*) FROM CustomerMaster WHERE Mobile=@Mobile", cl.con);
        checkCmd.Parameters.AddWithValue("@Mobile", txtMobile.Text.Trim());
        int count = Convert.ToInt32(checkCmd.ExecuteScalar());
        if (count > 0)
        {
            cl.con.Close();
            ScriptManager.RegisterStartupScript(this, this.GetType(), "alert",
                "alert('Mobile number already exists');", true);
            return;
        }
        SqlCommand cmd = new SqlCommand("INSERT INTO CustomerMaster(CustomerName, Mobile, Email, Password,AddressLine1, City, Pincode, IsActive,AddressLine2,State) VALUES (@Name, @Mobile, @Email, @Password, @Address, @City, @Pincode, @IsActive,@AddressLine2,@State)", cl.con);

        cmd.Parameters.AddWithValue("@Name", txtName.Text.Trim());
        cmd.Parameters.AddWithValue("@Mobile", txtMobile.Text.Trim());
        cmd.Parameters.AddWithValue("@Email", txtEmail.Text.Trim());
        cmd.Parameters.AddWithValue("@Password", txtPassword.Text.Trim()); 
        cmd.Parameters.AddWithValue("@Address", txtAddress1.Text.Trim());
        cmd.Parameters.AddWithValue("@City", txtCity.Text.Trim());
        cmd.Parameters.AddWithValue("@Pincode", txtPincode.Text.Trim());
        cmd.Parameters.AddWithValue("@IsActive", chkActive.Checked);
        cmd.Parameters.AddWithValue("@AddressLine2", txtAddress2.Text);
        cmd.Parameters.AddWithValue("@State", txtstate.Text);

        cmd.ExecuteNonQuery();
        cl.con.Close();
        ScriptManager.RegisterStartupScript(this, this.GetType(), "alert",
            "alert('Customer Saved Successfully');", true);
        ClearForm();
    }
    private void ClearForm()
    {
        txtName.Text = "";
        txtMobile.Text = "";
        txtEmail.Text = "";
        txtPassword.Text = "";
        txtAddress1.Text = "";
        txtCity.Text = "";
        txtPincode.Text = "";
        txtAddress2.Text = "";
        txtstate.Text = "";
        chkActive.Checked = true;
    }

  
}