﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class PurchaseReport : System.Web.UI.Page
{
    public static TimeZoneInfo timeZoneInfo = TimeZoneInfo.FindSystemTimeZoneById("India Standard Time");
    public static DateTime dateTime;
    Class1 cl = new Class1();
    HttpCookie lgdcookie;

    protected void Page_Load(object sender, EventArgs e)
    {
        lgdcookie = Request.Cookies["loggeduser"];
        dateTime = TimeZoneInfo.ConvertTime(DateTime.Now, timeZoneInfo);
        if (lgdcookie != null && !string.IsNullOrEmpty(lgdcookie["UserName"]))
        {
            if (!IsPostBack)
            {
                txtfrom.Text = dateTime.ToString("yyyy-MM-dd");
                txtto.Text = dateTime.ToString("yyyy-MM-dd");
            }
        }
        else
        {
            Response.Redirect("Login.aspx");
        }
    }

    protected void btnExportExcel_Click(object sender, EventArgs e)
    {
        try
        {
            DateTime fromDate = DateTime.Parse(txtfrom.Text);
            DateTime toDate = DateTime.Parse(txtto.Text);

            DataTable dt = GetItemWiseSaleReport(fromDate, toDate);
            this.EnableViewState = false;

            Response.Clear();
            Response.ClearHeaders();
            Response.ClearContent();

            Response.AddHeader("content-disposition",
                "attachment;filename=PurchaseReport_" + DateTime.Now.ToString("ddMMyyyy") + ".xls");
            Response.ContentType = "application/vnd.ms-excel";
            Response.Charset = "";

            if (dt.Rows.Count > 0)
            {
                StringBuilder sb = new StringBuilder();

                sb.Append("<style>");
                sb.Append("table { border-collapse: collapse; width:100%; font-family:Calibri; font-size:14px; }");
                sb.Append("th,td { border:1px solid #000; padding:5px; }");
                sb.Append("th { background:#f2f2f2; }");
                sb.Append("</style>");

                sb.Append("<table>");

                sb.Append("<tr><td colspan='10' style='font-size:20px;font-weight:bold;text-align:center'>Charans Club & Resort Pvt Ltd</td></tr>");
                sb.Append("<tr><td colspan='10' style='text-align:center;font-weight:bold'>Purchase Report</td></tr>");
                sb.Append("<tr><td colspan='10'><b>Date :</b> " + fromDate.ToString("dd-MM-yyyy") + " To " + toDate.ToString("dd-MM-yyyy") + "</td></tr>");

                sb.Append("<tr>");
                sb.Append("<th>Sr.No.</th>");
                sb.Append("<th>Purchase Date</th>");
                sb.Append("<th>Purchase No</th>");
                sb.Append("<th>Invoice No</th>");
                sb.Append("<th>Invoice Date</th>");
                sb.Append("<th>Category</th>");
                sb.Append("<th>Item Name</th>");
                sb.Append("<th>Qty</th>");
                sb.Append("<th>Rate</th>");
                sb.Append("<th>Amount</th>");
                sb.Append("</tr>");

                string currentPurchaseNo = "";
                int srNo = 1;

                int purchaseQtyTotal = 0;
                decimal purchaseAmtTotal = 0;

                int grandQty = 0;
                decimal grandAmt = 0;

                foreach (DataRow row in dt.Rows)
                {
                    string purchaseNo = row["pid"].ToString();
                    string purchaseDate = row["pdate"].ToString();
                    string invoiceNo = row["pno"].ToString();
                    string invoiceDate = row["Billdate"].ToString();
                    string invoice = row["pinv"].ToString();
                    string category = row["Item_G_Name"].ToString();
                    string itemName = row["itemname"].ToString();

                    int qty = Convert.ToInt32(row["qty"]);
                    string rate = row["rate"].ToString();
                    decimal amt = Convert.ToDecimal(row["amount"]);

                    if (currentPurchaseNo != "" && purchaseNo != currentPurchaseNo)
                    {
                        sb.Append("<tr style='font-weight:bold;background:#f5f5f5'>");
                        sb.Append("<td colspan='7' style='text-align:right'>Sub Total :</td>");
                        sb.Append("<td>" + purchaseQtyTotal + "</td>");
                        sb.Append("<td></td>");
                        sb.Append("<td>" + purchaseAmtTotal.ToString("0.00") + "</td>");
                        sb.Append("</tr>");

                        purchaseQtyTotal = 0;
                        purchaseAmtTotal = 0;
                    }

                    sb.Append("<tr>");

                    if (purchaseNo != currentPurchaseNo)
                    {
                        sb.Append("<td>" + srNo + "</td>");
                        sb.Append("<td>" + purchaseDate + "</td>");
                        sb.Append("<td>" + invoiceNo + "</td>");
                        sb.Append("<td>" + invoice + "</td>");
                        sb.Append("<td>" + invoiceDate + "</td>");
                        srNo++;
                    }
                    else
                    {
                        sb.Append("<td></td><td></td><td></td><td></td><td></td>");
                    }

                    sb.Append("<td>" + category + "</td>");
                    sb.Append("<td>" + itemName + "</td>");
                    sb.Append("<td>" + qty + "</td>");
                    sb.Append("<td>" + rate + "</td>");
                    sb.Append("<td>" + amt.ToString("0.00") + "</td>");
                    sb.Append("</tr>");

                    purchaseQtyTotal += qty;
                    purchaseAmtTotal += amt;

                    grandQty += qty;
                    grandAmt += amt;

                    currentPurchaseNo = purchaseNo;
                }

                sb.Append("<tr style='font-weight:bold;background:#f5f5f5'>");
                sb.Append("<td colspan='7' style='text-align:right'>Sub Total :</td>");
                sb.Append("<td>" + purchaseQtyTotal + "</td>");
                sb.Append("<td></td>");
                sb.Append("<td>" + purchaseAmtTotal.ToString("0.00") + "</td>");
                sb.Append("</tr>");

                sb.Append("<tr style='font-weight:bold;background:#d9edf7'>");
                sb.Append("<td colspan='7' style='text-align:right'>GRAND TOTAL :</td>");
                sb.Append("<td>" + grandQty + "</td>");
                sb.Append("<td></td>");
                sb.Append("<td>" + grandAmt.ToString("0.00") + "</td>");
                sb.Append("</tr>");

                sb.Append("</table>");

                Response.Write(sb.ToString());
                Response.Flush();
                Response.End();
            }
            else
            {
                ScriptManager.RegisterStartupScript(
                    this, this.GetType(), "alert",
                    "alert('No data found');", true);
            }
        }
        catch (Exception ex)
        {

        }
    }

    public override void VerifyRenderingInServerForm(Control control)
    {

    }
    public DataTable GetItemWiseSaleReport(DateTime fromDate, DateTime toDate)
    {
        StringBuilder query = new StringBuilder("SELECT pi.pid, CONVERT(NVARCHAR, pi.pdate, 103) AS pdate,pi.pno,pinv,CONVERT(NVARCHAR, pi.pinvdt, 103) AS Billdate,sd.Item_name as itemname,(CAST(pi.qty AS INT))as qty,pi.rate,pi.amount,sm.Item_G_Name FROM PurchaseEntry pi left join StoreItem_detail sd on pi.itemname=sd.SKU inner join StoreItem_group_Master sm on pi.itemcate=sm.Item_G_Id WHERE pi.pdate BETWEEN @fromDate AND @toDate");
        SqlCommand cmd = new SqlCommand(query.ToString(), cl.con);
        cmd.Parameters.AddWithValue("@FromDate", fromDate);
        cmd.Parameters.AddWithValue("@ToDate", toDate);
        SqlDataAdapter adp = new SqlDataAdapter(cmd);
        DataTable dt = new DataTable();
        adp.Fill(dt);
        return dt;
    }
    protected void btnback_Click(object sender, EventArgs e)
    {
        Response.Redirect("StoreDashboard.aspx");
    }
}