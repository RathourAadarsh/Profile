﻿<%@ Page Title="" Language="C#" MasterPageFile="~/Staff/StaffMaster.master" AutoEventWireup="true" CodeFile="Dashboard.aspx.cs" Inherits="Staff_Dashboard" %>

<asp:Content ID="Content1" ContentPlaceHolderID="head" runat="Server">
    <style>
        .dashboard-container {
            display: flex;
            flex-wrap: wrap;
            gap: 25px;
            justify-content: center;
            margin-top: 30px;
        }

        .dashboard-box {
            flex: 1 1 230px;
            max-width: 260px;
            height: 130px;
            border-radius: 14px;
            color: #fff;
            padding: 20px;
            display: flex;
            flex-direction: column;
            justify-content: center;
            text-align: center;
            cursor: pointer;
            transition: all 0.3s ease;
            box-shadow: 0 8px 20px rgba(0,0,0,0.15);
            text-decoration: none;
        }

            .dashboard-box:hover {
                transform: translateY(-10px);
                box-shadow: 0 12px 25px rgba(0,0,0,0.35);
            }

        .dashboard-title {
            font-size: 17px;
            font-weight: 600;
            letter-spacing: 1px;
        }

        .dashboard-count {
            font-size: 26px;
            font-weight: bold;
            margin-top: 5px;
        }

        .box1 {
            background: linear-gradient(135deg, #667eea, #764ba2);
        }

        .box2 {
            background: linear-gradient(135deg, #f7971e, #ffd200);
        }

        .box3 {
            background: linear-gradient(135deg, #43cea2, #185a9d);
        }

        .box4 {
            background: linear-gradient(135deg, #260f14, #b3756a);
        }

        .box5 {
            background: linear-gradient(135deg, #ff416c, #ff4b2b);
        }

        .box6 {
            background: linear-gradient(135deg, #ff416c, #ff4b2b);
        }

        .box7 {
            background: linear-gradient(135deg, #ff416c, #ff4b2b);
        }

        @media (max-width: 768px) {
            .dashboard-box {
                max-width: 90%;
                font-size: 16px;
            }
        }
    </style>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="ContentPlaceHolder1" runat="Server">
    <div class="container" style="margin-top: 100px;">
        <div class="dashboard-container">
            <!-- New Dashboard Options -->
            <asp:LinkButton runat="server" ID="btnpurchase" CssClass="dashboard-box box1" OnClick="btnpurchase_Click">
                <i class="fa-solid fa-cart-shopping"></i>
                <span class="dashboard-title" style="padding-top:12px;">Purchase Entry</span>
            </asp:LinkButton>
            <asp:LinkButton runat="server" ID="btnsales" CssClass="dashboard-box box2">
                <i class="fa-solid fa-file-invoice-dollar"></i>
                <span class="dashboard-title" style="padding-top:12px;">Sales / Billing</span>
            </asp:LinkButton>
            <asp:LinkButton runat="server" ID="btnstock" CssClass="dashboard-box box3">
                <i class="fa-solid fa-warehouse"></i>
                <span class="dashboard-title" style="padding-top:12px;">Stock / Inventory</span>
            </asp:LinkButton>
            <asp:LinkButton runat="server" ID="btnreports" CssClass="dashboard-box box4">
                <i class="fa-solid fa-chart-line"></i>
                <span class="dashboard-title" style="padding-top:12px;">Reports</span>
            </asp:LinkButton>
            <asp:LinkButton runat="server" ID="btnalerts" CssClass="dashboard-box box6">
               <i class="fas fa-exclamation-circle"></i>
                <span class="dashboard-title" style="padding-top:12px;">Expiry / Alerts</span>
            </asp:LinkButton>
        </div>
    </div>
</asp:Content>

