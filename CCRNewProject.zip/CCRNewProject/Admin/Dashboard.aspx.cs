﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Admin_Dashboard : System.Web.UI.Page
{
    Class1 cl = new Class1();
    public static TimeZoneInfo timeZoneInfo = TimeZoneInfo.FindSystemTimeZoneById("India Standard Time");
    public static DateTime dateTime;
    protected void Page_Load(object sender, EventArgs e)
    {
        dateTime = TimeZoneInfo.ConvertTime(DateTime.Now, timeZoneInfo);
        if (!IsPostBack)
        {
            binddetails();
        }
    }

    private void binddetails()
    {
        SqlCommand cmd = new SqlCommand("SELECT COUNT(*) AS KotCount,ISNULL(SUM(Grandtotal),0) AS KotAmount FROM kot_master WHERE KOT_Date >= CONVERT(date, GETUTCDATE()) AND KOT_Date < DATEADD(day, 1, CONVERT(date, GETUTCDATE()))", cl.con);
        cl.con.Open();
        SqlDataReader dr = cmd.ExecuteReader();
        if (dr.Read())
        {
            todaycountkot.InnerText = dr["KotCount"].ToString();
            todaytotalcountkot.InnerText = dr["KotAmount"].ToString();
        }
        cl.con.Close();
        SqlCommand cmd1 = new SqlCommand("SELECT COUNT(*) AS KotCount,ISNULL(SUM(Grandtotal),0) AS KotAmount FROM Bill_Master WHERE Bill_Date >= CONVERT(date, GETUTCDATE()) AND Bill_Date < DATEADD(day, 1, CONVERT(date, GETUTCDATE()))", cl.con);
        cl.con.Open();
        SqlDataReader dr1 = cmd1.ExecuteReader();
        if (dr1.Read())
        {
            todaycountbill.InnerText = dr1["KotCount"].ToString();
            todaytotalcountbill.InnerText = dr1["KotAmount"].ToString();
        }
        cl.con.Close();
        SqlCommand cmd2 = new SqlCommand("SELECT COUNT(*) AS KotCount,ISNULL(SUM(Grandtotal),0) AS KotAmount FROM Bill_Master WHERE IsPaid= 1 and Bill_Date >= CONVERT(date, GETUTCDATE()) AND Bill_Date < DATEADD(day, 1, CONVERT(date, GETUTCDATE()))", cl.con);
        cl.con.Open();
        SqlDataReader dr2 = cmd2.ExecuteReader();
        if (dr2.Read())
        {
            todaycountsett.InnerText = dr2["KotCount"].ToString();
            todaytotalcountsett.InnerText = dr2["KotAmount"].ToString();
        }
        cl.con.Close();
    }
}