﻿<%@ Page Title="" Language="C#" MasterPageFile="~/Staff/StaffMaster.master" AutoEventWireup="true" CodeFile="PurchaseEntry.aspx.cs" Inherits="Staff_PurchaseEntry" %>
<%@ Register Assembly="System.Web.Extensions, Version=4.0.0.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35"
    Namespace="System.Web.UI" TagPrefix="asp" %>

<asp:Content ID="Content1" ContentPlaceHolderID="head" runat="Server">
    <script>

        function calculateAmount() {
            var qty = document.getElementById('<%=txtQty.ClientID%>').value;
            var rate = document.getElementById('<%=txtPRate.ClientID%>').value;

            if (qty != "" && rate != "") {
                document.getElementById('<%=txtAmount.ClientID%>').value = qty * rate;
            }
        }

</script>

</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="ContentPlaceHolder1" runat="Server">
    <div class="container mt-4">
        <div class="card shadow">
            <div class="card-header bg-success text-white">
                <h5 style="text-align: center; font-weight: 600;">Purchase Entry</h5>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-2">
                        <label>Purchase No</label>
                    </div>
                    <div class="col-md-2">
                        <asp:TextBox ID="txtPurchaseNo" runat="server" CssClass="form-control"></asp:TextBox>
                    </div>
                    <div class="col-md-2">
                        <label>Purchase Date</label>
                    </div>
                    <div class="col-md-2">
                        <asp:TextBox ID="txtDate" runat="server" TextMode="Date" CssClass="form-control"></asp:TextBox>
                    </div>
                    <div class="col-md-1">
                        <label>Supplier</label>
                    </div>
                    <div class="col-md-3">
                        <asp:DropDownList ID="ddlsupplier" runat="server" CssClass="form-control"></asp:DropDownList>
                    </div>
                </div>
                <hr />
                <div class="table-responsive">
                    <table class="table table-bordered">
                        <thead class="table-dark">
                            <tr>
                                <th>Medicine</th>
                                <th>Batch No</th>
                                <th>Expiry</th>
                                <th>Qty</th>
                                <th>Purchase Rate</th>
                                <th>Sale Rate</th>
                                <th>GST%</th>
                                <th>Amount</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>
                                    <asp:DropDownList ID="ddlmedicine" runat="server" CssClass="form-control"></asp:DropDownList>
                                </td>
                                <td>
                                    <asp:TextBox ID="txtBatch" runat="server" CssClass="form-control"></asp:TextBox>
                                </td>
                                <td>
                                    <asp:TextBox ID="txtExpiry" runat="server" TextMode="Date" CssClass="form-control"></asp:TextBox>
                                </td>
                                <td>
                                    <asp:TextBox ID="txtQty" runat="server" CssClass="form-control" onkeyup="calculateAmount()"></asp:TextBox>
                                </td>
                                <td>
                                    <asp:TextBox ID="txtPRate" runat="server" CssClass="form-control" onkeyup="calculateAmount()"></asp:TextBox>
                                </td>
                                <td>
                                    <asp:TextBox ID="txtSRate" runat="server" CssClass="form-control"></asp:TextBox>
                                </td>
                                <td>
                                    <asp:TextBox ID="txtGST" runat="server" CssClass="form-control"></asp:TextBox>
                                </td>
                                <td>
                                    <asp:TextBox ID="txtAmount" runat="server" CssClass="form-control"></asp:TextBox>
                                </td>
                                 <td>
                                    <asp:Button ID="btnadd" runat="server" CssClass="btn btn-success" Text="Add"></asp:Button>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <div class="row mt-3">
                    <div class="col-md-3 offset-md-9">
                        <label>Total Amount</label>
                        <asp:TextBox ID="txtTotal" runat="server" CssClass="form-control"></asp:TextBox>
                    </div>
                </div>
                <br />
                <div class="text-center">
                    <asp:Button ID="btnSave" runat="server" Text="Final Save" CssClass="btn btn-success" OnClick="btnSave_Click" />
                    <asp:Button ID="btnClear" runat="server" Text="Back" CssClass="btn btn-danger" />
                </div>
            </div>
        </div>
    </div>
</asp:Content>

