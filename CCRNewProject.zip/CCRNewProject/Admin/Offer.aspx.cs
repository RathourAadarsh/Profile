﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;

public partial class Offer : System.Web.UI.Page
{
    Class1 cl = new Class1();

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            LoadTree();
        }
    }

    void LoadTree()
    {
        string q1 = "select item_g_id, item_g_name from Item_group_master";
        SqlDataAdapter sda1 = new SqlDataAdapter(q1, cl.con);
        DataTable dtGroup = new DataTable();
        sda1.Fill(dtGroup);

        rptGroup.DataSource = dtGroup;
        rptGroup.DataBind();
    }

    protected void rptGroup_ItemDataBound(object sender, RepeaterItemEventArgs e)
    {
        if (e.Item.ItemType == ListItemType.Item ||
            e.Item.ItemType == ListItemType.AlternatingItem)
        {
            DataRowView drv = (DataRowView)e.Item.DataItem;

            string q2 = "select Sku, item_name from item_detail where item_group_name=@gid";
            SqlDataAdapter sda2 = new SqlDataAdapter(q2, cl.con);
            sda2.SelectCommand.Parameters.AddWithValue("@gid", drv["item_g_name"]);

            DataTable dtItem = new DataTable();
            sda2.Fill(dtItem);

            Repeater rptItem = (Repeater)e.Item.FindControl("rptItem");
            rptItem.DataSource = dtItem;
            rptItem.DataBind();
        }
    }
    protected void btnSave_Click(object sender, EventArgs e)
    {
        try
        {
            // 🔹 BASIC VALIDATION
            if (string.IsNullOrWhiteSpace(txtTitle.Text))
            {
                ScriptManager.RegisterStartupScript(this, GetType(), "err", "alert('Title is required');", true);
                return;
            }

            if (!rbPercent.Checked && !rbFixed.Checked && !rbBOGO.Checked && !rbFixedPrice.Checked)
            {
                ScriptManager.RegisterStartupScript(this, GetType(), "err", "alert('Select Discount Type');", true);
                return;
            }

            // 🔹 READ VALUES
            string title = txtTitle.Text.Trim();
            string discountOn = ddlDiscountOn.SelectedValue;

            bool isDelivery = chkDelivery.Checked;
            bool isPickup = chkPickup.Checked;
            bool isDineIn = chkDineIn.Checked;

            decimal itemLimit = string.IsNullOrWhiteSpace(txtItemLimit.Text) ? 0 : Convert.ToDecimal(txtItemLimit.Text);

            string discountType =
                rbPercent.Checked ? "PERCENT" :
                rbFixed.Checked ? "FIXED" :
                rbBOGO.Checked ? "BOGO" : "FIXED_PRICE";

            string addDiscountOn = rbAmount.Checked ? "AMOUNT" : "PAYMENT";

            string applicableOn =
                rbAll.Checked ? "ALL" :
                rbCategory.Checked ? "CATEGORY" : "ITEM";

            int bogoBuyQty = string.IsNullOrWhiteSpace(txtbuy.Text) ? 0 : Convert.ToInt32(txtbuy.Text);
            int bogoGetQty = string.IsNullOrWhiteSpace(txtget.Text) ? 0 : Convert.ToInt32(txtget.Text);

            string bogoDiscountType =
                RadioButton1.Checked ? "PERCENT" :
                RadioButton2.Checked ? "FIXED" : "";

            decimal bogoAmount = string.IsNullOrWhiteSpace(txtamount.Text) ? 0 : Convert.ToDecimal(txtamount.Text);

            string bogoGetItemType =
                rbGetLower.Checked ? "LOWER" :
                rbGetHigher.Checked ? "HIGHER" :
                rbGetSame.Checked ? "SAME" : "";

            string bogoBuyItemType =
                rbBuyLower.Checked ? "LOWER" :
                rbBuyHigher.Checked ? "HIGHER" : "";

            decimal bogoBuyAmount = string.IsNullOrWhiteSpace(txtbogobuyamt.Text) ? 0 : Convert.ToDecimal(txtbogobuyamt.Text);

            DateTime? fromDate = string.IsNullOrWhiteSpace(txtfrom.Text) ? (DateTime?)null : Convert.ToDateTime(txtfrom.Text);
            DateTime? toDate = string.IsNullOrWhiteSpace(txtro.Text) ? (DateTime?)null : Convert.ToDateTime(txtro.Text);

            bool allDays = checkalldate.Checked;
            bool status = checkstatus.Checked;

            string description = TextBox1.Text.Trim();
            string terms = TextBox2.Text.Trim();

            // 🔹 INSERT OFFER MASTER
            SqlCommand cmd = new SqlCommand(@"
            INSERT INTO Offer_Master
            (Title, DiscountOn, Delivery, Pickup, DineIn, ItemLimit,
             DiscountType, AddDiscountOn, ApplicableOn,
             BogoBuyQty, BogoGetQty, BogoDiscountType, BogoAmount,
             BogoGetItemType, BogoBuyItemType, BogoBuyAmount,
             FromDate, ToDate, AllDays, Status, Description, Terms)
            OUTPUT INSERTED.OfferId
            VALUES
            (@Title,@DiscountOn,@Delivery,@Pickup,@DineIn,@ItemLimit,
             @DiscountType,@AddDiscountOn,@ApplicableOn,
             @BogoBuyQty,@BogoGetQty,@BogoDiscountType,@BogoAmount,
             @BogoGetItemType,@BogoBuyItemType,@BogoBuyAmount,
             @FromDate,@ToDate,@AllDays,@Status,@Description,@Terms)", cl.con);

            cmd.Parameters.AddWithValue("@Title", title);
            cmd.Parameters.AddWithValue("@DiscountOn", discountOn);
            cmd.Parameters.AddWithValue("@Delivery", isDelivery);
            cmd.Parameters.AddWithValue("@Pickup", isPickup);
            cmd.Parameters.AddWithValue("@DineIn", isDineIn);
            cmd.Parameters.AddWithValue("@ItemLimit", itemLimit);
            cmd.Parameters.AddWithValue("@DiscountType", discountType);
            cmd.Parameters.AddWithValue("@AddDiscountOn", addDiscountOn);
            cmd.Parameters.AddWithValue("@ApplicableOn", applicableOn);
            cmd.Parameters.AddWithValue("@BogoBuyQty", bogoBuyQty);
            cmd.Parameters.AddWithValue("@BogoGetQty", bogoGetQty);
            cmd.Parameters.AddWithValue("@BogoDiscountType", bogoDiscountType);
            cmd.Parameters.AddWithValue("@BogoAmount", bogoAmount);
            cmd.Parameters.AddWithValue("@BogoGetItemType", bogoGetItemType);
            cmd.Parameters.AddWithValue("@BogoBuyItemType", bogoBuyItemType);
            cmd.Parameters.AddWithValue("@BogoBuyAmount", bogoBuyAmount);
            cmd.Parameters.AddWithValue("@FromDate", (object)fromDate ?? DBNull.Value);
            cmd.Parameters.AddWithValue("@ToDate", (object)toDate ?? DBNull.Value);
            cmd.Parameters.AddWithValue("@AllDays", allDays);
            cmd.Parameters.AddWithValue("@Status", status);
            cmd.Parameters.AddWithValue("@Description", description);
            cmd.Parameters.AddWithValue("@Terms", terms);

            cl.con.Open();
            int offerId = Convert.ToInt32(cmd.ExecuteScalar());
            cl.con.Close();

            // 🔹 SAVE SELECTED ITEMS
            SaveSelectedItems(offerId);

            ScriptManager.RegisterStartupScript(this, GetType(), "ok", "alert('Offer saved successfully');", true);
        }
        catch (Exception ex)
        {
            ScriptManager.RegisterStartupScript(this, GetType(), "err", "alert('" + ex.Message.Replace("'", "") + "');", true);
        }
    }
    private void SaveSelectedItems(int offerId)
    {
        foreach (RepeaterItem grp in rptGroup.Items)
        {
            Repeater rptItem = (Repeater)grp.FindControl("rptItem");

            foreach (RepeaterItem itm in rptItem.Items)
            {
                HtmlInputCheckBox chk = (HtmlInputCheckBox)itm.FindControl("chkItem");

                if (chk != null && chk.Checked)
                {
                    SqlCommand cmd = new SqlCommand(
                        "INSERT INTO Offer_Items (OfferId, ItemSku) VALUES (@OfferId,@ItemSku)", cl.con);

                    cmd.Parameters.AddWithValue("@OfferId", offerId);
                    cmd.Parameters.AddWithValue("@ItemSku", chk.Value);

                    cl.con.Open();
                    cmd.ExecuteNonQuery();
                    cl.con.Close();
                }
            }
        }
    }

}