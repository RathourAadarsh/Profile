﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Admin_GroupReport : System.Web.UI.Page
{
    Class1 cl = new Class1();
    public static TimeZoneInfo timeZoneInfo = TimeZoneInfo.FindSystemTimeZoneById("India Standard Time");
    public static DateTime dateTime;
    protected void Page_Load(object sender, EventArgs e)
    {
        dateTime = TimeZoneInfo.ConvertTime(DateTime.Now, timeZoneInfo);
        if (!IsPostBack)
        {
            txtfrom.Text = dateTime.ToString("yyyy-MM-dd");              
        }
    }
    protected void btnback_Click(object sender, EventArgs e)
    {
        Response.Redirect("GroupReport.aspx");
    }        
    protected void btnExportExcel_Click(object sender, EventArgs e)
    {
        DateTime fromDate = DateTime.Parse(txtfrom.Text);

        DataTable dt = new DataTable();

        string query = @"WITH ItemSales AS (
    SELECT
        ig.subpgroupname AS GroupName,
        id.item_name     AS ItemName,
        SUM(bd.qty)      AS Qty,
        SUM(bd.Amount)   AS MyAmount,
        SUM(bm.Discount) AS TotalDiscount,
        SUM(bd.Amount - bm.Discount) AS NetAmount,
        SUM((bd.Amount - bm.Discount) * ISNULL(id.gst_per,0) / 100.0) AS TotalTax,
        SUM((bd.Amount - bm.Discount) +
            ((bd.Amount - bm.Discount) * ISNULL(id.gst_per,0) / 100.0)) AS TotalSales
    FROM Bill_Detail bd
    JOIN bill_master bm ON bd.Bill_ID = bm.Bill_ID
    JOIN item_detail id ON bd.itemname = id.item_name
    JOIN item_group_master ig ON id.item_group_name = ig.Item_G_Id
     WHERE bm.ispaid = 1
      AND bm.bill_date >= @billDate
      AND bm.bill_date < DATEADD(DAY, 1, @billDate) 
    GROUP BY ig.subpgroupname, id.item_name
),
Summary AS(SELECT
        'Max' AS GroupName,
        '-' AS ItemName,
        MAX(Qty) AS Qty,
        MAX(MyAmount) AS MyAmount,
        MAX(TotalDiscount) AS TotalDiscount,
        MAX(NetAmount) AS NetAmount,
        MAX(TotalTax) AS TotalTax,
        MAX(TotalSales) AS TotalSales,
        0 AS GroupOrder,
        0 AS RowOrder
    FROM ItemSales
    UNION ALL
    SELECT
        'Min',
        '-',
        MIN(Qty),
        MIN(MyAmount),
        MIN(TotalDiscount),
        MIN(NetAmount),
        MIN(TotalTax),
        MIN(TotalSales),
        0,
        1
    FROM ItemSales
    UNION ALL
    SELECT
        'Avg',
        '-',
        AVG(Qty),
        AVG(MyAmount),
        AVG(TotalDiscount),
        AVG(NetAmount),
        AVG(TotalTax),
        AVG(TotalSales),
        0,
        2
    FROM ItemSales
    UNION ALL
    SELECT
        'Total',
        '-',
        SUM(Qty),
        SUM(MyAmount),
        SUM(TotalDiscount),
        SUM(NetAmount),
        SUM(TotalTax),
        SUM(TotalSales),
        0,
        3
    FROM ItemSales
       UNION ALL   
    SELECT
        'Sub Total','',
        SUM(Qty),
        SUM(MyAmount),
        SUM(TotalDiscount),
        SUM(NetAmount),
        SUM(TotalTax),
        SUM(TotalSales),
        0,
        4
    FROM ItemSales),
GroupHeader AS
(
    SELECT DISTINCT
        GroupName,
        null AS ItemName,
        NULL AS Qty,
        NULL AS MyAmount,
        NULL AS TotalDiscount,
        NULL AS NetAmount,
        NULL AS TotalTax,
        NULL AS TotalSales,
        DENSE_RANK() OVER (ORDER BY GroupName) AS GroupOrder,
        0 AS RowOrder
    FROM ItemSales
),
GroupItems AS
(
    SELECT
        GroupName,
        '    ' + ItemName AS ItemName,
        Qty,
        MyAmount,
        TotalDiscount,
        NetAmount,
        TotalTax,
        TotalSales,
        DENSE_RANK() OVER (ORDER BY GroupName) AS GroupOrder,
        1 AS RowOrder
    FROM ItemSales
),
GroupSubTotal AS
(
    SELECT
        GroupName,
        null AS ItemName,
        SUM(Qty) AS Qty,
        SUM(MyAmount) AS MyAmount,
        SUM(TotalDiscount) AS TotalDiscount,
        SUM(NetAmount) AS NetAmount,
        SUM(TotalTax) AS TotalTax,
        SUM(TotalSales) AS TotalSales,
        DENSE_RANK() OVER (ORDER BY GroupName) AS GroupOrder,
        2 AS RowOrder
    FROM ItemSales
    GROUP BY GroupName
) SELECT
    CASE 
        WHEN GroupOrder = 0 THEN GroupName
        WHEN RowOrder = 0 THEN GroupName
        WHEN RowOrder = 2 THEN 'Sub Total'
        ELSE NULL
    END AS [Group],

    CASE 
        WHEN RowOrder = 2 THEN NULL
        ELSE ItemName
    END AS [Item],
    Qty,
    MyAmount AS [My Amount],
    TotalDiscount AS [Total Discount],
    NetAmount AS [Net Amount],
    TotalTax AS [Total Tax],
    TotalSales AS [Total Sales]
FROM
(
    SELECT * FROM Summary
    UNION ALL
    SELECT * FROM GroupHeader
    UNION ALL
    SELECT * FROM GroupItems
    UNION ALL
    SELECT * FROM GroupSubTotal
) x
ORDER BY
    GroupOrder,
    RowOrder,
    ItemName;";
        SqlCommand cmd = new SqlCommand(query, cl.con);
        cmd.Parameters.AddWithValue("@billDate", fromDate);
        SqlDataAdapter da = new SqlDataAdapter(cmd);   
        da.Fill(dt);
        Response.Clear();
        Response.Buffer = true;
        Response.AddHeader("content-disposition",
            "attachment;filename=GroupWiseReport_" + DateTime.Now.ToString("ddMMyyyy") + ".xls");
        Response.ContentType = "application/vnd.ms-excel";

        StringWriter sw = new StringWriter();

        sw.Write("<table border='1' style='font-family:Calibri;font-size:14px;border-collapse:collapse;width:100%'>");

        sw.Write("<tr><td td colspan='8' style='font-size:20px;font-weight:bold;text-align:center'>Charans Club & Resort Pvt Ltd</td></tr>");
        sw.Write("<tr><td colspan='8' style='text-align:center;font-weight:bold'>Group Report</td></tr>");
        sw.Write("<tr><td colspan='8'><b>Date :</b> " + fromDate.ToString("dd-MM-yyyy") + " </td></tr>");
        sw.Write("<tr><td colspan='8'></td></tr>");
        sw.Write("<tr style='background:#eee;font-weight:bold'>");
        sw.Write("<th>Group</th>");
        sw.Write("<th>Item</th>");
        sw.Write("<th>Qty</th>");
        sw.Write("<th>My Amount</th>");
        sw.Write("<th>Discount</th>");
        sw.Write("<th>Net Amount</th>");
        sw.Write("<th>Tax</th>");
        sw.Write("<th>Total Sales</th>");
        sw.Write("</tr>");

        string lastGroup = "";

        foreach (DataRow row in dt.Rows)
        {
            string group = row["Group"] == DBNull.Value ? "" : row["Group"].ToString();
            string item = row["Item"] == DBNull.Value ? "" : row["Item"].ToString();

            // 🔹 GROUP HEADER
            if (!string.IsNullOrEmpty(group) && group != lastGroup && row["Qty"] == DBNull.Value)
            {
                sw.Write("<tr style='background:#d9edf7;font-weight:bold'>");
                sw.Write("<td colspan='8'>" + group + "</td>");
                sw.Write("</tr>");

                lastGroup = group;
                continue;
            }

            // 🔹 SUB TOTAL
            if (group == "Sub Total")
            {
                sw.Write("<tr style='background:#f2f2f2;font-weight:bold'>");
            }
            // 🔹 SUMMARY ROWS
            else if (group == "Max" || group == "Min" || group == "Avg" || group == "Total")
            {
                sw.Write("<tr style='background:#ffeeba;font-weight:bold'>");
            }
            else
            {
                sw.Write("<tr>");
            }

            sw.Write("<td>" + group + "</td>");
            sw.Write("<td>" + item + "</td>");
            sw.Write("<td align='right'>" + (row["Qty"] == DBNull.Value ? "" : row["Qty"]) + "</td>");
            sw.Write("<td align='right'>" + (row["My Amount"] == DBNull.Value ? "" : row["My Amount"]) + "</td>");
            sw.Write("<td align='right'>" + (row["Total Discount"] == DBNull.Value ? "" : row["Total Discount"]) + "</td>");
            sw.Write("<td align='right'>" + (row["Net Amount"] == DBNull.Value ? "" : row["Net Amount"]) + "</td>");
            sw.Write("<td align='right'>" + (row["Total Tax"] == DBNull.Value ? "" : row["Total Tax"]) + "</td>");
            sw.Write("<td align='right'>" + (row["Total Sales"] == DBNull.Value ? "" : row["Total Sales"]) + "</td>");
            sw.Write("</tr>");
        }

        sw.Write("</table>");

        Response.Write(sw.ToString());
        Response.End();

    }

    public override void VerifyRenderingInServerForm(Control control)
    {

    }
}