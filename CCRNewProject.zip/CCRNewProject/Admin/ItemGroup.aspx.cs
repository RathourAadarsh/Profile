﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class Admin_ItemGroup : System.Web.UI.Page
{
    public static TimeZoneInfo timeZoneInfo = TimeZoneInfo.FindSystemTimeZoneById("India Standard Time");
    public static DateTime dateTime;
    Class1 cl3 = new Class1();
    HttpCookie lgdcookie;
    protected void Page_Load(object sender, EventArgs e)
    {
        lgdcookie = Request.Cookies["loggeduser"];
        dateTime = TimeZoneInfo.ConvertTime(DateTime.Now, timeZoneInfo);
        if(!IsPostBack)
        {
            txtgid.Text = cl3.Scalar("SELECT isnull(Max(item_g_id+1),1)item_g_id from item_group_master where deactive='0'");
            txtgid.ReadOnly = true;
            bindetail();
        }
    }

    protected void btnsave_Click(object sender, EventArgs e)
    {
        try
        {
            lgdcookie = Request.Cookies["loggeduser"];
            if (txtgrpname.Text == "")
            {
                string message = "Please Enter Item Category Name !!";
                string type = "warning";
                ScriptManager.RegisterStartupScript(this, this.GetType(), "Script", "savealert('" + message + "','" + type + "')", true);
                return;
            }
            else
            {
                if (btnsave.Text == "Save")
                {
                    string query = "insert into item_group_master(item_g_id,Item_G_Name,insdate,intime,deactive,insuser,pgroupname,subpgroupname,childgroupname) values('" + txtgid.Text+ "','"+ txtgrpname.Text+ "','"+dateTime.ToString("yyyy-MM-dd")+"','"+ dateTime.ToString("hh:mm:ss tt") + "','0','"+ lgdcookie["username"].ToString() + "','"+ddlpname.SelectedValue+"','"+ ddlsubparents.SelectedItem.Text+ "','"+ ddlchildbargroup .SelectedItem.Text+ "')";
                    cl3.con.Open();
                    SqlCommand cmd = new SqlCommand(query,cl3.con);
                   int result= cmd.ExecuteNonQuery();
                    cl3.con.Close();
                    if (result>0)
                    {
                        string redirectUrl = "ItemGroup.aspx";
                        string message = "Record Saved Successfully !!";
                        string type = "success";
                        string script = "savealert('" + message + "','" + type + "'); setTimeout(function() { window.location.href = '" + redirectUrl + "'; },1000);";
                        ScriptManager.RegisterStartupScript(this, this.GetType(), "Script", script, true);
                        return;
                    }
                    else
                    {
                        string message = "Something Went Wrong !!";
                        string type = "error";
                        ScriptManager.RegisterStartupScript(this, this.GetType(), "Script", "savealert('" + message + "','" + type + "')", true);
                        return;
                    }
                }
                else
                {
                    cl3.con.Open();
                    string query = @"UPDATE item_group_master
                 SET Item_G_Name = @Item_G_Name,updatedate = @insdate,updatetime = @intime,deactive = @deactive,updateuser = @insuser,pgroupname=@pgroupname,subpgroupname=@subpgroupname,childgroupname=@childgroupname WHERE item_g_id = @item_g_id";
                    using (SqlCommand cmd = new SqlCommand(query, cl3.con))
                    {
                        cmd.Parameters.AddWithValue("@Item_G_Name", txtgrpname.Text);
                        cmd.Parameters.AddWithValue("@insdate", dateTime.ToString("yyyy-MM-dd"));
                        cmd.Parameters.AddWithValue("@intime", dateTime.ToString("hh:mm:ss tt"));
                        cmd.Parameters.AddWithValue("@deactive", "0");
                        cmd.Parameters.AddWithValue("@insuser", lgdcookie["username"].ToString());
                        cmd.Parameters.AddWithValue("@item_g_id", txtgid.Text);
                        cmd.Parameters.AddWithValue("@pgroupname", ddlpname.SelectedValue);
                        cmd.Parameters.AddWithValue("@subpgroupname", ddlsubparents.SelectedItem.Text);
                        cmd.Parameters.AddWithValue("@childgroupname", ddlchildbargroup.SelectedItem.Text);

                        int result = cmd.ExecuteNonQuery();
                        cl3.con.Close();

                        if (result > 0)
                        {
                            string redirectUrl = "ItemGroup.aspx";
                            string message = "Record Updated Successfully !!";
                            string type = "success";
                            string script = "savealert('" + message + "','" + type + "'); setTimeout(function() { window.location.href = '" + redirectUrl + "'; },1000);";
                            ScriptManager.RegisterStartupScript(this, this.GetType(), "Script", script, true);
                            return;
                        }
                        else
                        {
                            string message = "Something Went Wrong !!";
                            string type = "error";
                            ScriptManager.RegisterStartupScript(this, this.GetType(), "Script", "savealert('" + message + "','" + type + "')", true);
                            return;
                        }
                    }
                }
            }
        }
        catch (Exception ex)
        {

        }
    }
    public void bindetail()
    {
        try
        {
            string query = "select item_g_id,Item_G_Name,pgroupname,subpgroupname,childgroupname,case when(Deactive='0') then 'De-Active' else 'Active' end as inactive from item_group_master";
            SqlDataAdapter sda = new SqlDataAdapter(query, cl3.con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                listview2.DataSource = dt;
                listview2.DataBind();
            }
        }
        catch(Exception ex)
        {

        }
    }
    protected void btnback_Click(object sender, EventArgs e)
    {
        Response.Redirect("Dashboard.aspx");
    }
    protected void btnedit_Click(object sender, EventArgs e)
    {
        try
        {
            Button button1 = (Button)sender;
            ListViewItem item = (ListViewItem)button1.NamingContainer;
            Label lblid1 = (Label)item.FindControl("lblcode");
            string query = "select item_g_id,Item_G_Name from item_group_master where deactive='0' and item_g_id='" + lblid1.Text + "'";
            SqlDataAdapter sda = new SqlDataAdapter(query, cl3.con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                txtgid.Text = dt.Rows[0]["item_g_id"].ToString();
                txtgrpname.Text = dt.Rows[0]["Item_G_Name"].ToString();
                btnsave.Text = "Update";
            }
            else
            {
                string message = "Something Went Wrong !!";
                string type = "error";
                ScriptManager.RegisterStartupScript(this, this.GetType(), "Script", "savealert('" + message + "','" + type + "')", true);
                return;
            }
        }
        catch (Exception ex)
        {

        }
    }
    protected void btndelete_Click(object sender, EventArgs e)
    {
        try
        {
            Button button1 = (Button)sender;
            ListViewItem item = (ListViewItem)button1.NamingContainer;
            Label lblid1 = (Label)item.FindControl("lblcode");
            Button btndelete = (Button)item.FindControl("btndelete");
            if (btndelete.Text == "De-Active")
            {
                string up = "update item_group_master set deactive='1' where item_g_id='" + lblid1.Text + "'";
                cl3.execute(up);
                bindetail();
                string redirectUrl = "ItemGroup.aspx";
                string message = "Record Deactivated Successfully !!";
                string type = "info";
                string script = "savealert('" + message + "', '" + type + "'); setTimeout(function() {{ window.location.href = '" + redirectUrl + "'; }},1500);"; ScriptManager.RegisterStartupScript(this, this.GetType(), "Script", script, true);
            }
            else if (btndelete.Text == "Active")
            {
                string up = "update item_group_master set deactive='0' where item_g_id='" + lblid1.Text + "'";
                cl3.execute(up);
                bindetail();
                string redirectUrl = "ItemGroup.aspx";
                string message = "Record Activated Successfully !!";
                string type = "info";
                string script = "savealert('" + message + "', '" + type + "'); setTimeout(function() {{ window.location.href = '" + redirectUrl + "'; }},1500);"; ScriptManager.RegisterStartupScript(this, this.GetType(), "Script", script, true);
            }
        }
        catch (Exception ex)
        {

        }
    }

    protected void ddlpname_SelectedIndexChanged(object sender, EventArgs e)
    {
        if(ddlpname.SelectedValue== "Food")
        {
            binfood();
        }
        else
        {
            bindbar();
            panel1.Visible = true;
        }
    }
    public void binfood()
    {
        try
        {
            string str = "select id,fname from subparentsgroupmaster";
            SqlCommand cmd = new SqlCommand(str, cl3.con);
            SqlDataAdapter adp = new SqlDataAdapter(cmd);
            DataTable dt1 = new DataTable();
            adp.Fill(dt1);
            if (dt1.Rows.Count > 0)
            {
                ddlsubparents.DataSource = dt1;
                ddlsubparents.DataTextField = "fname";
                ddlsubparents.DataValueField = "id";
                ddlsubparents.DataBind();
                ddlsubparents.Items.Insert(0, new ListItem("--Select--", "0"));
            }
        }
        catch (Exception)
        {

        }
    }
    public void bindbar()
    {
        try
        {
            string str = "select id,bname from subparentsgroupmaster order by bname";
            SqlCommand cmd = new SqlCommand(str, cl3.con);
            SqlDataAdapter adp = new SqlDataAdapter(cmd);
            DataTable dt1 = new DataTable();
            adp.Fill(dt1);
            if (dt1.Rows.Count > 0)
            {
                ddlsubparents.DataSource = dt1;
                ddlsubparents.DataTextField = "bname";
                ddlsubparents.DataValueField = "id";
                ddlsubparents.DataBind();
                ddlsubparents.Items.Insert(0, new ListItem("--Select--", "0"));
            }
        }
        catch (Exception)
        {

        }
    }
    public void liquer()
    {
        try
        {
            string str = "select id,liqurname from childGroupMaster";
            SqlCommand cmd = new SqlCommand(str, cl3.con);
            SqlDataAdapter adp = new SqlDataAdapter(cmd);
            DataTable dt1 = new DataTable();
            adp.Fill(dt1);
            if (dt1.Rows.Count > 0)
            {
                ddlchildbargroup.DataSource = dt1;
                ddlchildbargroup.DataTextField = "liqurname";
                ddlchildbargroup.DataValueField = "id";
                ddlchildbargroup.DataBind();
                ddlchildbargroup.Items.Insert(0, new ListItem("--Select--", "0"));
            }
        }
        catch (Exception)
        {

        }
    }
    public void beer()
    {
        try
        {
            string str = "select id,beername from childGroupMaster";
            SqlCommand cmd = new SqlCommand(str, cl3.con);
            SqlDataAdapter adp = new SqlDataAdapter(cmd);
            DataTable dt1 = new DataTable();
            adp.Fill(dt1);
            if (dt1.Rows.Count > 0)
            {
                ddlchildbargroup.DataSource = dt1;
                ddlchildbargroup.DataTextField = "beername";
                ddlchildbargroup.DataValueField = "id";
                ddlchildbargroup.DataBind();
                ddlchildbargroup.Items.Insert(0, new ListItem("--Select--", "0"));
            }
        }
        catch (Exception)
        {

        }
    }

    protected void ddlsubparents_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlsubparents.SelectedItem.Text == "Liquor")
        {
            liquer();
            panel1.Visible = true;
        }
        else
        {
            beer();
            panel1.Visible = true;
        }
    }
}
