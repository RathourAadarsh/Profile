﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

/// <summary>
/// Summary description for DbClass
/// </summary>
public class DbClass
{
    public static TimeZoneInfo timeZoneInfo = TimeZoneInfo.FindSystemTimeZoneById("India Standard Time");
    public static DateTime dateTime;
    Class1 cl3 = new Class1();

    public DbClass()
    {
      
    }
    public bool AddmillMaster(string code, string name, string txtmobile, string txtemailid, string txtlocation, string txtcpname,string txtaddress, string insu,string postalcode)
    {
        try
        {
            dateTime = TimeZoneInfo.ConvertTime(DateTime.Now, timeZoneInfo);
            string query = "INSERT INTO customerMaster(custid, custname,address, cperson,contactno,email,insdate, instime, insuser,insyear,isdeleted,location,postalcode) " + "VALUES (@custid,@custname, @address, @cperson,@contactno,@email, @insdate, @instime, @insuser,@insyear, '0',@location,@postalcode)";

            SqlCommand cmd = new SqlCommand(query, cl3.con);
            cmd.Parameters.AddWithValue("@custid", code);
            cmd.Parameters.AddWithValue("@postalcode", postalcode);
            cmd.Parameters.AddWithValue("@custname", name);
            cmd.Parameters.AddWithValue("@address", txtaddress);
            cmd.Parameters.AddWithValue("@cperson", txtcpname);
            cmd.Parameters.AddWithValue("@contactno", txtmobile);
            cmd.Parameters.AddWithValue("@email", txtemailid);
            cmd.Parameters.AddWithValue("@location", txtlocation);
            cmd.Parameters.AddWithValue("@insdate", dateTime.ToString("yyyy-MM-dd"));
            cmd.Parameters.AddWithValue("@instime", dateTime.ToString("hh:mm:ss tt"));
            cmd.Parameters.AddWithValue("@insuser", insu);
            cmd.Parameters.AddWithValue("@insyear", dateTime.ToString("yyyy"));
            cl3.con.Open();
            int n = cmd.ExecuteNonQuery();
            cl3.con.Close();
            return n > 0;
        }
        catch (Exception ex)
        {
            cl3.con.Close();
            return false;
        }
    }
    public bool UpdateCustomerData(string code, string name, string txtmobile, string txtemailid, string txtlocation, string txtcpname, string txtaddress, string insu,string postalcode)
    {
        try
        {
            dateTime = TimeZoneInfo.ConvertTime(DateTime.Now, timeZoneInfo);

            string query = @"UPDATE customerMaster 
                     SET custname = @custname,
                         address = @address,
                         cperson = @cperson,
                         contactno = @contactno,
                         email = @email,
                         location = @location,
                         postalcode = @postalcode,
                         insdate = @insdate,
                         instime = @instime,
                         insuser = @insuser,
                         insyear = @insyear
                     WHERE custid = @custid";

            SqlCommand cmd = new SqlCommand(query, cl3.con);

            cmd.Parameters.AddWithValue("@custid", code);
            cmd.Parameters.AddWithValue("@custname", name);
            cmd.Parameters.AddWithValue("@address", txtaddress);
            cmd.Parameters.AddWithValue("@cperson", txtcpname);
            cmd.Parameters.AddWithValue("@contactno", txtmobile);
            cmd.Parameters.AddWithValue("@email", txtemailid);
            cmd.Parameters.AddWithValue("@location", txtlocation);
            cmd.Parameters.AddWithValue("@postalcode", postalcode);
            cmd.Parameters.AddWithValue("@insdate", dateTime.ToString("yyyy-MM-dd"));
            cmd.Parameters.AddWithValue("@instime", dateTime.ToString("hh:mm:ss tt"));
            cmd.Parameters.AddWithValue("@insuser", insu);
            cmd.Parameters.AddWithValue("@insyear", dateTime.ToString("yyyy"));

            cl3.con.Open();
            int n = cmd.ExecuteNonQuery();
            cl3.con.Close();

            return n > 0;
        }
        catch (Exception ex)
        {
            cl3.con.Close();
            return false;
        }
    }
    public bool saveorder(string txtid, string txtdate, string txtjobno, string ddlcustomer,string txtreference, string txtsaleprice, string txtpaydate, string txtpaymentamt,string txtframeqty, string framemadeqty, string txtframedate,string txtcompositeqty, string txtcompositevalue,string txtglassqty, string txtglassorderdate, string txtglassrecdate,string txtpanelqty, string txtpanelorderdate, string pnlreceivedate,string txtinvoiceno, string txtinvdate, string txtinvamt,string txtpay2date, string txtpaymentamt2,string txtpaydate3, string txtpaymentamt3,string txtpaymentdate4, string txtpaymentamt4,string insu,string ddlpostalcode,string txtevalno)
    {
        try
        {
            dateTime = TimeZoneInfo.ConvertTime(DateTime.Now, timeZoneInfo);
            string query = "INSERT INTO orderentry (jobid, date, jobno, custname, refrence, saleprice,paymentdate1, paymentamt1,frameqty, framemadeqty, framemadedate,compositeqty, compositevalue,glassqty,panelqty,invno, invdt, invamt,paymentdate2, paymentamt2,paymentdate3, paymentamt3,paymentdate4, paymentamt4,insdate, instime, insuser, insyear,flag,cutflag,weldflag,hangflag,beedflag,postalcode,Evalutionno)VALUES(@orderid, @orderdate, @jobno, @customerid, @reference, @saleprice,@paydate1, @paymentamt1,@frameqty, @framemadeqty, @framedate,@compositeqty, @compositevalue,@glassqty,@panelqty,@invoiceno, @invoicedate, @invoiceamt,@paydate2, @paymentamt2,@paydate3, @paymentamt3,@paydate4, @paymentamt4,@insdate, @instime, @insuser, @insyear,'1','0','02','03','04',@postalcode,@Evalutionno)";

            SqlCommand cmd = new SqlCommand(query, cl3.con);

            cmd.Parameters.AddWithValue("@postalcode", ddlpostalcode);
            cmd.Parameters.AddWithValue("@Evalutionno", txtevalno);
            cmd.Parameters.AddWithValue("@orderid", txtid);
            cmd.Parameters.AddWithValue("@orderdate", txtdate);
            cmd.Parameters.AddWithValue("@jobno", txtjobno);
            cmd.Parameters.AddWithValue("@customerid", ddlcustomer);
            cmd.Parameters.AddWithValue("@reference", txtreference);
            cmd.Parameters.AddWithValue("@saleprice", txtsaleprice);

            cmd.Parameters.AddWithValue("@paydate1", txtpaydate);
            cmd.Parameters.AddWithValue("@paymentamt1", txtpaymentamt);

            cmd.Parameters.AddWithValue("@frameqty", txtframeqty);
            cmd.Parameters.AddWithValue("@framemadeqty", framemadeqty);
            cmd.Parameters.AddWithValue("@framedate", txtframedate);

            cmd.Parameters.AddWithValue("@compositeqty", txtcompositeqty);
            cmd.Parameters.AddWithValue("@compositevalue", txtcompositevalue);

            cmd.Parameters.AddWithValue("@glassqty", txtglassqty);
            cmd.Parameters.AddWithValue("@glassorderdate", txtglassorderdate);
            cmd.Parameters.AddWithValue("@glassreceivedate", txtglassrecdate);

            cmd.Parameters.AddWithValue("@panelqty", txtpanelqty);
            cmd.Parameters.AddWithValue("@panelorderdate", txtpanelorderdate);
            cmd.Parameters.AddWithValue("@panelreceivedate", pnlreceivedate);

            cmd.Parameters.AddWithValue("@invoiceno", txtinvoiceno);
            cmd.Parameters.AddWithValue("@invoicedate", txtinvdate);
            cmd.Parameters.AddWithValue("@invoiceamt", txtinvamt);
            cmd.Parameters.AddWithValue("@paydate2", txtpay2date);
            cmd.Parameters.AddWithValue("@paymentamt2", txtpaymentamt2);
            cmd.Parameters.AddWithValue("@paydate3", txtpaydate3);
            cmd.Parameters.AddWithValue("@paymentamt3", txtpaymentamt3);
            cmd.Parameters.AddWithValue("@paydate4", txtpaymentdate4);
            cmd.Parameters.AddWithValue("@paymentamt4", txtpaymentamt4);
            cmd.Parameters.AddWithValue("@insdate", dateTime.ToString("yyyy-MM-dd"));
            cmd.Parameters.AddWithValue("@instime", dateTime.ToString("hh:mm:ss tt"));
            cmd.Parameters.AddWithValue("@insuser", insu);
            cmd.Parameters.AddWithValue("@insyear", dateTime.ToString("yyyy"));
            cl3.con.Open();
            int n = cmd.ExecuteNonQuery();
            cl3.con.Close();
            return n > 0;
        }
        catch (Exception ex)
        {
            cl3.con.Close();
            return false;
        }
    }
}