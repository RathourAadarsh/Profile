﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class GroceryMaster : System.Web.UI.MasterPage
{
    public static TimeZoneInfo timeZoneInfo = TimeZoneInfo.FindSystemTimeZoneById("India Standard Time");
    public static DateTime dateTime;
    Class1 cl3 = new Class1();
    HttpCookie lgdcookie;

    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnlogou_Click(object sender, EventArgs e)
    {
        try
        {
            Session.Clear();
            Session.Abandon();
            HttpCookie lgdcookie = new HttpCookie("loggeduser");
            lgdcookie.Expires = DateTime.Now.AddDays(-1);
            Response.Cookies.Add(lgdcookie);
            Response.Redirect("Login.aspx");
        }
        catch (Exception ex)
        {

        }
    }
}
