﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class StockReport : System.Web.UI.Page
{
    public static TimeZoneInfo timeZoneInfo = TimeZoneInfo.FindSystemTimeZoneById("India Standard Time");
    public static DateTime dateTime;
    Class1 cl = new Class1();
    HttpCookie lgdcookie;
    protected void Page_Load(object sender, EventArgs e)
    {
        lgdcookie = Request.Cookies["loggeduser"];
        dateTime = TimeZoneInfo.ConvertTime(DateTime.Now, timeZoneInfo);
        if (!IsPostBack)
        {
            txtfdt.Text = dateTime.ToString("yyyy-MM-dd");
            txttodate.Text = dateTime.ToString("yyyy-MM-dd");
        }  
    }
    protected void btnview_Click(object sender, EventArgs e)
    {
        try
        {
            SqlCommand cmd = new SqlCommand("stockreport", cl.con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@fromdate", txtfdt.Text);
            cmd.Parameters.AddWithValue("@todate", txttodate.Text);
            SqlDataAdapter sa = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            sa.Fill(dt);
            lvReport.DataSource = dt;
            lvReport.DataBind();
        }
        catch(Exception ex)
        {

        }
    }
    protected void btnexcel_Click(object sender, EventArgs e)
    {
        try
        {
            DateTime fromDate = DateTime.Parse(txtfdt.Text);
            DateTime toDate = DateTime.Parse(txttodate.Text);
            SqlCommand cmd = new SqlCommand("stockreport", cl.con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@fromdate", fromDate);
            cmd.Parameters.AddWithValue("@todate", toDate);
            SqlDataAdapter sa = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            sa.Fill(dt);
            this.EnableViewState = false;
            Response.Clear();
            Response.ClearHeaders();
            Response.ClearContent();
            Response.AddHeader("content-disposition",
                "attachment;filename=StockReport_" + DateTime.Now.ToString("ddMMyyyy") + ".xls");
            Response.ContentType = "application/vnd.ms-excel";
            Response.Charset = "";
            if(dt.Rows.Count>0)
            {
                StringBuilder sb = new StringBuilder();
                sb.Append("<style>");
                sb.Append("table { border-collapse: collapse; width:100%; font-family:Calibri; font-size:14px; }");
                sb.Append("th,td { border:1px solid #000; padding:5px; text-align:center; }");
                sb.Append("th { background:#f2f2f2; }");
                sb.Append("</style>");
                sb.Append("<table>");
                sb.Append("<tr><td colspan='6' style='font-size:20px;font-weight:bold;text-align:center'>Charans Club & Resort Pvt Ltd</td></tr>");
                sb.Append("<tr><td colspan='6' style='text-align:center;font-weight:bold'>Stock Report</td></tr>");
                sb.Append("<tr><td colspan='6'><b>Date :</b> " + fromDate.ToString("dd-MM-yyyy") + " To " + toDate.ToString("dd-MM-yyyy") + "</td></tr>");
                sb.Append("<tr>");
                sb.Append("<th>Item Category </th>");
                sb.Append("<th>Item Name </th>");
                sb.Append("<th>Opening Qty</th>");
                sb.Append("<th>Purchase Qty </th>");
                sb.Append("<th>Issue Qty</th>");
                sb.Append("<th>Closing</th>");
                foreach (DataRow row in dt.Rows)
                {
                    string itemcate = row["itemcategory"].ToString();
                    string itemname = row["Item_name"].ToString();
                    string openingqty = row["openingQty"].ToString();
                    string purchaseqty = row["PurchaseQty"].ToString();
                    string issueqty = row["IssueQty"].ToString();
                    string closingqty = row["ClosingQty"].ToString();
                    sb.Append("<tr>");
                    sb.Append("<td>" + itemcate + "</td>");
                    sb.Append("<td>" + itemname + "</td>");
                    sb.Append("<td>" + openingqty + "</td>");
                    sb.Append("<td>" + purchaseqty + "</td>");
                    sb.Append("<td>" + issueqty + "</td>");
                    sb.Append("<td>" + closingqty + "</td>");
                    sb.Append("</tr>");
                }
                sb.Append("</table>");
                Response.Write(sb.ToString());
                Response.Flush();
                Response.End();
            }
            else
            {
                ScriptManager.RegisterStartupScript(
                    this, this.GetType(), "alert",
                    "alert('No data found');", true);
            }

        }
        catch (Exception ex)
        {

        }
    }   
}