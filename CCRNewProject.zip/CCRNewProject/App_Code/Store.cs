﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.IO;

public class Store
{
    public static TimeZoneInfo timeZoneInfo = TimeZoneInfo.FindSystemTimeZoneById("India Standard Time");
    public static DateTime dateTime;
    Class1 cl3 = new Class1();
    public Store()
    {

    }
    public bool Apurchase(string lblautoid, string txtpno, string txtpdate, string txtinvno, string txtindate, string ddlitename, string txtqty, string txtrate, string txtamt, string insu, string finyear, string ddlitemcate,string ptype,string ddlunit)
    {
        try
        {
            DateTime dateTime = TimeZoneInfo.ConvertTime(DateTime.Now, TimeZoneInfo.FindSystemTimeZoneById("India Standard Time"));
            string query = "INSERT INTO PurchaseEntry(pid,pno,pdate,pinv,pinvdt,itemname,qty,rate,amount,insdate, instime, insuser,finyear,isdeleted,itemcate,ptype,unit) VALUES (@pid,@pno,@pdt, @pinv,@pindt,@pitemname,@qty,@rate,@amt, @insdate, @instime, @insuser,@finyear, '0',@itemcate,@ptype,@unit)";
            SqlCommand cmd = new SqlCommand(query, cl3.con);
            // here is new code
            cmd.Parameters.AddWithValue("@itemcate", ddlitemcate);
            cmd.Parameters.AddWithValue("@pid", lblautoid);
            cmd.Parameters.AddWithValue("@pno", txtpno);
            cmd.Parameters.AddWithValue("@pdt", txtpdate);
            cmd.Parameters.AddWithValue("@pinv", txtinvno);
            cmd.Parameters.AddWithValue("@pindt", txtindate);
            cmd.Parameters.AddWithValue("@pitemname", ddlitename);
            cmd.Parameters.AddWithValue("@qty", txtqty);
            cmd.Parameters.AddWithValue("@rate", txtrate);
            cmd.Parameters.AddWithValue("@amt", txtamt);
            cmd.Parameters.AddWithValue("@insdate", dateTime.ToString("yyyy-MM-dd"));
            cmd.Parameters.AddWithValue("@instime", dateTime.ToString("hh:mm:ss tt"));
            cmd.Parameters.AddWithValue("@insuser", insu);
            cmd.Parameters.AddWithValue("@finyear", finyear);
            cmd.Parameters.AddWithValue("@ptype", ptype);
            cmd.Parameters.AddWithValue("@unit", ddlunit);
            cl3.con.Open();
            int n = cmd.ExecuteNonQuery();
            cl3.con.Close();
            return n > 0;
        }
        catch (Exception ex)
        {
            cl3.con.Close();
            return false;
        }
    }
    public bool Issuetokitchen(string lblautoid, string txtpno, string txtpdate, string txtinvno, string txtindate, string ddlitename, string txtqty, string txtrate, string txtamt, string insu, string finyear, string ddlitemcate, string ptype,string pnon, string ddlunit)
    {
        try
        {
            DateTime dateTime = TimeZoneInfo.ConvertTime(DateTime.Now, TimeZoneInfo.FindSystemTimeZoneById("India Standard Time"));
            string query = "INSERT INTO IssuetoKitchen(isid,ino,idate,inv,invdt,itemname,qty,rate,amount,insdate, instime, insuser,finyear,isdeleted,itemcate,ptype,pno,unit) VALUES (@pid,@pno,@pdt, @pinv,@pindt,@pitemname,@qty,@rate,@amt, @insdate, @instime, @insuser,@finyear, '0',@itemcate,@ptype,@pnon,@unit)";
            SqlCommand cmd = new SqlCommand(query, cl3.con);
            // here is new code
            cmd.Parameters.AddWithValue("@itemcate", ddlitemcate);
            cmd.Parameters.AddWithValue("@pid", lblautoid);
            cmd.Parameters.AddWithValue("@pno", txtpno);
            cmd.Parameters.AddWithValue("@pdt", txtpdate);
            cmd.Parameters.AddWithValue("@pinv", txtinvno);
            cmd.Parameters.AddWithValue("@pindt", txtindate);
            cmd.Parameters.AddWithValue("@pitemname", ddlitename);
            cmd.Parameters.AddWithValue("@qty", txtqty);
            cmd.Parameters.AddWithValue("@rate", txtrate);
            cmd.Parameters.AddWithValue("@amt", txtamt);
            cmd.Parameters.AddWithValue("@insdate", dateTime.ToString("yyyy-MM-dd"));
            cmd.Parameters.AddWithValue("@instime", dateTime.ToString("hh:mm:ss tt"));
            cmd.Parameters.AddWithValue("@insuser", insu);
            cmd.Parameters.AddWithValue("@finyear", finyear);
            cmd.Parameters.AddWithValue("@ptype", ptype);
            cmd.Parameters.AddWithValue("@pnon", pnon);
            cmd.Parameters.AddWithValue("@unit", ddlunit);
            cl3.con.Open();
            int n = cmd.ExecuteNonQuery();
            cl3.con.Close();
            return n > 0;
        }
        catch (Exception ex)
        {
            cl3.con.Close();
            return false;
        }
    }
}