﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Restaurant_Billing : System.Web.UI.Page
{
    Class1 cl = new Class1();
    public static TimeZoneInfo timeZoneInfo = TimeZoneInfo.FindSystemTimeZoneById("India Standard Time");
    public static DateTime dateTime;
    HttpCookie lgdcookie;
    string lastSubGroup = "";
    protected void Page_Load(object sender, EventArgs e)
    {
        lgdcookie = Request.Cookies["loggeduser"];
        if (lgdcookie != null && !string.IsNullOrEmpty(lgdcookie["UserName"]))
        {
            dateTime = TimeZoneInfo.ConvertTime(DateTime.Now, timeZoneInfo);

            if (!IsPostBack)
            {
                string foodBillNo = Request.QueryString["food"];
                string barBillNo = Request.QueryString["bar"];

                lbltable.Text = Request.QueryString["tableno"];

                bool hasFood = !string.IsNullOrEmpty(foodBillNo);
                bool hasBar = !string.IsNullOrEmpty(barBillNo);

                if (hasFood)
                {
                    BindFoodBill(foodBillNo);
                    printFood.Visible = true;
                }
                else
                {
                    printFood.Visible = false;
                }

                if (hasBar)
                {
                    BindBarBill(barBillNo);
                    printBar.Visible = true;
                }
                else
                {
                    printBar.Visible = false;
                }
                decimal foodTotal = hasFood ? Convert.ToDecimal(Label18.Text) : 0;
                decimal barTotal = hasBar ? Convert.ToDecimal(Label181.Text) : 0;

                ShowFooter(foodBillNo, barBillNo, foodTotal, barTotal);
                lastSubGroup = "";
                gridbill1.DataBind();

            }
        }
    }


    protected void btncancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("Dashboard.aspx");
    }
    protected void btnPrint_Click(object sender, EventArgs e)
    {            
        printFood.Visible = true;
        printBar.Visible = true;

        ScriptManager.RegisterStartupScript(
            this,
            this.GetType(),
            "printFood",
            "window.print();",
            true
        );
    }

    public void BindFoodBill(string billno)
    {
        try
        {
            Label6.Text = billno;
            lbltablee.Text = lbltable.Text;
            string query = "SELECT ig.subpgroupname, bd.itemname, bd.rate, SUM(bd.qty) AS qty, SUM(bd.amount) AS amount,CONVERT(nvarchar, bm.bill_date, 103) AS insdate,bm.bill_no,bm.grandtotal,bm.tax,bm.Discount,bm.subtotal FROM Bill_Master bm LEFT JOIN Bill_Detail bd ON bm.bill_id = bd.bill_id INNER JOIN item_detail id ON bd.itemname = id.item_name INNER JOIN Item_group_Master ig ON id.Item_group_name = ig.item_g_id WHERE bm.isrunning = 1 and bill_no='" + billno + "' and table_no='" + lbltable.Text + "' GROUP BY bd.itemname,bd.rate,bm.bill_date,bm.bill_no,bm.grandtotal,bm.tax, bm.Discount,bm.subtotal,  ig.subpgroupname ORDER BY ig.subpgroupname, bd.itemname";
            SqlDataAdapter sda = new SqlDataAdapter(query, cl.con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                gridbill.DataSource = dt;
                gridbill.DataBind();
                lblbilldate.Text = dt.Rows[0]["insdate"].ToString();
                lblptotal.Text = dt.Rows[0]["subtotal"].ToString();
                lbldiscount.Text = dt.Rows[0]["Discount"].ToString();
                Label17.Text = dt.Rows[0]["tax"].ToString();
                Label18.Text = dt.Rows[0]["grandtotal"].ToString();
                bindkot(billno, lblkotnoo);
                lblid.Text = lgdcookie["UserName"].ToString();
                lbldatee.Text = dateTime.ToString("dd/MM/yyyy");
                lbltime.Text = dateTime.ToString("hh:mm tt");
                decimal grandTotal = Convert.ToDecimal(dt.Rows[0]["grandtotal"]);
                lblinword.Text = NumberToWords(grandTotal);
            }
        }
        catch (Exception ex)
        {

        }
    }           
    public void BindBarBill(string billno1)
    {
        try
        {
            Label61.Text = billno1;
            lbltablee1.Text = lbltable.Text;
            string query = "SELECT ig.subpgroupname, bd.itemname, bd.rate, SUM(bd.qty) AS qty, SUM(bd.amount) AS amount,CONVERT(nvarchar, bm.bill_date, 103) AS insdate,bm.bill_no,bm.grandtotal,bm.tax,bm.Discount,bm.subtotal FROM Bill_Master bm LEFT JOIN Bill_Detail bd ON bm.bill_id = bd.bill_id INNER JOIN item_detail id ON bd.itemname = id.item_name INNER JOIN Item_group_Master ig ON id.Item_group_name = ig.item_g_id WHERE bm.isrunning = 1 and bill_no='" + billno1 + "' and table_no='" + lbltable.Text + "' GROUP BY bd.itemname,bd.rate,bm.bill_date,bm.bill_no,bm.grandtotal,bm.tax, bm.Discount,bm.subtotal,  ig.subpgroupname ORDER BY ig.subpgroupname, bd.itemname";
            SqlDataAdapter sda1 = new SqlDataAdapter(query, cl.con);
            DataTable dt1 = new DataTable();
            sda1.Fill(dt1);
            if (dt1.Rows.Count > 0)
            {
                gridbill1.DataSource = dt1;
                gridbill1.DataBind();
                lblbilldate1.Text = dt1.Rows[0]["insdate"].ToString();
                lblptotal1.Text = dt1.Rows[0]["subtotal"].ToString();
                decimal subtotal = Convert.ToDecimal(lblptotal1.Text);
                decimal membership = 0;
                if (subtotal > 1000)
                {
                    membership = 10;
                    membershipRow.Visible = true;
                    membershipNoteRow.Visible = true;
                    grandtotal.Visible = true;
                }
                else
                {
                    membershipRow.Visible = false;
                    membershipNoteRow.Visible = false;
                    grandtotal.Visible = false;
                }
                lblmembershipcharg.Text = membership.ToString("0.00");
                decimal grandTotal = subtotal + membership;
                Label181.Text = grandTotal.ToString("0.00");

                bindkot(billno1, lblkotnoo1);
                lblid1.Text = lgdcookie["UserName"].ToString();
                lbldatee1.Text = dateTime.ToString("dd/MM/yyyy");
                lbltime1.Text = dateTime.ToString("hh:mm tt");
                lblinword1.Text = NumberToWords(grandTotal);
            }
        }
        catch (Exception ex)
        {

        }
    }           
    public string NumberToWords(decimal number)
    {
        long intPart = (long)Math.Floor(number);
        int fraction = (int)((number - intPart) * 100); 

        string words = NumberToWords(intPart);

        if (fraction > 0)
        {
            words += " and " + NumberToWords(fraction) + " Paise";
        }

        return words + " Only";
    }
    private string NumberToWords(long number)
    {
        if (number == 0)
            return "Zero";

        if (number < 0)
            return "Minus " + NumberToWords(Math.Abs(number));

        string words = "";

        if ((number / 10000000) > 0)
        {
            words += NumberToWords(number / 10000000) + " Crore ";
            number %= 10000000;
        }

        if ((number / 100000) > 0)
        {
            words += NumberToWords(number / 100000) + " Lakh ";
            number %= 100000;
        }

        if ((number / 1000) > 0)
        {
            words += NumberToWords(number / 1000) + " Thousand ";
            number %= 1000;
        }

        if ((number / 100) > 0)
        {
            words += NumberToWords(number / 100) + " Hundred ";
            number %= 100;
        }

        if (number > 0)
        {
            string[] units = { "", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten",
                           "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen", "Seventeen", "Eighteen", "Nineteen" };
            string[] tens = { "", "", "Twenty", "Thirty", "Forty", "Fifty", "Sixty", "Seventy", "Eighty", "Ninety" };

            if (number < 20)
                words += units[number];
            else
            {
                words += tens[number / 10];
                if ((number % 10) > 0)
                    words += " " + units[number % 10];
            }
        }

        return words.Trim();
    }

    public void bindkot(string blno, Label targetLabel)
    {
        List<string> kotList = new List<string>();
       
        using (SqlCommand cmd = new SqlCommand("SELECT kot_no FROM kot_Master WHERE billno=@billno", cl.con))
        {
            cmd.Parameters.AddWithValue("@billno", blno);
            cl.con.Open();

            using (SqlDataReader dr = cmd.ExecuteReader())
            {
                while (dr.Read())
                {
                    kotList.Add(dr["kot_no"].ToString());
                }
            }
            cl.con.Close();
        }     

        targetLabel.Text = string.Join(", ", kotList);
    }

    protected void gridbill_RowDataBound(object sender, GridViewRowEventArgs e)
    {          
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            string currentGroup =
                DataBinder.Eval(e.Row.DataItem, "subpgroupname").ToString();
            if (lastSubGroup != currentGroup)
            {
                GridView grid = (GridView)sender;

                GridViewRow groupRow = new GridViewRow(
                    -1, -1,
                    DataControlRowType.DataRow,
                    DataControlRowState.Normal
                );

                TableCell cell = new TableCell();
                cell.ColumnSpan = grid.Columns.Count;
                cell.Text = currentGroup.ToUpper();
                cell.BackColor = Color.LightGray;
                cell.Font.Bold = true;
                cell.Font.Size = 10;
                cell.HorizontalAlign = HorizontalAlign.Left;
                cell.Style.Add("padding", "3px");

                groupRow.Cells.Add(cell);

                grid.Controls[0].Controls.AddAt(
                    grid.Controls[0].Controls.Count - 1,
                    groupRow
                );

                lastSubGroup = currentGroup;
            }
        }          
    }
    protected void gridbill_RowDataBound1(object sender, GridViewRowEventArgs e)
    {          
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            string currentGroup =
                DataBinder.Eval(e.Row.DataItem, "subpgroupname").ToString();
            if (lastSubGroup != currentGroup)
            {
                GridView grid = (GridView)sender;

                GridViewRow groupRow = new GridViewRow(
                    -1, -1,
                    DataControlRowType.DataRow,
                    DataControlRowState.Normal
                );

                TableCell cell = new TableCell();
                cell.ColumnSpan = grid.Columns.Count;
                cell.Text = currentGroup.ToUpper();
                cell.BackColor = Color.LightGray;
                cell.Font.Bold = true;
                cell.Font.Size = 10;
                cell.HorizontalAlign = HorizontalAlign.Left;
                cell.Style.Add("padding", "3px");

                groupRow.Cells.Add(cell);

                grid.Controls[0].Controls.AddAt(
                    grid.Controls[0].Controls.Count - 1,
                    groupRow
                );

                lastSubGroup = currentGroup;
            }
        }          
    }
    private void ShowFooter(string foodBillNo, string barBillNo,
                        decimal foodTotal, decimal barTotal)
    {
        bool hasFood = !string.IsNullOrEmpty(foodBillNo);
        bool hasBar = !string.IsNullOrEmpty(barBillNo);

        if (!(hasFood && hasBar))
        {
            printFooter.Visible = false;
            return;
        }
        printFooter.Visible = true;

        lblFoodBillNo.Text = foodBillNo;
        lblFoodAmount.Text = foodTotal.ToString("0.00");

        lblBarBillNo.Text = barBillNo;
        lblBarAmount.Text = barTotal.ToString("0.00");

        lblFinalTotal.Text = (foodTotal + barTotal).ToString("0.00");
    }     

}

