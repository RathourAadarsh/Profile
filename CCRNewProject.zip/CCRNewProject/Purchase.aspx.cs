﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class Purchase : System.Web.UI.Page
{
    public static TimeZoneInfo timeZoneInfo = TimeZoneInfo.FindSystemTimeZoneById("India Standard Time");
    public static DateTime dateTime;
    Class1 cl3 = new Class1();
    HttpCookie lgdcookie;

    protected void Page_Load(object sender, EventArgs e)
    {
        lgdcookie = Request.Cookies["loggeduser"];
        dateTime = TimeZoneInfo.ConvertTime(DateTime.Now, timeZoneInfo);
        if (lgdcookie != null && !string.IsNullOrEmpty(lgdcookie["UserName"]))
        {
            if (!IsPostBack)
            {
                generatepno();
                generateino();
                itemcategory();
                item();
                binddetail();
                txtpdate.Text = dateTime.ToString("yyyy-MM-dd");
                txtindate.Text = dateTime.ToString("yyyy-MM-dd");
            }
        }
        else
        {
            Response.Redirect("Login.aspx");
        }
    }
    public void generatepno()
    {
        int len = 0;
        string id = null;
        string st = null;
        int count = 0;
        int i = 0;
        string vou = null;
        string prefix = cl3.Scalar("select pnofix from PrefixPurchase");
        vou = "Select ISNULL(max(convert(int,pid)),0) as pid  from PurchaseEntry where finyear='" + lgdcookie["finyear"] + "'";
        count = Convert.ToInt32(cl3.Scalar(vou));
        if (count > 0)
        {
            st = cl3.Scalar("Select ISNULL(max(convert(int,pid)),0) as pid  from PurchaseEntry where finyear='" + lgdcookie["finyear"] + "'");
            i = Convert.ToInt32(st);
            id = (i + 1).ToString();
            len = id.Length;
            switch (len)
            {
                case 1:
                    id = "000" + id;
                    break;
                case 2:
                    id = "00" + id;
                    break;
                case 3:
                    id = "0" + id;
                    break;
            }
        }
        else
        {
            id = "0001";
        }
        lblautoid.Text = id;
        txtpno.Text = prefix + "/" + id;
        txtpno.ReadOnly = true;
    }
    public void generateino()
    {
        int len = 0;
        string id = null;
        string st = null;
        int count = 0;
        int i = 0;
        string vou = null;
        string prefix = cl3.Scalar("select Inofix from PrefixPurchase");
        vou = "Select ISNULL(max(convert(int,isid)),0) as isid  from IssuetoKitchen where finyear='" + lgdcookie["finyear"] + "'";
        count = Convert.ToInt32(cl3.Scalar(vou));
        if (count > 0)
        {
            st = cl3.Scalar("Select ISNULL(max(convert(int,isid)),0) as isid  from IssuetoKitchen where finyear='" + lgdcookie["finyear"] + "'");
            i = Convert.ToInt32(st);
            id = (i + 1).ToString();
            len = id.Length;
            switch (len)
            {
                case 1:
                    id = "000" + id;
                    break;
                case 2:
                    id = "00" + id;
                    break;
                case 3:
                    id = "0" + id;
                    break;
            }
        }
        else
        {
            id = "0001";
        }
        lblisid.Text = id;
        lblissno.Text = prefix + "/" + id;
    }
    protected void ddlitemcate_SelectedIndexChanged(object sender, EventArgs e)
    {
        item();
    }
    public void itemcategory()
    {
        try
        {
            string str = "select item_g_id,item_g_name from StoreItem_group_Master where deactive='0' order by item_g_name";
            SqlCommand cmd = new SqlCommand(str, cl3.con);
            SqlDataAdapter adp = new SqlDataAdapter(cmd);
            DataTable dt1 = new DataTable();
            adp.Fill(dt1);
            if (dt1.Rows.Count > 0)
            {
                ddlitemcate.DataSource = dt1;
                ddlitemcate.DataTextField = "item_g_name";
                ddlitemcate.DataValueField = "item_g_id";
                ddlitemcate.DataBind();
                //ddlitemcate.Items.Insert(0, new ListItem("--Select--", "0"));
            }
        }
        catch (Exception)
        {

        }
    }
    public void item()
    {
        try
        {
            string str = "select sku,item_name from StoreItem_detail where deactive='0' order by item_name";
            SqlCommand cmd = new SqlCommand(str, cl3.con);
            SqlDataAdapter adp = new SqlDataAdapter(cmd);
            DataTable dt1 = new DataTable();
            adp.Fill(dt1);
            if (dt1.Rows.Count > 0)
            {
                ddlitename.DataSource = dt1;
                ddlitename.DataTextField = "item_name";
                ddlitename.DataValueField = "sku";
                ddlitename.DataBind();
                ddlitename.Items.Insert(0, new ListItem("--Select--", "0"));
            }
        }
        catch (Exception ex)
        {

        }
    }
    protected void ddlitename_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            txtrate.Text = cl3.Scalar("select Item_sale_rate from StoreItem_detail where sku = '" + ddlitename.SelectedValue + "'");
        }
        catch (Exception ex)
        {

        }
    }

    protected void btnSave_Click(object sender, EventArgs e)
    {
        try
        {
            if (txtindate.Text == "" || txtpno.Text == "" || txtpdate.Text == "" || txtinvno.Text == "" || ddlitename.SelectedValue == "0" || txtqty.Text == "" || txtrate.Text == "" || txtamt.Text == "" || ddlitemcate.SelectedValue == "0")
            {

                string message = "Please Fill All Fields !!";
                string type = "warning";
                ScriptManager.RegisterStartupScript(this, this.GetType(), "Script", "savealert('" + message + "','" + type + "')", true);
                return;
            }
            else
            {
                Store clsave = new Store();
                bool result = clsave.Apurchase(lblautoid.Text, txtpno.Text, txtpdate.Text, txtinvno.Text, txtindate.Text, ddlitename.SelectedValue, txtqty.Text, txtrate.Text, txtamt.Text, lgdcookie["username"].ToString(), lgdcookie["finyear"].ToString(), ddlitemcate.SelectedValue, rbtnpurchase.SelectedValue, ddlunit.SelectedValue);
                if (result)
                {
                    if (rbtnpurchase.SelectedValue == "Kitchen")
                    {
                        bool issue = clsave.Issuetokitchen(lblisid.Text, lblissno.Text, txtpdate.Text, txtinvno.Text, txtindate.Text, ddlitename.SelectedValue, txtqty.Text, txtrate.Text, txtamt.Text, lgdcookie["username"].ToString(), lgdcookie["finyear"].ToString(), ddlitemcate.SelectedValue, rbtnpurchase.SelectedValue, txtpno.Text, ddlunit.SelectedValue);
                    }
                    string up = "update StoreItem_detail set Item_sale_rate='" + txtrate.Text + "'  where  SKU='" + ddlitename.SelectedValue + "'";
                    cl3.execute(up);
                    binddetail();
                    txtamt.Text = "";
                    txtqty.Text = "";
                    txtrate.Text = "";
                    btnfinal.Visible = true;

                }
                else
                {
                    string message = "Something Went Wrong !!";
                    string type = "error";
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "Script", "savealert('" + message + "','" + type + "')", true);
                    return;
                }
            }
        }
        catch (Exception ex)
        {

        }
    }

    protected void btnClear_Click(object sender, EventArgs e)
    {
        Response.Redirect("StoreDashboard.aspx");
    }

    protected void btnfinal_Click(object sender, EventArgs e)
    {
        Response.Redirect("Purchase.aspx");
    }
    public void binddetail()
    {
        string query = "select ptype,p.pid,p.pno,convert(nvarchar,p.pdate,103)pdate,p.pinv,convert(nvarchar,p.pinvdt,103)pinvdt,p.itemcate,p.itemname,(p.qty+p.unit)qty,p.rate,p.amount,sip.Item_G_Name,sd.Item_name from purchaseentry p inner join StoreItem_group_Master sip on p.itemcate=sip.item_g_id inner join storeitem_detail sd on p.itemname=sd.sku where pno='" + txtpno.Text + "'";
        SqlDataAdapter sda = new SqlDataAdapter(query, cl3.con);
        DataTable dt = new DataTable();
        sda.Fill(dt);
        if (dt.Rows.Count > 0)
        {
            listview2.DataSource = dt;
            listview2.DataBind();
        }
    }
}