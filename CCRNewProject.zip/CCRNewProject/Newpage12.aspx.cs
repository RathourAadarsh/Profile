﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Newpage12 : System.Web.UI.Page
{
    Class1 cl = new Class1();

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {           
            var masterFooter = this.Master.FindControl("masterFooter");
            if (masterFooter != null)
            {
                masterFooter.Visible = false;
            }
            string tableNo = Request.QueryString["tblno"];
            lblTableNo.Text = Request.QueryString["tblno"];

            if (Session["SelectedItems_" + tableNo] != null)
            {
                List<Itemdata> items = (List<Itemdata>)Session["SelectedItems_" + tableNo];

                items = items.Where(x => Convert.ToInt32(x.qty) > 0).ToList();

                Session["SelectedItems_" + tableNo] = items;

                ScriptManager.RegisterStartupScript(this, this.GetType(), "fillData",
                    "setTimeout(function(){ restoreSelectedItems('" +
                    new JavaScriptSerializer().Serialize(items) +
                    "'); }, 500);",
                    true);
            }

            BindGroupData();
        }
    }
    private void BindGroupData()
    {
        SqlCommand cmd = new SqlCommand("SELECT id.id as item_id, ig.Item_G_Name AS group_name, id.item_name, id.item_sale_rate, ('../' + id.Productimage) AS Productimage,id.flag FROM Item_detail id INNER JOIN item_group_master ig ON id.item_group_name = ig.item_g_id ORDER BY ig.Item_G_Name, id.item_name", cl.con);
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataTable dt = new DataTable();
        da.Fill(dt);
        if (dt.Rows.Count > 0)
        {
            var groups = dt.AsEnumerable()
                           .GroupBy(r => r.Field<string>("group_name"))
                           .Select(g => new
                           {
                               GroupName = g.Key,
                               Items = g.CopyToDataTable(),
                               ItemCount = g.Count()
                           }).ToList();
            rptGroup.DataSource = groups;
            rptGroup.DataBind();
            rptGroupMenu.DataSource = groups.Select(x => new
            {
                GroupName = x.GroupName,
                ItemCount = x.ItemCount
            });
            rptGroupMenu.DataBind();
        }
    }
    protected void rptGroup_ItemDataBound(object sender, RepeaterItemEventArgs e)
    {
        if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
        {
            dynamic group = e.Item.DataItem;
            Repeater rptItems = (Repeater)e.Item.FindControl("rptItems");
            rptItems.DataSource = group.Items;
            rptItems.DataBind();
        }
    }
    protected void btnNext_Click(object sender, EventArgs e)
    {
        string json = hfItems.Value;
        string tableNo = Request.QueryString["tblno"];

        if (string.IsNullOrEmpty(json))
        {
            ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert('No item selected!');", true);
            return;
        }

        JavaScriptSerializer js = new JavaScriptSerializer();
        List<Itemdata> items = js.Deserialize<List<Itemdata>>(json);

        if (items == null || items.Count == 0)
        {
            ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert('No valid item data found!');", true);
            return;
        }

        if (cl.con.State == ConnectionState.Closed)
            cl.con.Open();
        foreach (var item in items)
        {
            if (item.flag == 0)  
            {
                SqlCommand cmd = new SqlCommand("SELECT flag FROM Item_detail WHERE id=@id", cl.con);
                cmd.Parameters.AddWithValue("@id", item.item_id);
                item.flag = Convert.ToInt32(cmd.ExecuteScalar());
                item.gst_per = (item.flag == 1) ? 5 : 0;
            }
        }
        int kotId = Convert.ToInt32(
            new SqlCommand("SELECT ISNULL(MAX(kot_id),0) + 1 FROM RestaurantItems", cl.con)
            .ExecuteScalar()
        );

        foreach (var item in items)
        {
            decimal qty = Convert.ToDecimal(item.qty);
            decimal rate = Convert.ToDecimal(item.item_rate);

            decimal basicAmount = qty * rate;
            decimal gstPer = (item.flag == 1) ? 5 : 0;
            decimal gstAmount = Math.Round((basicAmount * gstPer) / 100, 2);

            decimal totalAmount = basicAmount + gstAmount;

            SqlCommand cmdItem = new SqlCommand("INSERT INTO RestaurantItems (kot_id, Table_No, itemcode, itemname, qty, rate, Amount, GstPer, GstAmount, TotalAmount) VALUES (@kot_id, @Table_No, @itemcode, @itemname, @qty, @rate, @Amount, @GstPer, @GstAmount, @TotalAmount)", cl.con);

            cmdItem.Parameters.AddWithValue("@kot_id", kotId);
            cmdItem.Parameters.AddWithValue("@Table_No", tableNo);
            cmdItem.Parameters.AddWithValue("@itemcode", item.item_id);
            cmdItem.Parameters.AddWithValue("@itemname", item.item_name);
            cmdItem.Parameters.AddWithValue("@qty", qty);
            cmdItem.Parameters.AddWithValue("@rate", rate);
            cmdItem.Parameters.AddWithValue("@Amount", basicAmount);
            cmdItem.Parameters.AddWithValue("@GstPer", gstPer);
            cmdItem.Parameters.AddWithValue("@GstAmount", gstAmount);
            cmdItem.Parameters.AddWithValue("@TotalAmount", totalAmount);

            cmdItem.ExecuteNonQuery();
        }

        cl.con.Close();

        Session["SelectedItems_" + tableNo] = items;
        Session["KOT_ID_" + tableNo] = kotId;

        Response.Redirect("OrderSummary.aspx?tblno=" + tableNo);
    }

    private void BindSelectedItems(List<Itemdata> items)
    {
        itemCount.InnerText = items.Count.ToString();
    }
    [WebMethod]
    public static string SaveItems(List<Itemdata> items)
    {
        HttpContext.Current.Session["SelectedItems"] = items;
        return "OK";
    }
    protected void txtSearch_TextChanged(object sender, EventArgs e)
    {
        string search = txtSearch.Text.Trim().ToLower();
        SqlCommand cmd = new SqlCommand("SELECT id.id as item_id, ig.Item_G_Name AS group_name, id.item_name, id.item_sale_rate, ('../' + id.Productimage) AS Productimage FROM Item_detail id INNER JOIN item_group_master ig ON id.item_group_name = ig.Item_G_Name WHERE id.item_name LIKE @search + '%' ORDER BY ig.Item_G_Name, id.item_name", cl.con);

        cmd.Parameters.AddWithValue("@search", search);
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataTable dt = new DataTable();
        da.Fill(dt);

        if (dt.Rows.Count > 0)
        {
            var groups = dt.AsEnumerable()
                           .GroupBy(r => r.Field<string>("group_name"))
                           .Select(g => new
                           {
                               GroupName = g.Key,
                               Items = g.CopyToDataTable(),
                               ItemCount = g.Count()
                           }).ToList();
            rptGroup.DataSource = groups;
            rptGroup.DataBind();

            rptGroupMenu.DataSource = groups.Select(x => new
            {
                GroupName = x.GroupName,
                ItemCount = x.ItemCount
            });
            rptGroupMenu.DataBind();
        }
        else
        {
            rptGroup.DataSource = null;
            rptGroup.DataBind();
            rptGroupMenu.DataSource = null;
            rptGroupMenu.DataBind();
        }
    }
}