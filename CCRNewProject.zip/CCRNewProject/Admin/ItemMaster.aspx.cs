﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class Admin_ItemMaster : System.Web.UI.Page
{
    public static TimeZoneInfo timeZoneInfo = TimeZoneInfo.FindSystemTimeZoneById("India Standard Time");
    public static DateTime dateTime;
    HttpCookie lgdcookie;
    Class1 cl = new Class1();

    protected void Page_Load(object sender, EventArgs e)
    {
        lgdcookie = Request.Cookies["loggeduser"];
        dateTime = TimeZoneInfo.ConvertTime(DateTime.Now, timeZoneInfo);
        if (lgdcookie != null && !string.IsNullOrEmpty(lgdcookie["UserName"]))
        {
            if (!IsPostBack)
            {
                txtitemcode.Text = cl.Scalar("SELECT isnull(Max(sku+1),1)sku from Item_detail where deactive='0'");
                txtitemcode.ReadOnly = true;
                bindgroup();
            }
        }
        else
        {
            Response.Redirect("Login.aspx");
        }
    }

    protected void btnsave_Click(object sender, EventArgs e)
    {
        try
        {
            if (txtitemname.Text == "")
            {

            }
            else
            {
                if (btnsave.Text == "Save")
                {

                }
                else
                {

                }
            }
        }
        catch (Exception ex)
        {

        }
    }

    protected void btnback_Click(object sender, EventArgs e)
    {
        Response.Redirect("Dashboard.aspx");
    }
    public void bindgroup()
    {
        try
        {
            string str = "select item_g_id,item_g_name from item_group_master where deactive='0' order by item_g_name";
            SqlCommand cmd = new SqlCommand(str, cl.con);
            SqlDataAdapter adp = new SqlDataAdapter(cmd);
            DataTable dt1 = new DataTable();
            adp.Fill(dt1);
            if (dt1.Rows.Count > 0)
            {
                ddlgroup.DataSource = dt1;
                ddlgroup.DataTextField = "item_g_name";
                ddlgroup.DataValueField = "item_g_id";
                ddlgroup.DataBind();
                ddlgroup.Items.Insert(0, new ListItem("--Select--", "0"));
            }
        }
        catch (Exception)
        {

        }
    }
}