﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Configuration;
using System.Xml.Linq;
using System.Data.SqlClient;


/// <summary>
/// Summary description for Class1
/// </summary>
public class Class1
{
    public SqlConnection con = new SqlConnection();
    SqlCommand cmd = new SqlCommand();
    public string constr;
    public Class1()
    {
        //constr = "Data Source=DESKTOP-2F9M65R\\MSSQLSERVER12;Initial Catalog=WeldingProjectUK;Integrated Security=True";
        constr = "Data Source =SQL1004.site4now.net; Initial Catalog = db_ab253a_uk;User Id=db_ab253a_uk_admin; Password =uk#15934%; Encrypt = True; TrustServerCertificate = True";

        cb = new System.Data.SqlClient.SqlCommandBuilder(adp);
        adp.SelectCommand = new System.Data.SqlClient.SqlCommand(" ", con);
        adp.InsertCommand = new System.Data.SqlClient.SqlCommand(" ", con);
        adp.UpdateCommand = new System.Data.SqlClient.SqlCommand(" ", con);
        cmd = new System.Data.SqlClient.SqlCommand("", con);
        cmd.CommandTimeout = 0;
        con.ConnectionString = constr;
    }
    public void execute(string str)
    {
        if (con.State == ConnectionState.Open)
        {
            con.Close();
        }
        con.ConnectionString = constr;
        cmd.Connection = con;
        cmd.CommandText = str;
        cmd.CommandTimeout = 0;
        con.Open();
        cmd.ExecuteNonQuery();
        con.Close();
    }
    public string Scalar(string str)
    {
        if (con.State == ConnectionState.Open)
        {
            con.Close();
        }
        con.ConnectionString = constr;
        cmd.Connection = con;
        string s = null;
        cmd.CommandText = str;
        con.Open();
        s = Convert.ToString(cmd.ExecuteScalar());
        con.Close();
        return s;
    }
    public SqlDataReader DataReader(string str)
    {
        SqlDataReader dr = default(SqlDataReader);
        if (con.State == ConnectionState.Open)
        {
            con.Close();
        }
        con.ConnectionString = constr;
        cmd.Connection = con;
        cmd.CommandText = str;
        cmd.CommandTimeout = 0;
        con.Open();
        dr = cmd.ExecuteReader();
        return dr;
    }
    public DataSet Dataset(string str)
    {
        SqlDataAdapter adp = new SqlDataAdapter();
        DataSet ds = new DataSet();
        if (con.State == ConnectionState.Open)
        {
            con.Close();
        }
        con.ConnectionString = constr;
        cmd.Connection = con;
        cmd.CommandText = str;
        cmd.CommandTimeout = 0;
        con.Open();
        adp.SelectCommand = cmd;
        adp.Fill(ds);
        return ds;
    }
    public DataTable DataTable(string str)
    {
        SqlDataReader dr = default(SqlDataReader);
        if (con.State == ConnectionState.Open)
        {
            con.Close();
        }
        con.ConnectionString = constr;
        cmd.Connection = con;
        cmd.CommandText = str;
        cmd.CommandTimeout = 0;
        con.Open();
        dr = cmd.ExecuteReader();
        DataTable dt = new DataTable();
        dt.Load(dr);
        return dt;
    }
    public int count(string tbname, string Fieldname, string value)
    {
        if (con.State == ConnectionState.Open)
        {
            con.Close();
        }
        int c = 0;
        con.ConnectionString = constr;
        con.Open();
        cmd.Connection = con;
        cmd.CommandText = "select count(*) from " + tbname + " where " + Fieldname + "='" + value + "'";
        c = Convert.ToInt32(cmd.ExecuteScalar());
        con.Close();
        return c;
    }
    public System.Data.SqlClient.SqlDataAdapter adp = new System.Data.SqlClient.SqlDataAdapter();
    public System.Data.SqlClient.SqlCommandBuilder cb;

    public void open()
    {
        if (con.State == ConnectionState.Closed)
        {
            con.Open();
        }
    }
    public void close()
    {
        if (con.State == ConnectionState.Open)
        {
            con.Close();
        }
    }
}