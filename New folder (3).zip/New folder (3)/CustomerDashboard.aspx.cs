﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class CustomerDashboard : System.Web.UI.Page
{
    public static TimeZoneInfo timeZoneInfo = TimeZoneInfo.FindSystemTimeZoneById("India Standard Time");
    public static DateTime dateTime;
    Class1 cl = new Class1();
    protected void Page_Load(object sender, EventArgs e)
    {
        dateTime = TimeZoneInfo.ConvertTime(DateTime.Now, timeZoneInfo);
        if (!IsPostBack)
        {
            BindCategory();
            BindProduct(0); 
        }
    }
    private void BindCategory()
    {
        SqlDataAdapter da = new SqlDataAdapter("SELECT CategoryId, CategoryName,ImageUrl FROM Category WHERE IsActive=1",
            cl.con);

        DataTable dt = new DataTable();
        da.Fill(dt);

        rptCategory.DataSource = dt;
        rptCategory.DataBind();
    }

    private void BindProduct(int categoryId)
    {
        string query = "";

        if (categoryId == 0)
        {
            query = "SELECT * FROM Product WHERE IsActive=1";
        }
        else
        {
            query = "SELECT * FROM Product WHERE IsActive=1 AND CategoryId=@CategoryId";
        }

        SqlCommand cmd = new SqlCommand(query,cl.con);

        if (categoryId != 0)
        {
            cmd.Parameters.AddWithValue("@CategoryId", categoryId);
        }

        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataTable dt = new DataTable();
        da.Fill(dt);

        rptProduct.DataSource = dt;
        rptProduct.DataBind();
    }

    protected void rptCategory_ItemCommand(object source,
        System.Web.UI.WebControls.RepeaterCommandEventArgs e)
    {
        if (e.CommandName == "Filter")
        {
            int categoryId = Convert.ToInt32(e.CommandArgument);
            BindProduct(categoryId);
        }
    }
    //protected void rptProduct_ItemCommand(object source, RepeaterCommandEventArgs e)
    //{
    //    int productId = Convert.ToInt32(e.CommandArgument);

    //    if (e.CommandName == "Add")
    //    {
    //        Panel pnlAdd = (Panel)e.Item.FindControl("pnlAdd");
    //        Panel pnlQty = (Panel)e.Item.FindControl("pnlQty");
    //        Label lblQty = (Label)e.Item.FindControl("lblQty");

    //        pnlAdd.Visible = false;
    //        pnlQty.Visible = true;
    //        lblQty.Text = "1";
    //    }

    //    if (e.CommandName == "Plus")
    //    {
    //        Label lblQty = (Label)e.Item.FindControl("lblQty");
    //        int qty = Convert.ToInt32(lblQty.Text);
    //        lblQty.Text = (qty + 1).ToString();
    //    }

    //    if (e.CommandName == "Minus")
    //    {
    //        Label lblQty = (Label)e.Item.FindControl("lblQty");
    //        Panel pnlAdd = (Panel)e.Item.FindControl("pnlAdd");
    //        Panel pnlQty = (Panel)e.Item.FindControl("pnlQty");

    //        int qty = Convert.ToInt32(lblQty.Text);

    //        if (qty > 1)
    //        {
    //            lblQty.Text = (qty - 1).ToString();
    //        }
    //        else
    //        {
    //            pnlAdd.Visible = true;
    //            pnlQty.Visible = false;
    //        }
    //    }
    //}

}