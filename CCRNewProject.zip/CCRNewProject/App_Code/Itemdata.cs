﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
public class Itemdata
{
    public string item_id { get; set; }
    public string item_name { get; set; }
    public string item_rate { get; set; }
    public string qty { get; set; }
    public string remark { get; set; }
    public string TableNo { get; set; }   
    public int kot_flag { get; set; }     
    public int Bill_print { get; set; }
    public int flag { get; set; }    
    public decimal gst_per { get; set; }  
}
